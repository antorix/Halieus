import tkinter as tk
from tkinter import ttk
import os
import data as d
from data import db
from icons import icon
import tkinter.messagebox as mb

class GUI:    
    
    def __init__(self, parent):

        # Window set up         
        w = 800
        h = 600
        ws = parent.winfo_screenwidth()
        hs = parent.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        parent.minsize(300,430)
        if os.name=="nt": parent.iconbitmap("icon.ico")
        parent.title("Участки")
        #ttk.Separator(parent, orient='horizontal').grid (column=0, row=0, columnspan=2, sticky='nwe')
        #ttk.Separator(parent, orient='horizontal').grid (column=0, row=5, columnspan=2, sticky='nwe')
        ttk.Sizegrip(parent).grid(column=1, row=5, sticky="se")                
        
        # Main menu
        menubar = tk.Menu(parent)
        filemenu = tk.Menu(menubar, tearoff=0)
        def clear():
            if mb.askyesno("Очистка базы", "Вы уверены, что хотите безвозвратно удалить все участки?")==True: # help window
                del db[:]
                self.update()
        filemenu.add_command(label="Очистить базу", command=clear)
        def about(): mb.showinfo("О программе", "Участки 0.9b\nantorix@gmail.com") # help window
        filemenu.add_command(label="О программе", command=about)
        filemenu.add_separator()
        filemenu.add_command(label="Выход", command=parent.quit)
        menubar.add_cascade(label="Настройки", menu=filemenu)
        #editmenu = tk.Menu(menubar, tearoff=0)
        parent.config(menu=menubar)        
        
        # Grid set up        
        parent.grid_columnconfigure (0, weight=5)
        parent.grid_columnconfigure (1, weight=0)
        parent.grid_rowconfigure    (0, weight=0)
        parent.grid_rowconfigure    (1, weight=0)
        parent.grid_rowconfigure    (2, weight=0)
        parent.grid_rowconfigure    (3, weight=0)
        parent.grid_rowconfigure    (4, weight=1)
        parent.grid_rowconfigure    (5, weight=0)
        
        # Main list        
        self.list = tk.Listbox(parent, bd=5, height=30, font="Courier 9", relief="flat")
        self.list.grid(column=0, row=1, rowspan=5, padx=3, pady=3, sticky="nwes")  
        rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=rightScrollbar.set)      
        rightScrollbar.pack(side="right", fill="y")
        bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
        self.list.configure(xscrollcommand=bottomScrollbar.set)
        bottomScrollbar.pack(side="bottom", fill="x")
        
        # Operations on main list        
        def getSelected(event): return int(event.widget.get(event.widget.curselection()[0])[:event.widget.get(event.widget.curselection()[0]).index(")")])-1 # returns index number of selected ter            
        def select(event): # show ter card            
            selected=getSelected(event)
            if db[selected].show(self)=="delete":
                del db[selected] # delete from card
            d.save()
            self.update()            
        def delete(event): # delete from list
            selected = getSelected(event)
            if mb.askyesno("Удаление", "Удалить участок %s?" % db[selected].number)==True:
                del db[selected]
                d.save()
                self.update()            
        #self.list.bind("<<ListboxSelect>>", select)
        self.list.bind("<Double-Button-1>", select)
        self.list.bind("<Return>", select)
        self.list.bind("<Delete>", delete)
        self.list.bind("<BackSpace>", delete)
        
        # Statistics        
        self.statsFrame=ttk.LabelFrame(parent, text="Статистика")
        self.statsFrame.grid(column=1, row=2, padx=5, pady=5, sticky="nwes")
        self.stats=ttk.Label(self.statsFrame)#, font="Tahoma 9")
        self.stats.grid(padx=10, pady=10)
        
        # Sort buttons
        self.sortFrame = ttk.LabelFrame(parent, text="Сортировка")
        self.sortFrame.grid(column=1, row=3, padx=5, pady=5, sticky="nwes")
        self.sortType = tk.StringVar() # radio buttons
        self.sortType.set("По дате сдачи")
        def setSort(): self.update(sort=str(self.sortType.get()))
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По номеру", text="По номеру (№)", command=setSort)
        self.sort2=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По типу", text="По типу (%s)" % icon("type"), command=setSort)
        self.sort3=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По адресу", text="По адресу (%s)" % icon("cottage"), command=setSort)
        self.sort4=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По возвещателю", text="По возвещателю (☺)", command=setSort)        
        self.sort5=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По дате сдачи", text="По дате сдачи (%s)" % icon("calendar"), command=setSort)
        self.sort6=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По числу обработок", text="По числу обработок (%s)" % icon("worked"), command=setSort)
        self.sort7=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По заметке", text="По заметке (%s)" % icon("note"), command=setSort)
        self.sort1.grid(column=0, row=0, padx=5, pady=5, sticky="w")
        self.sort2.grid(column=0, row=1, padx=5, pady=5, sticky="w")
        self.sort3.grid(column=0, row=2, padx=5, pady=5, sticky="w")
        self.sort4.grid(column=0, row=3, padx=5, pady=5, sticky="w")
        self.sort5.grid(column=0, row=4, padx=5, pady=5, sticky="w")
        self.sort6.grid(column=0, row=5, padx=5, pady=5, sticky="w")
        self.sort7.grid(column=0, row=6, padx=5, pady=5, sticky="w")
        
        # New ter
        def newTer(): d.newTer(self, parent)
        home = tk.PhotoImage(file="home.png")
        style = ttk.Style()
        style.configure("big.TButton", font=('', 11), foreground="darkgreen")
        new = ttk.Button(text="Новый участок", style='big.TButton', image=home, command=newTer)
        new.grid(column=1, row=4, pady=10, ipadx=15, ipady=10, sticky="")                
        
        self.update()
        d.save()
        
    def update(self, sort=None):
        """ Redraw ter list and update all stats """
        given = 0
        for number in range(len(db)):
            if db[number].publisher != "": given+=1
        if sort==None: sort = str(self.sortType.get())
        if sort=="По дате сдачи": db.sort(key=lambda x: x.dateReturned, reverse=False) # sort types
        if sort=="По номеру": db.sort(key=lambda x: x.number, reverse=False) 
        if sort=="По типу": db.sort(key=lambda x: x.type, reverse=False) 
        if sort=="По адресу": db.sort(key=lambda x: x.address, reverse=False) 
        if sort=="По возвещателю": db.sort(key=lambda x: x.publisher, reverse=False) 
        if sort=="По числу обработок": db.sort(key=lambda x: x.worked, reverse=False) 
        if sort=="По заметке": db.sort(key=lambda x: x.note, reverse=False)         
        self.listContent = tk.StringVar(value=["%d) %s" % (i+1, db[i].retrieve()) for i in range(len(db))]) # fill list
        self.list.configure(listvariable=self.listContent)      
        for i in range(len(db)):
            self.list.itemconfig(i, {"fg":'midnight blue'}) # set color                 
            if i % 2 == 0: self.list.itemconfig(i, {"bg":'cornsilk'}) # set color                 
            else: self.list.itemconfig(i, {"bg":'gray98'}) # set color                 
        
        self.stats["text"] = "Всего участков:\t%d\n\nВ картотеке:\t%d\n\nУ возвещателей:\t%d" % (len(db), len(db)-given, given)
