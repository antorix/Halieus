import tkinter as tk
from tkinter import ttk
import os
import data as d
from data import db
from icons import icon
import datetime
import time
import tkinter.messagebox as mb

class GUI:    
    
    def __init__(self, parent):

        # Window set up         
        w = 800
        h = 600
        ws = parent.winfo_screenwidth()
        hs = parent.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        parent.minsize(490,490)
        if os.name=="nt": parent.iconbitmap("icon.ico")
        parent.title("Участки")
        #ttk.Separator(parent, orient='horizontal').grid (column=0, row=0, columnspan=2, sticky='nwe')
        
        # Main menu
        menubar = tk.Menu(parent)
        filemenu = tk.Menu(menubar, tearoff=0)
        def clear():
            if mb.askyesno("Очистка базы", "Вы уверены, что хотите безвозвратно удалить все участки?")==True: # help window
                del db[:]
                self.update()
        filemenu.add_command(label="Очистить базу", command=clear)
        def about(): mb.showinfo("О программе", "Участки 0.9b\nantorix@gmail.com") # help window
        filemenu.add_command(label="О программе", command=about)
        filemenu.add_separator()
        filemenu.add_command(label="Выход", command=parent.quit)
        menubar.add_cascade(label="Настройки", menu=filemenu)
        #editmenu = tk.Menu(menubar, tearoff=0)
        parent.config(menu=menubar)        
        
        # Grid set up        
        parent.grid_columnconfigure (0, weight=1)
        parent.grid_columnconfigure (1, weight=0)
        parent.grid_rowconfigure    (0, weight=0)
        parent.grid_rowconfigure    (1, weight=0)
        parent.grid_rowconfigure    (2, weight=0)
        parent.grid_rowconfigure    (3, weight=0)
        parent.grid_rowconfigure    (4, weight=1)
        parent.grid_rowconfigure    (5, weight=0)
        #parent.grid_rowconfigure    (6, weight=0)
        #parent.grid_rowconfigure    (7, weight=0)
        
        # Main list        
        self.list = tk.Listbox(parent, bd=5, height=10, font="Courier 9", relief="flat")
        self.list.grid(column=0, row=1, rowspan=4, padx=3, pady=3, sticky="nwes")  
        rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=rightScrollbar.set)      
        rightScrollbar.pack(side="right", fill="y")
        bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
        self.list.configure(xscrollcommand=bottomScrollbar.set)
        bottomScrollbar.pack(side="bottom", fill="x")
        
        # Operations on main list        
        def getSelected(event): return int(event.widget.get(event.widget.curselection()[0])[:event.widget.get(event.widget.curselection()[0]).index(")")])-1 # returns index number of selected ter            
        def select(event): # show ter card            
            selected=getSelected(event)
            if db[selected].show(self)=="delete":
                del db[selected] # delete from card
                d.save(self)
            self.update()            
        def delete(event): # delete from list
            selected = getSelected(event)
            if mb.askyesno("Удаление", "Удалить участок %s?" % db[selected].number)==True:
                del db[selected]
                d.save(self)
                self.update()            
        #self.list.bind("<<ListboxSelect>>", select)
        self.list.bind("<Double-Button-1>", select)
        self.list.bind("<Return>", select)
        self.list.bind("<Delete>", delete)
        self.list.bind("<BackSpace>", delete)
        
        # New ter
        def newTer(): d.newTer(self, parent)
        #pic = tk.PhotoImage(file="home.png")
        #style = ttk.Style()
        #style.configure("big.TButton", font=('', 10), foreground="darkgreen")
        #new = ttk.Button(parent, text="Новый участок", style='big.TButton', image=home, command=newTer)
        new = tk.Button(parent, text="Новый участок", font="Arial 11", relief="flat", fg="darkgreen", command=newTer)
        #tk.Label(image=pic, compound="right").grid(column=1, row=0, padx=5, pady=5, ipady=8)
        new.grid(column=0, row=5, padx=5, pady=5, ipady=8, sticky="nesw")

        # Search
        self.searchFrame=ttk.Frame(parent)
        self.searchFrame.grid(column=0, row=0, sticky="e")
        ttk.Label(self.searchFrame, text="Поиск").grid(column=0, row=0, padx=3, sticky="e")
        self.search=ttk.Entry(self.searchFrame, width=30)
        self.search.grid(column=1, row=0, padx=3, sticky="e")
        def search(event): # enter search
            query = self.search.get()
            count=0
            for i in range(len(db)):
                if query in db[i].number\
                or query in db[i].type\
                or query in db[i].address\
                or query in db[i].dateGiven\
                or query in db[i].publisher\
                or query in db[i].dateReturned\
                or query in str(db[i].worked)\
                or query in db[i].note\
                or query in db[i].image\
                or query in db[i].map:
                    db.insert(0, db.pop(i))
                    self.update(sort=None)
                    count+=1            
            for i in range(count): self.list.itemconfig(i, {"bg":'green2'})                
        self.search.bind("<Return>", search)
        
        # Statistics        
        self.statsFrame=ttk.LabelFrame(parent, width=500, text="Статистика")
        self.statsFrame.grid(column=1, row=2, padx=5, pady=5, sticky="nwes")
        self.stat1=ttk.Label(self.statsFrame, text="Всего участков")
        self.stat2=ttk.Label(self.statsFrame, text="В картотеке")
        self.stat3=ttk.Label(self.statsFrame, text="На руках")
        self.stat4=ttk.Label(self.statsFrame, text="Необработанные")
        self.stat5=ttk.Label(self.statsFrame, text="Не обработанные за год")
        self.stat1.grid(column=0, row=0, padx=5, pady=5, sticky="w")
        self.stat2.grid(column=0, row=1, padx=5, pady=5, sticky="w")
        self.stat3.grid(column=0, row=2, padx=5, pady=5, sticky="w")
        self.stat4.grid(column=0, row=3, padx=5, pady=5, sticky="w")
        self.stat5.grid(column=0, row=4, padx=5, pady=5, sticky="w")
        
        # Filters in statistics
        def filter(): self.update(self)
        self.filterNonWorked = tk.IntVar()
        self.filterNonWorked.set(0)
        self.check1 = ttk.Checkbutton(self.statsFrame, variable=self.filterNonWorked, onvalue=1, offvalue=0, command=filter)        
        self.filterYear = tk.IntVar()
        self.filterYear.set(0)
        self.check2 = ttk.Checkbutton(self.statsFrame, variable=self.filterYear, onvalue=1, offvalue=0, command=filter)                       
        self.check1.grid(column=1, row=3, padx=5, pady=0, sticky="e")
        self.check2.grid(column=1, row=4, padx=5, pady=0, sticky="e")  
        
        # Sorting
        self.sortFrame = ttk.LabelFrame(parent, text="Сортировка")
        self.sortFrame.grid(column=1, row=3, padx=5, pady=5, sticky="nwes")
        self.sortType = tk.StringVar() # radio buttons
        self.sortType.set("По дате сдачи")
        def setSort(): self.update(sort=str(self.sortType.get()))
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По номеру", text="По номеру (№)", command=setSort)
        self.sort2=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По типу", text="По типу (%s)" % icon("type"), command=setSort)
        self.sort3=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По адресу", text="По адресу (%s)" % icon("cottage"), command=setSort)
        self.sort4=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По возвещателю", text="По возвещателю (☺)", command=setSort)        
        self.sort5=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По дате сдачи", text="По дате сдачи (%s)" % icon("calendar"), command=setSort)
        self.sort6=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По числу обработок", text="По числу обработок (%s)" % icon("worked"), command=setSort)
        self.sort7=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По заметке", text="По заметке (%s)" % icon("note"), command=setSort)
        self.sort1.grid(column=0, row=0, padx=5, pady=3, sticky="w")
        self.sort2.grid(column=0, row=1, padx=5, pady=3, sticky="w")
        self.sort3.grid(column=0, row=2, padx=5, pady=3, sticky="w")
        self.sort4.grid(column=0, row=3, padx=5, pady=3, sticky="w")
        self.sort5.grid(column=0, row=4, padx=5, pady=3, sticky="w")
        self.sort6.grid(column=0, row=5, padx=5, pady=3, sticky="w")
        self.sort7.grid(column=0, row=6, padx=5, pady=3, sticky="w")
        
        # Footer
        self.statusBar = tk.Label(text="Последнее сохранение: ", fg="gray20")
        self.statusBar.grid(column=0, columnspan=2, row=6, sticky="w")
        ttk.Separator(parent, orient='horizontal').grid (column=0, row=5, columnspan=2, sticky='swe')
        ttk.Sizegrip(parent).grid(column=1, row=6, sticky="se")                
        
        self.update()
        d.save(self)
        
    def update(self, sort="default"):
        """ Redraw ter list and update all stats """
            
        if sort=="default": sort = str(self.sortType.get()) # sort
        if sort=="По дате сдачи": db.sort(key=lambda x: x.dateReturned, reverse=False) 
        if sort=="По номеру": db.sort(key=lambda x: x.number, reverse=False) 
        if sort=="По типу": db.sort(key=lambda x: x.type, reverse=False) 
        if sort=="По адресу": db.sort(key=lambda x: x.address, reverse=False) 
        if sort=="По возвещателю": db.sort(key=lambda x: x.publisher, reverse=False) 
        if sort=="По числу обработок": db.sort(key=lambda x: x.worked, reverse=False) 
        if sort=="По заметке": db.sort(key=lambda x: x.note, reverse=False)         
        if sort==None: self.sortType.set(None)
        self.listContent = tk.StringVar(value=tuple(["%d) %s" % (i+1, db[i].retrieve()) for i in range(len(db))])) # fill list        
        self.list.configure(listvariable=self.listContent)    
        worked=0
        year=0
        for i in range(len(db)):            
            if db[i].worked<=0 and self.filterNonWorked.get()==1: # set fg color
                self.list.itemconfig(i, fg="firebrick")
                worked+=1
            else: self.list.itemconfig(i, {"fg":"midnight blue"})            
            try: # count non worked days 
                d0 = datetime.date( int(db[i].dateReturned[0:4]), int(db[i].dateReturned[5:7]), int(db[i].dateReturned[8:10]) )
                ds = time.strftime("%Y-%m-%d", time.localtime())
                d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
                delta = (d1-d0).days
            except: delta=None
            if delta==None or delta>365: year+=1
            if self.filterYear.get()==1 and (delta==None or delta>365): self.list.itemconfig(i, {"bg":'yellow2'}) # set bg color
            elif i % 2 == 0: self.list.itemconfig(i, bg="cornsilk") # set bg color
            else: self.list.itemconfig(i, bg="gray98")            
        given = nonWorked = 0 # stats
        for number in range(len(db)):
            if db[number].publisher != "": given+=1
            if db[number].worked==0: nonWorked+=1
        self.stat1["text"] = "Всего участков:\t\t%d" % len(db)
        self.stat2["text"] = "В картотеке:\t\t%d" % (len(db)-given)        
        self.stat3["text"] = "На руках:\t\t%d (%d%%)" % (given, (given/len(db))*100)
        self.stat4["text"] = "Не обработано:\t\t%d (%d%%)" % (nonWorked, (nonWorked/len(db))*100)
        self.stat5["text"] = "Не обработано за год:\t%d (%d%%)" % (year, (year/len(db))*100)
