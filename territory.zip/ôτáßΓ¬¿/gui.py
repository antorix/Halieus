﻿import tkinter as tk
from tkinter import ttk
import data as d
from data import db
title = "Участки v0.9"
#import tkinter.messagebox as mb

class GUI:    
    
    def __init__(self, parent):

        # Window saet up         
        w = 800
        h = 600
        ws = parent.winfo_screenwidth()
        hs = parent.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        parent.minsize(300,200)
        parent.iconbitmap("icon.ico")
        parent.title(title)
        ttk.Sizegrip(parent).grid(column=1, row=3, sticky="se")                
        
        # Grid set up        
        parent.grid_columnconfigure (0, weight=5)
        parent.grid_columnconfigure (1, weight=0)
        parent.grid_rowconfigure    (0, weight=1)
        parent.grid_rowconfigure    (1, weight=1)
        parent.grid_rowconfigure    (2, weight=0)
        parent.grid_rowconfigure    (3, weight=0)
        
        # Main list        
        self.list = tk.Listbox(parent, font="arial 10", relief="flat")        
        self.list.grid(column=0, row=0, rowspan=3, padx=3, pady=3, sticky="nwes")        
        
        def select(event):
            #mb.showinfo("Ваш любимый язык", "Да-да, мы поняли")
            widget = event.widget
            selection=widget.curselection()
            value = widget.get(selection[0])
            selected = int(value[:value.index(")")])-1
            db[selected].show(self)
            
        #self.list.bind("<<ListboxSelect>>", select)
        self.list.bind("<Double-Button-1>", select)
        self.list.bind("<Return>", select)
        
        # Statistics        
        self.statsFrame=ttk.LabelFrame(parent, text="Статистика")
        self.statsFrame.grid(column=1, row=0, padx=3, pady=3, sticky="nwes")
        self.stats=tk.Message(self.statsFrame, width=150, font="Courier 9")
        self.stats.grid(padx=10, pady=10)
        
        # Sort buttons
        ttk.LabelFrame(parent, text="Сортировка").grid(column=1, row=1, padx=3, pady=3, sticky="nwes")
                
        # New ter
        def newTer(): d.newTer(self, parent)
        ttk.Button(parent, text="Новый участок", command=newTer).grid(column=1, row=2, padx=3, pady=10, ipadx=5, ipady=5)        
        
        self.update()
        
    def update(self):
        """ Redraw ter list and update all stats """
        given = 0
        for number in range(len(db)):
            if db[number].publisher != "": given+=1
        db.sort(key=lambda x: x.dateReturned, reverse=False) # sort by date returned
        self.list.delete(0, len(db))
        for i in range(len(db)): self.list.insert(i, "%d)  %s" % (i+1, db[i].retrieve()))
        self.stats["text"] = "Всего участков:\t%d\nВ картотеке:\t%d\nУ возвещателей:\t%d (☺)" % (len(db), len(db)-given, given)
        d.save()
