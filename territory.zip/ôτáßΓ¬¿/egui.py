﻿"""
API
===
"""
eg_version = __doc__.split()[1]


import os
import sys
import string
import webbrowser
import time
from tkinter import *
from tkinter import ttk 
runningPython3 = True
basestring = str

def write(*args):
    args = [str(arg) for arg in args]
    args = " ".join(args)
    sys.stdout.write(args)

def writeln(*args):
    write(*args)
    sys.stdout.write("\n")

PROPORTIONAL_FONT_FAMILY = ("Courier New")
MONOSPACE_FONT_FAMILY = ("Courier New")

PROPORTIONAL_FONT_SIZE = 9
MONOSPACE_FONT_SIZE = 9  # a little smaller, because it it more legible at a smaller size
TEXT_ENTRY_FONT_SIZE = 9  # a little larger makes it easier to see

STANDARD_SELECTION_EVENTS = ["Return", "Button-1", "space"]

# Initialize some global variables that will be reset later
__choiceboxMultipleSelect = None
__replyButtonText = None
__choiceboxResults = None
__firstWidget = None
__enterboxText = None
__enterboxDefaultText = ""
__multenterboxText = ""
choiceboxChoices = None
choiceboxWidget = None
entryWidget = None
boxRoot = None

#-------------------------------------------------------------------
# multenterbox
#-------------------------------------------------------------------
def multenterbox(msg="Fill in values for the fields."
                 , title=" "
                 , fields=()
                 , values=()
                 , neutralButton=False):
    return __multfillablebox(msg, title, fields, values, None, neutralButton=neutralButton)


#-----------------------------------------------------------------------
# __multfillablebox
#-----------------------------------------------------------------------
def __multfillablebox(msg="Fill in values for the fields."
                      , title=" "
                      , fields=()
                      , values=()
                      , mask=None
                      , neutralButton=False
                      , self=None):
    global boxRoot, __multenterboxText, __multenterboxDefaultText, cancelButton, entryWidget, okButton

    #choices = ["Ввод", "Отмена"]
    if len(fields) == 0:
        return None

    fields = list(fields[:])  # convert possible tuples to a list
    values = list(values[:])  # convert possible tuples to a list

    #TODO RL: The following seems incorrect when values>fields.  Replace below with zip?
    if len(values) == len(fields):
        pass
    elif len(values) > len(fields):
        fields = fields[0:len(values)]
    else:
        while len(values) < len(fields):
            values.append("")

    boxRoot = Toplevel()
    
    
    w = 620
    h = 350
    ws = boxRoot.winfo_screenwidth()
    hs = boxRoot.winfo_screenheight()
    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2)-40
    boxRoot.minsize(w,h)
    boxRoot.geometry('%dx%d+%d+%d' % (w, h, x, y))
    boxRoot.grab_set() # set as modal
    
    boxRoot.protocol('WM_DELETE_WINDOW', denyWindowManagerClose)
    boxRoot.title(title)
    boxRoot.iconname('Dialog')
    boxRoot.bind("<Escape>", __multenterboxCancel)
    if os.name=="nt": boxRoot.iconbitmap('icon.ico')

    # -------------------- put subframes in the boxRoot --------------------
    messageFrame = ttk.Frame(master=boxRoot)
    messageFrame.pack(side=TOP, fill=BOTH, padx=5, pady=5)
    

    #-------------------- the msg widget ----------------------------
    messageWidget = Message(messageFrame, width="5.5i", text=msg)
    messageWidget.configure(font=(PROPORTIONAL_FONT_FAMILY, PROPORTIONAL_FONT_SIZE))
    

    global entryWidgets
    entryWidgets = list()

    lastWidgetIndex = len(fields) - 1

    for widgetIndex in range(len(fields)):
        argFieldName = fields[widgetIndex]
        argFieldValue = values[widgetIndex]
        entryFrame = ttk.Frame(master=boxRoot)
        entryFrame.pack(side=TOP, fill=BOTH)

        # --------- entryWidget ----------------------------------------------
        
        labelWidget = ttk.Label(entryFrame, text=argFieldName)
        labelWidget.pack(side=LEFT, padx="3m", pady="1m")
        style = ttk.Style()
        style.configure('my.TButton', font=('', 8))
        if "Дата выдачи" in argFieldName:
            def given():
                entryWidgets[3].delete(0,END)
                entryWidgets[3].insert(0, time.strftime("%Y-%m-%d", time.localtime()))
            #cal=PhotoImage(file="cal.png")
            today1 = ttk.Button(entryFrame, text="Сегодня", style='my.TButton', command=given)
            today1.pack(side=RIGHT, padx="3m")
            entryWidget = ttk.Entry(entryFrame, width=43)
        elif "Возвещатель" in argFieldName:
            def clearPublisher(): entryWidgets[4].delete(0,END)                
            #clr=PhotoImage(file="clear.png")
            clear = ttk.Button(entryFrame, text="Очистить", style='my.TButton', command=clearPublisher)
            clear.pack(side=RIGHT, padx="3m")
            entryWidget = ttk.Entry(entryFrame, width=43)
        elif "Дата возврата" in argFieldName:
            def returned():
                entryWidgets[5].delete(0,END)
                entryWidgets[5].insert(0, time.strftime("%Y-%m-%d", time.localtime()))
            today2 = ttk.Button(entryFrame, text="Сегодня", style='my.TButton', command=returned)
            today2.pack(side=RIGHT, padx="3m")
            entryWidget = ttk.Entry(entryFrame, width=43)
        elif "Число обработок" in argFieldName:
            def worked():
                if entryWidgets[6].get()=="": entryWidgets[6].insert(0, 1)
                else:
                    try:
                        new = int(entryWidgets[6].get())
                        entryWidgets[6].delete(0,END)
                        entryWidgets[6].insert(0, str(new+1))
                    except: pass
            #plus=PhotoImage(file="plus.png")
            today2 = ttk.Button(entryFrame, text="+1", style='my.TButton', command=worked)
            today2.pack(side=RIGHT, padx="3m")
            entryWidget = ttk.Entry(entryFrame, width=43)
        elif "Заметка" in argFieldName:
            def clearNote(): entryWidgets[7].delete(0,END)                
            clear = ttk.Button(entryFrame, text="Очистить", style='my.TButton', command=clearNote)
            clear.pack(side=RIGHT, padx="3m")
            entryWidget = ttk.Entry(entryFrame, width=43)
        elif "Файл" in argFieldName:
            def showImage():
                try: webbrowser.open("%s" % entryWidgets[8].get())                  
                except: pass
            #run=PhotoImage(file="run.png")
            show = ttk.Button(entryFrame, text="Открыть", style='my.TButton', command=showImage)
            show.pack(side=RIGHT, padx="3m")
            entryWidget = ttk.Entry(entryFrame, width=43)
        elif "Карта" in argFieldName:
            def showMap(): webbrowser.open(entryWidgets[9].get())                    
            #view=PhotoImage(file="map.png")
            map = ttk.Button(entryFrame, text="Показать", style='my.TButton', command=showMap)
            map.pack(side=RIGHT, padx="3m")
            entryWidget = ttk.Entry(entryFrame, width=43)
        else: entryWidget = ttk.Entry(entryFrame, width=57)
        
        entryWidgets.append(entryWidget)
        entryWidget.configure(font=(PROPORTIONAL_FONT_FAMILY, TEXT_ENTRY_FONT_SIZE))
        entryWidget.pack(side=RIGHT, padx="3m")
        
        def popup(event):
            filemenu.post(event.x_root, event.y_root)
        entryWidget.bind("<Button-3>", popup)

        entryWidget.bind("<Return>", __multenterboxGetText)
        entryWidget.bind("<Escape>", __multenterboxCancel)
        
        # for the last entryWidget, if this is a multpasswordbox,
        # show the contents as just asterisks
        if widgetIndex == lastWidgetIndex:
            if mask:
                entryWidgets[widgetIndex].configure(show=mask)

        # put text into the entryWidget
        entryWidgets[widgetIndex].insert(0, argFieldValue)
        widgetIndex += 1
        

    # ------------------ ok button -------------------------------
    buttonsFrame = Frame(master=boxRoot)
    buttonsFrame.pack(side=BOTTOM, fill=BOTH)
    #buttonsFrame.grid(column=0, row=10)

    okButton = ttk.Button(buttonsFrame, takefocus=1, text="OK")
    bindArrows(okButton)
    okButton.pack(expand=1, side=LEFT, padx='3m', pady='3m', ipadx='2m', ipady='1m')

    # for the commandButton, bind activation events to the activation event handler
    commandButton = okButton
    handler = __multenterboxGetText
    for selectionEvent in STANDARD_SELECTION_EVENTS:
        commandButton.bind("<%s>" % selectionEvent, handler)
        
    # ------------------ delete button -------------------------------
    if neutralButton==True:
        deleteButton = ttk.Button(buttonsFrame, takefocus=1, text="Удалить")
        bindArrows(deleteButton)
        deleteButton.pack(expand=1, side=LEFT, padx='3m', pady='3m', ipadx='2m', ipady='1m')

        # for the commandButton, bind activation events to the activation event handler
        commandButton = deleteButton
        handler = __multenterboxDelete            
        #if(mb.askyesno("Участки", "Точно удалить участок %s?"))==True:
        for selectionEvent in STANDARD_SELECTION_EVENTS:
            commandButton.bind("<%s>" % selectionEvent, handler)


    # ------------------ cancel button -------------------------------
    cancelButton = ttk.Button(buttonsFrame, takefocus=1, text="Отмена")
    bindArrows(cancelButton)
    cancelButton.pack(expand=1, side=LEFT, padx='3m', pady='3m', ipadx='2m', ipady='1m')

    # for the commandButton, bind activation events to the activation event handler
    commandButton = cancelButton
    handler = __multenterboxCancel
    for selectionEvent in STANDARD_SELECTION_EVENTS:
        commandButton.bind("<%s>" % selectionEvent, handler)

    # Context menu

    menubar = Menu(entryFrame)
    filemenu = Menu(menubar, tearoff=0)
    def insert():
        clipboard = boxRoot.selection_get(selection = "CLIPBOARD")
        #entryWidgets[widgetIndex].insert(0,clipboard)
        #print(clipboard)
    #filemenu.add_command(label="Вставить", command=insert)
    def clear(event):
        entryWidget.delete(0,END)    
    #filemenu.add_command(label="Очистить", command=clear)
    editmenu = Menu(menubar, tearoff=0)
        
        
    editmenu = Menu(menubar, tearoff=0)
    def clearAll():
        for i in range(10): entryWidgets[i].delete(0,END)
    #filemenu.add_separator()
    filemenu.add_command(label="Очистить все поля", command=clearAll)
    editmenu = Menu(menubar, tearoff=0)


    # ------------------- time for action! -----------------
    entryWidgets[0].focus_force()  # put the focus on the entryWidget
    boxRoot.mainloop()  # run it!

    # -------- after the run has completed ----------------------------------
    boxRoot.destroy()  # button_click didn't destroy boxRoot, so we do it now
    return __multenterboxText


#-----------------------------------------------------------------------
# __multenterboxGetText
#-----------------------------------------------------------------------
def __multenterboxGetText(event):
    global __multenterboxText

    __multenterboxText = list()
    for entryWidget in entryWidgets:
        __multenterboxText.append(entryWidget.get())
    boxRoot.quit()


def __multenterboxCancel(event):
    global __multenterboxText
    __multenterboxText = None
    boxRoot.quit()
    
def __multenterboxDelete(event):
    global __multenterboxText    
    __multenterboxText = "delete"    
    boxRoot.quit()


def __enterboxGetText(event):
    global __enterboxText

    __enterboxText = entryWidget.get()
    boxRoot.quit()


def __enterboxRestore(event):
    global entryWidget

    entryWidget.delete(0, len(entryWidget.get()))
    entryWidget.insert(0, __enterboxDefaultText)


def __enterboxCancel(event):
    global __enterboxText

    __enterboxText = None
    boxRoot.quit()


def denyWindowManagerClose():
    """ don't allow WindowManager close
    """
    x = Tk()
    x.withdraw()
    x.bell()
    x.destroy()

def bindArrows(widget):

    widget.bind("<Down>", tabRight)
    widget.bind("<Up>", tabLeft)

    widget.bind("<Right>", tabRight)
    widget.bind("<Left>", tabLeft)


def tabRight(event):
    boxRoot.event_generate("<Tab>")


def tabLeft(event):
    boxRoot.event_generate("<Shift-Tab>")


def __choiceboxGetChoice(event):
    global boxRoot, __choiceboxResults, choiceboxWidget

    if __choiceboxMultipleSelect:
        __choiceboxResults = [choiceboxWidget.get(index) for index in choiceboxWidget.curselection()]
    else:
        choice_index = choiceboxWidget.curselection()
        __choiceboxResults = choiceboxWidget.get(choice_index)

    boxRoot.quit()

def __choiceboxNew(event):
    """ Create new territory """
    global boxRoot, __choiceboxResults, choiceboxWidget
    __choiceboxResults="new"
    boxRoot.quit()    
    

def __choiceboxCancel(event):
    global boxRoot, __choiceboxResults

    __choiceboxResults = None
    boxRoot.quit()


def KeyboardListener(event):
    global choiceboxChoices, choiceboxWidget
    key = event.keysym
    if len(key) <= 1:
        if key in string.printable:
            # Find the key in the list.
            # before we clear the list, remember the selected member
            try:
                start_n = int(choiceboxWidget.curselection()[0])
            except IndexError:
                start_n = -1

            ## clear the selection.
            choiceboxWidget.selection_clear(0, 'end')

            ## start from previous selection +1
            for n in range(start_n + 1, len(choiceboxChoices)):
                item = choiceboxChoices[n]
                if item[0].lower() == key.lower():
                    choiceboxWidget.selection_set(first=n)
                    choiceboxWidget.see(n)
                    return
            else:
                # has not found it so loop from top
                for n, item in enumerate(choiceboxChoices):
                    if item[0].lower() == key.lower():
                        choiceboxWidget.selection_set(first=n)
                        choiceboxWidget.see(n)
                        return

                # nothing matched -- we'll look for the next logical choice
                for n, item in enumerate(choiceboxChoices):
                    if item[0].lower() > key.lower():
                        if n > 0:
                            choiceboxWidget.selection_set(first=(n - 1))
                        else:
                            choiceboxWidget.selection_set(first=0)
                        choiceboxWidget.see(n)
                        return

                # still no match (nothing was greater than the key)
                # we set the selection to the first item in the list
                lastIndex = len(choiceboxChoices) - 1
                choiceboxWidget.selection_set(first=lastIndex)
                choiceboxWidget.see(lastIndex)
                return
