import pickle
#import time
from egui import multenterbox
fieldNames=("Номер", "Тип", "Адрес", "Дата выдачи (ГГГГ-ММ-ДД)", "Возвещатель", "Дата возврата (ГГГГ-ММ-ДД)", "Число обработок", "Заметка", "Файл", "Карта")

class Ter(): # territory class
    number=""           # 0
    type=""             # 1
    address=""          # 2
    dateGiven=""        # 3
    publisher=""        # 4
    dateReturned=""     # 5
    worked=0            # 6
    note=""             # 7
    image=""            # 8
    map=""              # 9
    history=[]          
    extra=[]            

    def __init__(self, fields): # create/update ter
        #if fields[5]=="": fields[5] = time.strftime("%Y-%m-%d", time.localtime()) # fill some fields if empty
        if fields[8]=="": fields[8] = fields[0]+".png"
        if fields[9]=="": fields[9] = "https://yandex.ru/maps/?text=%s" % fields[2]     
        self.number = fields[0].strip()
        self.type = fields[1].strip()
        self.address = fields[2].strip()
        self.dateGiven = fields[3].strip()
        self.publisher = fields[4].strip()
        self.dateReturned = fields[5].strip()        
        try: self.worked = int(fields[6].strip())
        except: pass        
        self.note = fields[7].strip()
        self.image = fields[8].strip()
        self.map = fields[9].strip()
        
    def retrieve(self):
        """ How to show individual ter line in list """
        
        if self.number != "": ifNumber = "№%s" % self.number
        else: ifNumber = ""
        if self.type != "": ifType = "  ●%s" % self.type
        else: ifType = ""
        if self.address != "": ifAddress = "   \u2302%s" % self.address
        else: ifAddress = ""
        if self.dateReturned != "": ifReturned = "   ↓%s" % self.dateReturned
        else: ifReturned=""
        if self.publisher != "": ifPublisher = "   ☺%s" % self.publisher
        else: ifPublisher = ""
        if self.worked != 0: ifWorked = "   ↔%d" % self.worked
        else: ifWorked = ""
        
        return ifNumber+ifType+ifAddress+ifReturned+ifPublisher+ifWorked
    
    def show(self, gui):
        fields = multenterbox("", "Участок %s" % self.number, 
                    fieldNames,
                    [self.number, self.type, self.address, self.dateGiven, self.publisher, self.dateReturned, self.worked, self.note, self.image, self.map],
                    neutralButton=True
            )
        if fields==None: return
        elif fields=="delete": return "delete"
        else: self.__init__(fields)
        gui.update()        

def newTer(gui, window): 
    """ Create new territory """    
    fields = multenterbox("", "Новый участок", fieldNames)
    if fields==None: return
    db.append(Ter(fields))
    gui.update()
    save()
    
def load():
    try:
        with open("data.pkl", "rb") as file: db = pickle.load(file) # load database 
    except:
        print("file not found")
        db=[] # if none, create blank list"""
    return db

def save():
    """ Save database """
    with open("data.pkl", "wb") as file: pickle.dump(db, file) # save database
    
#global db
db = load()
