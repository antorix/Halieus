----- RUSSIAN -----

Halieus не требует установки, но необходимо установить движок Python. В Windows для этого достаточно запустить файл «УСТАНОВКА-INSTALL». Проверьте соединение с Интернетом – будет дополнительно загружено примерно 13 МБ. Сама программа запускается файлом Halieus.pyw. Если обычный двойной щелчок мыши не работает, откройте правым щелчком контекстное меню и там Открыть с помощью – Python. Можно создать ярлык на рабочем столе с помощью прилагаемой иконки (файл "icon.ico").

Если при запуске файла Halieus.pyw в Windows возникает ошибка типа «Отсутствует файл api-ms-win-crt-runtime-l1-1-0.dl», см. здесь:
https://helpx.adobe.com/ru/creative-cloud/kb/error_on_launch.html

LINUX

В Ubuntu Linux введите:

sudo apt-get install idle3

Затем откройте файл Halieus.pyw через IDLE3 и нажмите F5.

MAC

В OS X установите Python по ссылке:

https://www.python.org/ftp/python/3.6.0/python-3.6.0-macosx10.6.pkg

Затем необходимо установить TCL по ссылке:

http://www.activestate.com/activetcl/downloads/thank-you?dl=http://downloads.activestate.com/ActiveTcl/releases/8.5.18.0/ActiveTcl8.5.18.0.298892-macosx10.5-i386-x86_64-threaded.dmg 

Затем откройте файл Halieus.pyw через IDLE3 и нажмите F5.

----- ENGLISH -----

Halieus doesn't require installation, but the Python engine must be installed. In Windows, just launch the file "УСТАНОВКА-INSTALL". Check your Internet connection: about 13 Mb will be downloaded. Then run the program by opening the file Halieus.pyw. If a regular double click doesn't work, open the context menu with a right click and then Open with – Python. You can create a shortcut on your desktop using the included icon (file "icon.ico").

If after launching Halieus.pyw in Windows you get an error like "The program can't start because api-ms-win-crt-runtime-l1-1-0.dll is missing from your computer," please see here:
https://helpx.adobe.com/en/creative-cloud/kb/error_on_launch.html

LINUX

In Ubuntu Linux type:

sudo apt-get install idle3

Then open the file Halieus.pyw via IDLE3 and press F5.

MAC

In OS X install Python using the link:

https://www.python.org/ftp/python/3.6.0/python-3.6.0-macosx10.6.pkg

Then install TCL:

http://www.activestate.com/activetcl/downloads/thank-you?dl=http://downloads.activestate.com/ActiveTcl/releases/8.5.18.0/ActiveTcl8.5.18.0.298892-macosx10.5-i386-x86_64-threaded.dmg 

Then open the file Halieus.pyw via IDLE3 and press F5.