import os

def icon(pic):
    if os.name=="nt":
        if pic=="note":         return "\ud83d\udcc4" 
        elif pic=="cottage":    return "\ud83c\udfe0"
        elif pic=="calendar":   return "\ud83d\udcc5"
        elif pic=="worked":     return "\ud83d\udd03"   
        elif pic=="plus":       return "\u2716"
        elif pic=="cut":        return "\u2702"     
        elif pic=="type":       return "\ud83d\udcbc"  
        elif pic=="globe":      return "\uD83C\uDF0D"      
        elif pic=="сheck":      return "\u2714"   
        elif pic=="clock":      return "\u231A"   
        elif pic=="warning":    return "\u26A0"   
        else: return ""
        
    else:
        if pic=="note":         return "☼"
        elif pic=="cottage":    return "⌂"
        elif pic=="calendar":   return "↓"
        elif pic=="worked":     return "↔"
        elif pic=="plus":       return "+"
        elif pic=="type":       return "▪"
        elif pic=="globe":      return "○"
        elif pic=="сheck":      return "√"
        elif pic=="clock":      return "○"           
        elif pic=="warning":    return " !"
        else: return ""
