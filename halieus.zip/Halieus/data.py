#!/usr/bin/python
# -*- coding: utf-8 -*-
import pickle
import tkinter.messagebox as mb
import data as d
from icons import icon
import tercard
import datetime
import time
import os
import urllib.request
import zipfile

class Ter(): # territory class

    def __init__(self, root, number="", type="", address="", note="", image="", map="", worked=False):
        self.number=number
        self.type=type
        self.address=address
        self.note=note
        self.map=map
        self.image=image
        self.works=[]
        self.extra=[]
        
        if worked==True:            
            self.give("?", root, silent=True)
            self.submit(root, silent=True)
        
    def retrieve(self):
        """ How to show individual ter line in list """
        if self.getStatus()==0: status = "%s " % icon("сheck")
        elif self.getStatus()==1: status = "%s " % icon("clock")
        else: status = "%s " % icon("warning")
        if self.number != "": ifNumber = "№%s" % self.number
        else: ifNumber = ""
        if self.number != "": ifNumber = "№%s" % self.number
        else: ifNumber = ""
        if self.type != "": ifType = "   %s%s" % (icon("type"), self.type)
        else: ifType = ""
        if self.address != "": ifAddress = "   %s%s" % (icon("cottage"), self.address)
        else: ifAddress = ""
        if self.getDate2() != "": ifReturned = "   %s%s" % (icon("calendar"), self.getDate2())
        else: ifReturned=""
        if self.getPublisher() != "" and self.getStatus()!=0: ifPublisher = "   ☺%s" % self.getPublisher()
        else: ifPublisher = ""
        if self.getWorks()!= 0: ifWorked = "   %s%d" % (icon("worked"), self.getWorks())
        else: ifWorked = ""
        if self.note != "": ifNote = "   %s%s" % (icon("note"), self.note)
        else: ifNote = ""        
        return status+ifNumber+ifType+ifAddress+ifReturned+ifPublisher+ifWorked+ifNote

    def show(self, root, new=False):
        tercard.terCard(self, root, new=new)        
    
    def getStatus(self):
        if len(self.works)==0 or self.getDate2()!="": return 0
        elif self.getDate2()=="" and self.getDelta1()<180: return 1
        else: return 2
        
    def getWorks(self):
        """ Return number of works """
        if len(self.works)==0: result=0
        elif self.works[len(self.works)-1][2]!="": result=len(self.works)
        else: result=len(self.works)-1
        return result
        
    def getPublisher(self):
        """ Return publisher of last work, if exists """
        if len(self.works)==0: return ""
        else: return self.works[len(self.works)-1][0]
        
    def getCurrentPublisher(self):
        """ Return current publisher, if he works on ter """
        if self.getDate1()!="" and self.getDate2()=="": return self.getPublisher()
        else: return ""
       
    def getDate1(self):
        """ Return date 1 of last work, if exists """
        if len(self.works)==0: return ""
        else: return self.works[len(self.works)-1][1]
        
    def getDate2(self):
        """ Return date 2 of last work, if exists """
        if len(self.works)==0: return ""
        elif self.works[len(self.works)-1][2]!="": return self.works[len(self.works)-1][2]
        elif len(self.works)>1 and self.works[len(self.works)-2][2]!="": return self.works[len(self.works)-2][2]
        else: return ""
        
    def getDate2Prev(self):
        """ Return date 2 of previous to last work, if exists """
        return self.works[len(self.works)-2][2]
        
    def give(self, name, root, silent=False, fromTerCard=False):
        if root.chosenPublisher.get().strip()=="" and silent==False: mb.showwarning("Ошибка выдачи участка", "Необходимо ввести имя возвещателя внизу главной страницы.") 
        elif self.getStatus()!=0: mb.showwarning("Ошибка выдачи участка", "Участок %s уже выдан возвещателю %s %s. Сначала необходимо сдать его." % (self.number, self.getPublisher(), self.getDate1()))
        elif silent==False:
            answer=mb.askyesno("Выдача участка", "Выдать участок %s возвещателю %s в дату %s?" % (self.number, name, root.chosenDate.get().strip()))
            if answer==True:
                self.works.append([name, root.chosenDate.get().strip(), ""])
                if fromTerCard==False: root.save()
        else: self.works.append([name, root.chosenDate.get().strip(), ""])            
        
    def submit(self, root, silent=False, fromTerCard=False):
        if root.chosenDate.get().strip()=="": mb.showwarning("Ошибка сдачи участка", "Необходимо ввести корректную дату внизу главной страницы.")
        elif self.getStatus()==0: mb.showwarning("Ошибка сдачи участка", "Участок %s находится в картотеке и никому не выдан." % self.number)
        elif silent==False:
            answer = mb.askyesno("Сдача участка", "Сдать (вернуть в картотеку) участок %s возвещателя %s в дату %s?" % (self.number, self.getPublisher(), root.chosenDate.get()))
            if answer==True:
                self.works[len(self.works)-1][2]=root.chosenDate.get().strip()
                if fromTerCard==False: root.save()
        else: self.works[len(self.works)-1][2]=root.chosenDate.get().strip()

    def getDelta1(self):
        """ Calculates number of days since last date1 of selected ter """
        try: 
            d0 = datetime.date( int(d.convert(self.getDate1())[0:4]), int(d.convert(self.getDate1())[5:7]), int(d.convert(self.getDate1())[8:10]) )
            ds = time.strftime("%Y-%m-%d", time.localtime())
            d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
            return (d1-d0).days
        except: return 999
        
    def getDelta2(self):
        """ Calculates number of days since last date2 of selected ter """
        try: 
            d0 = datetime.date( int(d.convert(self.getDate2())[0:4]), int(d.convert(self.getDate2())[5:7]), int(d.convert(self.getDate2())[8:10]) )
            ds = time.strftime("%Y-%m-%d", time.localtime())
            d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
            return (d1-d0).days
        except:
            try:
                d0 = datetime.date( int(d.convert(self.getDate2Prev())[0:4]), int(d.convert(self.getDate2Prev())[5:7]), int(d.convert(self.getDate2Prev())[8:10]) )
                ds = time.strftime("%Y-%m-%d", time.localtime())
                d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
                return (d1-d0).days
            except: return 999
            
    def exportXLS_List(self):
        return ["%s" % self.number, self.type, self.address, self.note, self.map, self.image]
        
    def exportXLS_S13(self):
        return self.number

def load(filename=""):
    if filename=="": filename="core.hal"
    result=False
    try:
        with open(filename, "rb") as f: db = pickle.load(f)                     # load database 
        if len(db)!=0 and db[0].address=="" and db[0].number=="" and db[0].type=="": pass
        result=True
    except:
        print("no core, create blank")
        db=[]                                                               # if none, create blank list
    settings=[]
    try:
        with open("settings.ini", "r", encoding="utf-8") as file:
            content = [line.rstrip() for line in file]
            settings.append(content[0][content[0].index("=")+1:])
            settings.append(content[1][content[1].index("=")+1:])
            settings.append(content[2][content[2].index("=")+1:])
            settings.append(content[3][content[3].index("=")+1:])
            settings.append(content[4][content[4].index("=")+1:])
    except: 
        print("no settings, create blank")
        settings.append("По номеру алфавитная")                                 # 0 default sort type
        settings.append(1)                                                      # 1 auto update
        settings.append(1)                                                      # 2 grid on list
        settings.append(1)                                                      # 3 images in ters
        settings.append(0)                                                      # 4 large font in list        
    return result, db, settings    

def convert(d):
    """Convert DD-MM-YY date into YYYY-MM-DD"""    
    try: return "20"+d[6]+d[7]+"-"+d[3]+d[4]+"-"+d[0]+d[1]
    except: return ""

def ifInt(char):
    """Check if value is integer"""    
    try: int(char) + 1
    except: return False
    else: return True

def verifyDate(date, silent=False):
    """Return False if date is incorrect, and shows warning"""
    try:
        if  ifInt(date[0])==True and\
            ifInt(date[1])==True and\
            date[2]=="." and\
            ifInt(date[3])==True and\
            ifInt(date[4])==True and\
            date[5]=="." and\
            ifInt(date[6])==True and\
            ifInt(date[7])==True and\
            len(date)==8:        
                correct=True
        else: correct=False
    except: correct=False
    if correct==False and silent==False: mb.showwarning("Неверная дата", "Дата введена неправильно. Проверьте формат: ДД.ММ.ГГ, например 30.12.16.")
    return correct
    
def updateApp(root):
    try:
        print("checking updates")
        file=urllib.request.urlopen("https://raw.githubusercontent.com/antorix/Halieus/master/version.txt")
        version=str(file.read())
        newversion=[int(version[2]), int(version[4]), int(version[6])]
        thisversion=[int(root.currentVersion[0]), int(root.currentVersion[2]), int(root.currentVersion[4])]
        if newversion>thisversion:
            print("new version found!")
            try: urllib.request.urlretrieve("http://github.com/antorix/Halieus/raw/master/update.zip", "update.zip")
            except: print("download failed")
            else: print("download complete")
            try:
                zip=zipfile.ZipFile("update.zip", "r")
                zip.extractall("")
                zip.close()
                os.remove("update.zip")
            except: print("unpacking failed")
            else: print("unpacking complete")            
    except: print("update check failed")
