from icons import icon
import tercard
import tkinter.messagebox as mb
from save import save
import datetime
import time

class Ter(): # territory class

    def __init__(self, gui, db, number="", type="", worked=False):
        self.number=number           
        self.type=type             
        self.address=""          
        self.note=""             
        self.image=""            
        self.map=""                  
        self.works=[]
        self.extra=[]
        
        if worked==True:            
            self.give("?", gui.chosenDate.get(), gui, db, silent=True)
            self.submit(gui.chosenDate.get(), gui, db, silent=True)
        
    def retrieve(self):
        """ How to show individual ter line in list """
        if self.getStatus()==0: status = "%s " % icon("сheck")
        elif self.getStatus()==1: status = "%s " % icon("clock")
        else: status = "%s " % icon("warning")
        if self.number != "": ifNumber = "№%s" % self.number
        else: ifNumber = ""
        if self.number != "": ifNumber = "№%s" % self.number
        else: ifNumber = ""
        if self.type != "": ifType = "   %s%s" % (icon("type"), self.type)
        else: ifType = ""
        if self.address != "": ifAddress = "   %s%s" % (icon("cottage"), self.address)
        else: ifAddress = ""
        if self.getDate2() != "": ifReturned = "   %s%s" % (icon("calendar"), self.getDate2())
        else: ifReturned=""
        if self.getPublisher() != "" and self.getStatus()!=0: ifPublisher = "   ☺%s" % self.getPublisher()
        else: ifPublisher = ""
        if self.getWorks()!= 0: ifWorked = "   %s%d" % (icon("worked"), self.getWorks())
        else: ifWorked = ""
        if self.note != "": ifNote = "   %s%s" % (icon("note"), self.note)
        else: ifNote = ""        
        return status+ifNumber+ifType+ifAddress+ifReturned+ifPublisher+ifWorked+ifNote

    def show(self, gui, window, db, settings):
        tercard.open(self, gui, window, db, settings)
    
    def getStatus(self):
        if len(self.works)==0 or self.getDate2()!="": return 0
        elif self.getDate2()=="" and self.getDelta1()<180: return 1
        else: return 2
        
    def getWorks(self):
        """ Return number of works """
        if len(self.works)==0: result=0
        elif self.works[len(self.works)-1][2]!="": result=len(self.works)
        else: result=len(self.works)-1
        return result
        
    def getPublisher(self):
        """ Return publisher of last work, if exists """
        if len(self.works)==0: return ""
        else: return self.works[len(self.works)-1][0]
       
    def getDate1(self):
        """ Return date 1 of last work, if exists """
        if len(self.works)==0: return ""
        else: return self.works[len(self.works)-1][1]
        
    def getDate2(self):
        """ Return date 2 of last work, if exists """
        if len(self.works)==0: return ""
        else: return self.works[len(self.works)-1][2]
        
    def getDate2Prev(self):
        """ Return date 2 of previous to last work, if exists """
        return self.works[len(self.works)-2][2]
        
    def give(self, name, date, gui, db, silent=False): 
        if self.getStatus()!=0:
            mb.showerror("Ошибка выдачи участка", "Участок %s уже выдан возвещателю %s %s. Сначала необходимо сдать его." % (self.number, self.getPublisher(), self.getDate1()))
            return
        if silent==False:
            answer=mb.askyesno("Выдача участка", "Выдать участок %s возвещателю %s в дату %s?" % (self.number, name, date))
            if answer==True:
                self.works.append([name, date, ""])
                save(gui, db)
        else: self.works.append([name, date, ""])            
        
    def submit(self, date, gui, db, silent=False):
        if self.getStatus()==0:
            mb.showerror("Ошибка сдачи участка", "Участок %s находится в картотеке и никому не выдан" % self.number)
            return
        if silent==False:
            answer = mb.askyesno("Сдача участка", "Сдать (вернуть в картотеку) участок %s возвещателя %s в дату %s?" % (self.number, self.getPublisher(), date))
            if answer==True:
                self.works[len(self.works)-1][2]=date
                save(gui, db)
        else: self.works[len(self.works)-1][2]=date            
            
    def getDelta1(self):
        """ Calculates number of days since last date1 of selected ter """
        try: # count non worked days 
            d0 = datetime.date( int(convert(self.getDate1())[0:4]), int(convert(self.getDate1())[5:7]), int(convert(self.getDate1())[8:10]) )
            ds = time.strftime("%Y-%m-%d", time.localtime())
            d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
            return (d1-d0).days
        except: return 999
        
    def getDelta2(self):
        """ Calculates number of days since last date2 of selected ter """
        try: # count non worked days 
            d0 = datetime.date( int(convert(self.getDate2())[0:4]), int(convert(self.getDate2())[5:7]), int(convert(self.getDate2())[8:10]) )
            ds = time.strftime("%Y-%m-%d", time.localtime())
            d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
            return (d1-d0).days
        except:
            try:
                d0 = datetime.date( int(convert(self.getDate2Prev())[0:4]), int(convert(self.getDate2Prev())[5:7]), int(convert(self.getDate2Prev())[8:10]) )
                ds = time.strftime("%Y-%m-%d", time.localtime())
                d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
                return (d1-d0).days
            except: return 999

def deleteTer(gui, db, settings, all=False):
    """ Delete ters """
    if all==True:
        del db[:]
        save(gui, db)
        return
    selected = gui.list.curselection()
    if len(selected)==0: return
    elif len(selected)==1:
        if mb.askyesno("Удаление", "Удалить участок %s?" % db[selected[0]].number)==True:
            del db[selected[0]]
            save(gui, db)
    else:
        if mb.askyesno("Удаление", "Удалить эти участки (%d)?" % len(selected))==True:
            count=0
            for i in range(len(selected)):
                sel = selected[i]
                del db[sel-count]
                count+=1
            save(gui, db)

def newTer(gui, window, db, settings, number="", type="", silent=False, worked=False): 
    db.append(Ter(gui, db, number=number, type=type, worked=worked))
    if silent==False: tercard.open(db[len(db)-1], gui, window, db, settings, new=True)   

def giveTer(gui, selected, db, settings, ter=False):
    if gui.chosenPublisher.get().strip()=="":
        mb.showerror("Ошибка выдачи участка", "Необходимо ввести имя возвещателя внизу главной страницы.")        
    elif gui.chosenDate.get()=="": mb.showerror("Ошибка выдачи участка", "Необходимо ввести корректную дату внизу главной страницы.")
    else:
        if ter==False:
            for i in range(len(selected)): db[selected[i]].give(gui.chosenPublisher.get().strip(), gui.chosenDate.get(), gui, db)    
        else: ter.give(gui.chosenPublisher.get().strip(), gui.chosenDate.get(), gui, db)    
    
def submitTer(gui, selected, db, settings, ter=False):
    if gui.chosenDate.get()=="": mb.showerror("Ошибка сдачи участка", "Необходимо ввести корректную дату внизу главной страницы.")
    else:
        if ter==False:
            for i in range(len(selected)): db[selected[i]].submit(gui.chosenDate.get(), gui, db)    
        else: ter.submit(gui.chosenDate.get(), gui, db)    

def convert(d):
    """ Convert DD-MM-YY date into YYYY-MM-DD """    
    try: return "20"+d[6]+d[7]+"-"+d[3]+d[4]+"-"+d[0]+d[1]
    except: return ""

def ifInt(char):
    """ Checks if value is integer """    
    try: int(char) + 1
    except: return False
    else: return True
