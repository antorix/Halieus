#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
import pickle
import os
import datetime
from data import Ter
import data as d
import tools
from icons import icon
import time
import webbrowser
import tkinter.messagebox as mb

class Root:    
    
    def __init__(self, parent, load):

        # Load database and settings        
        self.db=load[1]
        self.settings=load[2]
        self.sortType=tk.StringVar()                                          
        self.sortType.set(self.settings[0])
        self.autoUpdate=tk.IntVar()
        self.autoUpdate.set(self.settings[1])
        self.listGrid=tk.IntVar()
        self.listGrid.set(self.settings[2])
        self.images=tk.IntVar()
        self.images.set(self.settings[3])
        self.largeFont=tk.IntVar()
        self.largeFont.set(self.settings[4])
        self.currentVersion="1.0.2"        
 
        # Pictures
        self.imgExcel=tk.PhotoImage(file="images/excel.png")
        self.imgXLS=tk.PhotoImage(file="images/xls.png")
        self.imgCheck=tk.PhotoImage(file="images/check.png")
        self.imgWork=tk.PhotoImage(file="images/work.png")
        self.imgMass=tk.PhotoImage(file="images/mass.png")
        self.imgTimeout=tk.PhotoImage(file="images/timeout.png")        
        self.imgFish=tk.PhotoImage(file="images/fish.png")        
        self.imgFace=tk.PhotoImage(file="images/face.png")        
        self.imgCalendar=tk.PhotoImage(file="images/calendar.png")        
        self.imgOpen=tk.PhotoImage(file="images/open.png")
        self.imgGive=tk.PhotoImage(file="images/give.png")
        self.imgGiveBig=tk.PhotoImage(file="images/givebig.png")
        self.imgSubmit=tk.PhotoImage(file="images/submit.png")
        self.imgSubmitBig=tk.PhotoImage(file="images/submitbig.png")
        self.imgDel=tk.PhotoImage(file="images/delete.png")
        self.imgSearch=tk.PhotoImage(file="images/search.png")
        self.imgNew=tk.PhotoImage(file="images/new.png")
        #self.imgBest=tk.PhotoImage(file="images/bestters.png")        
        
        # Some other values
        self.style = ttk.Style()
        self.style.configure("big.TButton", font=('', 10), color="green")
        self.prevDate=""
        self.tips="\
● Есть два способа быстро добавить много участков: массовое создание и импорт из Excel. Оба находятся в Меню → Инструменты.\n\n\
● Сохранять и загружать данные не нужно, они автоматически загружаются при запуске программы и сохраняются при каждом изменении. Однако можно экспортировать и импортировать базу данных для переноса на другие устройства или резервирования (Меню → Файл).\n\n\
● Программа автоматически создает резервную копию при каждом сохранении (файл \"backup.hal\"). Импортируйте его, если что-то пошло не так.\n\n\
● Программа полностью автоматически, в фоновом режиме обновляет саму себя через Интернет. Вам ничего не нужно делать, при этом размер загружаемых файлов составляет несколько килобайт. Это можно отключить в настройках, но настоятельно не рекомендуется.\n\n\
● К каждому участку можно прикрепить картинку, положив ее в папке программы в формате .png и прописав имя файла в карточке участка. Эту функцию можно отключить в настройках.\n\n\
● Иcпользуйте горячие клавиши: [Insert] – новый участок; [Alt+Home] – выдать участок; [Alt+End] – сдать участок; [Alt+0] – ввести возвещателя.\n\n\
● Если что-то не работает или непонятно, не стесняйтесь писать автору программы через Меню → Помощь → Поддержка. Вам обязательно помогут!"
        
        # Window set up         
        w = parent.winfo_screenwidth()/1.8
        h = parent.winfo_screenheight()/1.3
        ws = parent.winfo_screenwidth()
        hs = parent.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-50
        parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        parent.minsize(250,285)
        if os.name=="nt": parent.iconbitmap("icon.ico")
        parent.title("Halieus")
        parent.grid_columnconfigure (0, weight=1)
        parent.grid_rowconfigure    (3, weight=1)
        self.padx=3
        self.pady=2        
        parent.bind("<Insert>", self.newTer)
        parent.bind("<Alt-Home>", self.giveSelected)
        parent.bind("<Alt-End>", self.submitSelected)
        parent.bind("<Control-f>", self.searchFocus)
        parent.bind("<Alt-0>", self.publisherFocus)
        
        # Main menu
        menubar = tk.Menu(parent)
        filemenu1 = tk.Menu(menubar, tearoff=0)                                 # Файл
        menubar.add_cascade(label="Файл", menu=filemenu1)
        filemenu1.add_command(label="Импорт", compound="left", command=self.importDB) 
        filemenu1.add_command(label="Экспорт", compound="left", command=self.exportDB)
        filemenu1.add_command(label="Очистка", compound="left", command=self.clearDB)
        filemenu1.add_separator()
        filemenu1.add_command(label="Выход", command=parent.quit)
        filemenu2 = tk.Menu(menubar, tearoff=0)                                 # Инструменты
        menubar.add_cascade(label="Инструменты", menu=filemenu2)
        filemenu2.add_command(label="Массовое создание участков", command=self.massCreate)
        filemenu2.add_command(label="Импорт участков из Excel", command=self.importXLS)
        filemenu2.add_command(label="Экспорт данных в Excel", command=self.exportXLS)
        filemenu3 = tk.Menu(menubar, tearoff=0)                                 # Настройки
        menubar.add_cascade(label="Настройки", menu=filemenu3)
        filemenu3.add_checkbutton(label="Автообновление программы", variable=self.autoUpdate, command=self.saveSettings)
        filemenu3.add_checkbutton(label="Сетка списка участков", variable=self.listGrid, command=self.saveSettings)
        filemenu3.add_checkbutton(label="Увеличенный шрифт списка", variable=self.largeFont, command=self.saveSettings)
        filemenu3.add_checkbutton(label="Картинки в участках", variable=self.images, command=self.saveSettings)
        filemenu4 = tk.Menu(menubar, tearoff=0)                                 # Помощь
        menubar.add_cascade(label="Помощь", menu=filemenu4)
        def __showTips(): self.showTips(self.tips, 475)
        filemenu4.add_command(label="Важно знать", command=__showTips)
        filemenu4.add_command(label="Поддержка", command=self.support)
        filemenu4.add_command(label="О программе", command=self.about)
        parent.config(menu=menubar)
  
        # Upper bar 
        self.massFrame=ttk.Frame(parent)                                        
        self.massFrame.grid(column=0, row=0, padx=self.padx, pady=self.pady,\
            sticky="we")                                            
        self.selCount=tk.Label(self.massFrame, fg="MidnightBlue")               # selection count 
        self.selCount.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="w")
        self.massEdit=ttk.Button(self.massFrame, text="Массовая правка",\
            command=self.massEdit)                                              # mass edit
        self.massFrame.grid_columnconfigure(2, weight=1)
        tk.Label(self.massFrame, text="Поиск", fg="gray20").grid(column=3, row=0, padx=3, sticky="e")                          
        self.search=ttk.Entry(self.massFrame, width=30)                         # search  
        self.search.grid(column=4, row=0, sticky="e")
        self.search.focus_force()
        self.search.bind("<Return>", self.find)
        self.searchButton=ttk.Button(self.massFrame, image=self.imgSearch)
        self.searchButton.grid(column=5, row=0, sticky="w")
        self.searchButton.bind("<1>", self.find)
        
        # Main list        
        self.list = tk.Listbox(parent, activestyle="dotbox", width=50, bd=1, selectmode="extended", relief="sunken")
        self.list.grid(column=0, row=1, rowspan=4, padx=self.padx, pady=self.pady, sticky="nwes")  
        rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=rightScrollbar.set)      
        rightScrollbar.pack(side="right", fill="y")
        bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
        self.list.configure(xscrollcommand=bottomScrollbar.set)
        bottomScrollbar.pack(side="bottom", fill="x")
        self.list.bind("<Return>", self.openSelected)
        self.list.bind("<Double-1>", self.openSelected)
        self.list.bind("<<ListboxSelect>>", self.activateButtons)
        self.list.bind("<3>", self.listPopup)
        self.list.bind("<space>", self.listPopup)
        
        # Main list context menu
        listbar = tk.Menu(self.list)
        self.listmenu = tk.Menu(listbar, tearoff=0)
        def __openSingleTer(): self.openSingleTer()        
        self.listmenu.add_command(label=" Открыть", image=self.imgOpen, compound="left", command=__openSingleTer)
        self.listmenu.iconPhotoImage = self.imgOpen
        def __giveSelected(): self.giveSelected()        
        self.listmenu.add_command(label=" Выдать", image=self.imgGive, compound="left", command=__giveSelected)
        self.listmenu.iconPhotoImage = self.imgGive
        def __submitSelected(): self.submitSelected()
        self.listmenu.add_command(label=" Сдать", image=self.imgSubmit, compound="left", command=__submitSelected)
        self.listmenu.iconPhotoImage = self.imgSubmit
        def __deleteSelected(): self.deleteSelected()
        self.listmenu.add_command(label=" Удалить", image=self.imgDel, compound="left", command=__deleteSelected)
        self.listmenu.iconPhotoImage = self.imgDel
        listbar.add_cascade(label="Действия", menu=self.listmenu)                           
        self.list.bind("<Delete>", self.deleteSelected)
        self.list.bind("<BackSpace>", self.deleteSelected)       
        
        # Upper right zone
        self.upperRightZone=ttk.Frame(parent)
        self.upperRightZone.grid(column=1,row=3, padx=self.padx, pady=self.pady, sticky="nwes")
        
        # Statistics        
        self.statsFrame=ttk.LabelFrame(self.upperRightZone, text="Статистика")
        self.statsFrame.grid(column=0, row=0, padx=self.padx, pady=self.pady*3, sticky="nwe")
        ttk.Label(self.statsFrame, text="Всего участков:").grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="w")
        ttk.Label(self.statsFrame, text="В картотеке:").grid(column=0, row=1, padx=self.padx, pady=self.pady, sticky="w")
        ttk.Label(self.statsFrame, text="На руках:").grid(column=0, row=2, padx=self.padx, pady=self.pady, sticky="w")
        ttk.Label(self.statsFrame, text="Обработано за год:").grid(column=0, row=3, padx=self.padx, pady=self.pady, sticky="w")
        ttk.Label(self.statsFrame, text="Не обрабатывалось:").grid(column=0, row=4, padx=self.padx, pady=self.pady, sticky="w")
        self.stat1=ttk.Label(self.statsFrame)
        self.stat2=ttk.Label(self.statsFrame)
        self.stat3=ttk.Label(self.statsFrame)
        self.stat4=ttk.Label(self.statsFrame)
        self.stat5=ttk.Label(self.statsFrame)
        self.stat1.grid(column=1, row=0, padx=self.padx, pady=self.pady, sticky="w")
        self.stat2.grid(column=1, row=1, padx=self.padx, pady=self.pady, sticky="w")
        self.stat3.grid(column=1, row=2, padx=self.padx, pady=self.pady, sticky="w")
        self.stat4.grid(column=1, row=3, padx=self.padx, pady=self.pady, sticky="w")
        self.stat5.grid(column=1, row=4, padx=self.padx, pady=self.pady, sticky="w")        
        self.filterYear = tk.IntVar()
        self.filterYear.set(0)
        ttk.Checkbutton(self.statsFrame, variable=self.filterYear, command=self.update).grid(column=2, row=3, pady=self.pady, sticky="w")                         
        self.filterWorked = tk.IntVar()
        self.filterWorked.set(0)
        ttk.Checkbutton(self.statsFrame, variable=self.filterWorked, command=self.update).grid(column=2, row=4, pady=self.pady, sticky="w")        
        
        # Sorting
        self.sortFrame = ttk.LabelFrame(self.upperRightZone, text="Сортировка")
        self.sortFrame.grid(column=0, row=1, padx=self.padx, pady=self.pady*3, sticky="nwe")
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По номеру алфавитная", text="По номеру алфавитная (№1а)", command=self.setSort).grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="w")
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По номеру числовая", text="По номеру числовая (№1)", command=self.setSort).grid(column=0, row=1, padx=self.padx, pady=self.pady, sticky="w")
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По статусу", text="По статусу (%s)" % icon("сheck"), command=self.setSort).grid(column=0, row=2, padx=self.padx, pady=self.pady, sticky="w")
        self.sort5=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По дате сдачи", text="По давности обработки (%s)" % icon("calendar"), command=self.setSort).grid(column=0, row=3, padx=self.padx, pady=self.pady, sticky="w")
        self.sort6=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По числу обработок", text="По числу обработок (%s)" % icon("worked"), command=self.setSort).grid(column=0, row=4, padx=self.padx, pady=self.pady, sticky="w")
        self.sort2=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По типу", text="По типу (%s)" % icon("type"), command=self.setSort).grid(column=0, row=5, padx=self.padx, pady=self.pady, sticky="w")
        self.sort3=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По адресу", text="По адресу (%s)" % icon("cottage"), command=self.setSort).grid(column=0, row=6, padx=self.padx, pady=self.pady, sticky="w")
        self.sort4=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По возвещателю", text="По возвещателю (☺)", command=self.setSort).grid(column=0, row=7, padx=self.padx, pady=self.pady, sticky="w")      
        self.sort7=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По заметке", text="По заметке (%s)" % icon("note"), command=self.setSort).grid(column=0, row=8, padx=self.padx, pady=self.pady, sticky="w")
        # Advanced statistics
        self.optionSet=ttk.LabelFrame(self.upperRightZone, text="Расширенная статистика")
        #self.optionSet.grid(column=0, row=2, padx=self.padx, pady=self.pady*3, sticky="nwe")
        self.optionSet.grid_columnconfigure(0, weight=1)
        self.optionSet.grid_columnconfigure(1, weight=1)
        ttk.Button(self.optionSet, text="Возвещатели").grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="we")
        ttk.Button(self.optionSet, text="Типы").grid(column=1, row=0, padx=self.padx, pady=self.pady, sticky="we")
        
        # Operations
        self.statsMass=ttk.LabelFrame(parent, text="Действия")
        self.statsMass.grid(column=0, row=5, columnspan=4, padx=self.padx, pady=self.pady, sticky="wns")                
        self.buttonGive = ttk.Button(self.statsMass, text="Выдать", image=self.imgGiveBig, compound="left", command=__giveSelected)
        self.buttonGive.grid(column=0, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")
        self.buttonSubmit = ttk.Button(self.statsMass, text="Сдать", image=self.imgSubmitBig, compound="left", command=__submitSelected)
        self.buttonSubmit.grid(column=1, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")        
        ttk.Separator(self.statsMass, orient='vertical').grid(column=3, row=0, rowspan=2, padx=self.padx*4, pady=self.pady*4, sticky='ns')       
        self.publisherLabel=tk.Label(self.statsMass, image=self.imgFace, compound="left", text="Возвещатель")
        self.publisherLabel.grid(column=4, row=0, padx=self.padx*2.5, pady=0, sticky="ws")
        ttk.Label(self.statsMass, image=self.imgCalendar, compound="left", text="Дата").grid(column=5, row=0, pady=0, columnspan=2, sticky="ws")        
        self.chosenPublisher=ttk.Entry(self.statsMass)
        self.chosenPublisher.grid(column=4, row=1, padx=self.padx*3, pady=5, sticky="wn")
        self.chosenPublisher.bind("<Return>", self.giveSelected)
        self.chosenPublisher.bind("<KeyRelease>", self.publisherNormal)
        self.chosenPublisher.bind("<FocusOut>", self.publisherNormal)
        self.chosenDate=ttk.Entry(self.statsMass, width=8)
        self.chosenDate.grid(column=5, row=1, pady=5, sticky="wn")
        self.chosenDate.bind("<FocusOut>", self.checkDate)                        
        style = ttk.Style()
        style.configure("small3.TButton", font=('', 7))
        ttk.Button(self.statsMass, text="Сегодня", style="small3.TButton", command=self.insertDate).grid(column=6, row=1, padx=5, pady=5, sticky="wn")       
        
        # Bottom right zone
        self.bottomRightZone=ttk.Frame(parent)
        self.bottomRightZone.grid(column=1,row=4, padx=self.padx, pady=self.pady, sticky="wes")
        self.bottomRightZone.grid_columnconfigure(0, weight=1)
        
        # Big buttons
        def __newTer(): self.newTer(event=None)
        #self.bestTers=ttk.Button(self.bottomRightZone, text=" Участки на выдачу", compound="top", style='big.TButton', image=self.imgBest, command=__newTer)
        #self.bestTers.grid                                                                                                                    (column=0, row=0, padx=self.padx*7, pady=self.pady*6, ipadx=10, sticky="we")
        ttk.Button(self.bottomRightZone, text=" Новый участок", compound="left", style='big.TButton', image=self.imgNew, command=__newTer).grid(column=0, row=1, padx=self.padx*7, pady=self.pady, ipadx=10, ipady=10, sticky="we")
        
        # Footer
        self.statusBar = tk.Label(fg="gray20")
        self.statusBar.grid(column=0, columnspan=2, row=6, sticky="w")
        ttk.Separator(parent, orient='horizontal').grid (column=0, row=6, columnspan=2, sticky='nwe')
        ttk.Sizegrip(parent).grid(column=1, row=0, rowspan=7, sticky="se")                
        
        # Startup operations
        self.activateButtons(None)
        self.insertDate()
        self.update()        
        if not os.path.exists("settings.ini"):
            self.showTips("Добро пожаловать в Halieus! Пожалуйста, уделите всего минуту на следующую важную информацию (вы можете вернуться к ней позже в Меню → Помощь).\n\n" + self.tips, 530)
            self.saveSettings()       
        
    # FUNCTIONS ---------------------------------------------------------------------------    
    
    def support(self): webbrowser.open("http://halieus.blogspot.com/")
    def publisherNormal(self, event=None): self.publisherLabel["fg"] = "black"
    def massCreate(self): tools.massCreate(self)
    def importXLS(self): tools.importXLS(self)
    def searchFocus(self, event=None): self.search.focus_force()
    def publisherFocus(self, event=None): self.chosenPublisher.focus_force()
    def exportXLS(self): tools.exportXLS(self)
    def massEdit(self): tools.massEdit(self)   
    
    def update(self, sort="unchanged"):
        """ Redraw ter list and update all stats """        
        if sort=="unchanged": sort = str(self.sortType.get())                   # sort
        if sort=="По дате сдачи": self.db.sort(key=lambda x: d.convert(x.getDateLastSubmit()), reverse=False) 
        elif sort=="По номеру числовая":
            try: self.db.sort(key=lambda x: float(x.number), reverse=False) 
            except:
                mb.showwarning("Ошибка сортировки", "В номерах участков используются нецифровые символы либо пустые номера, поэтому числовая сортировка невозможна. Переключаюсь на алфавитную.")
                sort="По номеру алфавитная"
                self.sortType.set("По номеру алфавитная")
                self.settings[0]=str(self.sortType.get())
                self.saveSettings()
                self.db.sort(key=lambda x: x.number, reverse=False)                
        elif sort=="По номеру алфавитная": self.db.sort(key=lambda x: x.number, reverse=False) 
        elif sort=="По статусу": self.db.sort(key=lambda x: x.getStatus(), reverse=True) 
        elif sort=="По типу": self.db.sort(key=lambda x: x.type, reverse=False) 
        elif sort=="По адресу": self.db.sort(key=lambda x: x.address, reverse=False) 
        elif sort=="По возвещателю": self.db.sort(key=lambda x: x.getCurrentPublisher(), reverse=False) 
        elif sort=="По числу обработок": self.db.sort(key=lambda x: x.getWorks(), reverse=False) 
        elif sort=="По заметке": self.db.sort(key=lambda x: x.note, reverse=False)         
        else: self.sortType.set(None)
        self.listContent = tk.StringVar(value=tuple([" %d) %s" % (i+1, self.db[i].retrieve()) for i in range(len(self.db))])) # fill list        
        self.list.configure(listvariable=self.listContent)
        if self.largeFont.get()==0: self.list["font"]="Tahoma 9"
        else: self.list["font"]="Tahoma 11"
        self.worked=self.year=self.given=self.nonWorked=0                       # calculate stats
        for i in range(len(self.db)):
            delta2=self.db[i].getDelta2()            
            if self.db[i].getWorks()<=0 and self.filterWorked.get()==1:         
                self.list.itemconfig(i,                 fg="red")               # color for non-worked ters
                self.worked+=1
            else: self.list.itemconfig(i,               fg="gray15")            # color for regular ters
            if delta2<365: self.year+=1
            if self.filterYear.get()==1 and delta2<365: self.list.itemconfig(i, bg='PaleGreen')
            elif i % 2 == 0: self.list.itemconfig(i,                bg="white") # 2 bg colors for stripes
            else:
                if self.listGrid.get()==1: self.list.itemconfig(i,  bg="#e8f0ff")
                else: self.list.itemconfig(i,                       bg="white")            
            if self.db[i].getPublisher()!="" and self.db[i].getStatus()!=0: self.given+=1
            if self.db[i].getWorks()==0: self.nonWorked+=1            
        self.stat1["text"] = "%d" % len(self.db)             
        self.stat2["text"] = "%d" % (len(self.db)-self.given)        
        try: self.stat3["text"] = "%d (%d%%)" % (self.given, (self.given/len(self.db))*100)
        except: self.stat3["text"] = "0"
        try: self.stat4["text"] = "%d (%d%%)" % (self.year, (self.year/len(self.db))*100)
        except: self.stat4["text"] = "0"
        try: self.stat5["text"] = "%d (%d%%)" % (self.nonWorked, (self.nonWorked/len(self.db))*100)
        except: self.stat5["text"] = "0"
        try: self.statusBar["text"] = "Последнее изменение базы данных: %s        " % datetime.datetime.fromtimestamp(os.path.getmtime("core.hal")) # last core save
        except: pass
    
    def about(self):
        about=tk.Toplevel(bg="white")
        about.focus_force()
        about.grab_set()
        w = 440
        h = 200
        ws = about.winfo_screenwidth()
        hs = about.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        about.geometry('%dx%d+%d+%d' % (w, h, x, y))
        about.minsize(w,h)
        about.title("О программе")
        if os.name=="nt": about.iconbitmap("images/about.ico")
        def quit(event): about.destroy()
        about.bind("<Escape>", quit)
        ttk.Label(about, image=self.imgFish, background="white", borderwidth=0).grid(column=0, row=2, rowspan=6, padx=self.padx*7, pady=self.pady, sticky="")
        ttk.Label(about, text="Halieus %s" % self.currentVersion, background="white", font="Arial 11 bold").grid(column=1, row=2, padx=self.padx, pady=self.pady*5, sticky="w")
        email=tk.Label(about, background="white", font="Arial 10 underline", text="antorix@gmail.com", cursor="hand2")
        email.grid(column=1, row=3, padx=self.padx, pady=self.pady*2, sticky="w")
        def mailto(event): webbrowser.open("mailto:antorix@gmail.com")
        email.bind("<Button-1>", mailto)
        web=tk.Label(about, background="white", font="Arial 10 underline", text="halieus.blogspot.com", cursor="hand2")
        web.grid(column=1, row=4, padx=self.padx, pady=self.pady*2, sticky="w")
        def openWeb(event): webbrowser.open("http://halieus.blogspot.com/")
        web.bind("<Button-1>", openWeb)
        ttk.Label(about, background="white", font="Arial 10", text="Лицензия GNU GPL").grid(column=1, row=5, padx=self.padx, pady=self.pady*2, sticky="w")
        ttk.Label(about, background="white", font="Arial 10 italic", text=
"Иисус сказал им: «Идите за мной,\n\
и я сделаю вас ловцами (греч. halieus)\n\
людей» (Мк. 1:17)\n\n").grid(column=1, row=6, padx=self.padx, pady=self.pady*2, sticky="w")
        
    def showTips(self, text, height):
        tip=tk.Toplevel(bg="white")
        tip.focus_force()
        tip.grab_set()
        tk.Message(tip, width=390, text=text, background="white").pack(padx=self.padx*2, pady=self.pady*2, expand=True)
        w = 410
        h = height
        ws = tip.winfo_screenwidth()
        hs = tip.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        tip.geometry('%dx%d+%d+%d' % (w, h, x, y))
        tip.minsize(w,h)
        tip.title("Важно знать")
        if os.name=="nt": tip.iconbitmap("images/info.ico")
        def quit(event): tip.destroy()
        tip.bind("<Escape>", quit)
        
    def listPopup(self, event=None):
        if len(self.list.curselection())==0:
            self.listmenu.entryconfig(" Открыть", state="disabled")
            self.listmenu.entryconfig(" Выдать", state="disabled")
            self.listmenu.entryconfig(" Сдать", state="disabled")
            self.listmenu.entryconfig(" Удалить", state="disabled")
        elif len(self.list.curselection())==1:
            self.listmenu.entryconfig(" Открыть", state="normal")
            self.listmenu.entryconfig(" Выдать", state="normal")
            self.listmenu.entryconfig(" Сдать", state="normal")
            self.listmenu.entryconfig(" Удалить", state="normal")
        else:
            self.listmenu.entryconfig(" Открыть", state="disabled")
            self.listmenu.entryconfig(" Выдать", state="normal")
            self.listmenu.entryconfig(" Сдать", state="normal")
            self.listmenu.entryconfig(" Удалить", state="normal")
        self.listmenu.post(event.x_root, event.y_root)
        
    def entryPopup(self): pass
    
    def saveSettings(self):
        result=False
        while result!=True:
            try:
                with open("settings.ini", "w", encoding="utf-8") as file:
                    file.write( "Sort type="    + str(self.sortType.get())  +"\n"+\
                                "Auto update="  + str(self.autoUpdate.get())+"\n"+\
                                "List grid="    + str(self.listGrid.get())  +"\n"+\
                                "Images in cards="+ str(self.images.get())  +"\n"+\
                                "Large font="   + str(self.largeFont.get()) +"\n"
                    )
            except: result=False
            else: result=True
        self.update()
    
    def save(self, filename=False):
        try: os.remove("backup.hal")
        except: print("can't delete backup")
        try: os.rename("core.hal", "backup.hal")
        except: print("can't rename core to backup")
        if filename==False: filename="core.hal"                                 
        with open(filename, "wb") as file: pickle.dump(self.db, file) 
        self.update()
    
    def importDB(self):
        ftypes = [('База данных Halieus (*.hal)', '.hal')]
        filename = filedialog.askopenfilename(filetypes=ftypes, defaultextension='.hal')
        if filename!="":
            load=d.load(filename)
            if load[0]==True:
                self.db=load[1]
                self.save()
            else: mb.showerror("Ошибка", "Импорт файла %s не удался! Файл испорчен или имеет неправильный формат." % filename)
                
    def exportDB(self):
            ftypes = [('База данных Halieus (*.hal)', '.hal')]
            filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile='Территория собрания.hal', defaultextension='.hal')
            if filename!="":
                try:
                    self.save(filename=filename)
                    mb.showinfo("Экспорт", "Экспорт базы данных в файл %s выполнено успешно." % filename)
                except: mb.showerror("Ошибка", "Экспорт не удался!")
        
    def clearDB(self):
        if mb.askyesno("Очистка", "Вы уверены, что хотите безвозвратно удалить все участки?")==True: self.deleteSelected(self, all=True)                              
    
    def newTer(self, event=None, number="", type="", address="", note="", map="", image="", silent=False, worked=False): 
        self.db.append(Ter(self, number=number, type=type, address=address, note=note, map=map, image=image, worked=worked))      
        if silent==False: self.db[len(self.db)-1].show(self, new=True)          # if true, it is mass generation
            
    def checkDate(self, event):
        if d.verifyDate(self.chosenDate.get())==False:
            self.chosenDate.delete(0, "end")
            self.chosenDate.insert(0, self.prevDate)
        else:
            self.prevDate=self.chosenDate.get()            

    def find(self, event=None): 
        query = self.search.get().strip()
        if query=="": return
        count=0
        for i in range(len(self.db)):
            if query in self.db[i].number\
            or query in self.db[i].type\
            or query in self.db[i].address\
            or query in self.db[i].getDate1()\
            or query in self.db[i].getPublisher()\
            or query in self.db[i].getDate2()\
            or query in str(self.db[i].getWorks())\
            or query in self.db[i].note\
            or query in self.db[i].image\
            or query in self.db[i].map:
                self.db.insert(0, self.db.pop(i))
                count+=1
        self.update(sort=None)
        for i in range(count): self.list.itemconfig(i, bg="yellow")
            
    def openSingleTer(self, event=None):
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
    
    def openSelected(self, event=None):
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
        else: self.listPopup(event)
        
    def giveSelected(self, event=None):
        if len(self.list.curselection())==0: return
        elif self.chosenPublisher.get().strip()=="":
            self.publisherLabel["fg"] = "red"
            self.publisherFocus()
        elif self.chosenDate.get().strip()=="": self.chosenDate.focus_force()            
        else:
            for i in range(len(self.list.curselection())): self.db[self.list.curselection()[i]].give(self.chosenPublisher.get().strip(), self)    
    
    def submitSelected(self, event=None):
        if len(self.list.curselection())==0: return
        elif self.chosenDate.get().strip()=="": self.chosenDate.focus_force()
        else:
            for i in range(len(self.list.curselection())): self.db[self.list.curselection()[i]].submit(self)
            
    def deleteSelected(self, event=None, all=False):
        if all==True:
            del self.db[:]
            self.save()
        elif len(self.list.curselection())==0: return                
        elif len(self.list.curselection())==1:
            if mb.askyesno("Удаление", "Удалить участок %s?" % self.db[self.list.curselection()[0]].number)==True:
                del self.db[self.list.curselection()[0]]
                self.save()
        else:
            if mb.askyesno("Удаление", "Удалить эти участки (%d)?" % len(self.list.curselection()))==True:
                count=0
                for i in range(len(self.list.curselection())):
                    sel = self.list.curselection()[i]
                    del self.db[sel-count]
                    count+=1
                self.save()        
    
    def activateButtons(self, event=None):
        if len(self.list.curselection())!=0: self.selCount["text"]="Выбрано %d" % len(self.list.curselection())
        else: self.selCount["text"]=""
        self.buttonGive.state(["!disabled"])
        self.buttonSubmit.state(["!disabled"])
        #if len(self.list.curselection())<2: self.massEdit.grid_remove()        
        #else: self.massEdit.grid(column=1, row=0, padx=10, sticky="w")
        if len(self.list.curselection())==0:
            self.buttonGive.state(["disabled"])
            self.buttonSubmit.state(["disabled"])
    
    def setSort(self):
        self.settings[0]=str(self.sortType.get())
        self.saveSettings()
        self.update(sort=str(self.sortType.get()))
        
    def insertDate(self):
        self.chosenDate.delete(0, "end")
        self.chosenDate.insert(0, time.strftime("%d.%m", time.localtime()) + "." + str(int(time.strftime("%Y", time.localtime()))-2000))
        self.prevDate=self.chosenDate.get()
