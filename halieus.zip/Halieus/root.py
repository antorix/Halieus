#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
import pickle
import os
import datetime
from data import Ter
import data as d
import time
import webbrowser
import tkinter.messagebox as mb
import tools
import images

class Root(tk.Frame):
    """Main interface class"""  
    
    def __init__(self, window):        
        
        # Load database and all settings
        self.currentVersion="1.1.2"       
        self.db=d.load()[1]
        self.settings=d.load()[2]
        images.images(self)        
        self.style = ttk.Style()
        self.style.configure("big.TButton", font=('', 10))
        self.style.configure("startup.TButton", relief="raised", font=("{Arial bold}", 12), width=25, justify="center")
        self.prevDate=""
        self.tips="\
● Есть два способа быстро добавить много участков: массовое создание и импорт из Excel. Оба находятся в Меню → Инструменты.\n\n\
● Сохранять и загружать данные не нужно, они автоматически загружаются при запуске программы и сохраняются при каждом изменении. Однако можно экспортировать и импортировать базу данных для переноса на другие устройства или резервирования (Меню → Файл).\n\n\
● При каждом сохранении создается резервная копия (до 3). Если что-то пошло не так, восстановите наиболее свежую копию через Меню → Файл → Восстановление.\n\n\
● Для копирования-вставки рекомендуется использовать сочетания Ctrl+Insert и Shift+Insert или контекстное меню.\n\n\
● Программа полностью автоматически, в фоновом режиме обновляет саму себя через Интернет. Вам ничего не нужно делать, при этом размер загружаемого файла составляет считанные килобайты. Это можно отключить в настройках, но настоятельно не рекомендуется.\n\n\
● К каждому участку можно прикрепить картинку, положив ее в папке программы в формате .png и прописав имя файла в карточке участка. Эту функцию можно отключить в настройках.\n\n\
● Если что-то не работает или непонятно, не стесняйтесь писать автору программы через Меню → Помощь → Поддержка. Вам обязательно помогут!\n"
        self.sortType=tk.StringVar()                                            # variables
        self.sortType.set(self.settings[0])        
        self.autoUpdate=tk.IntVar()
        self.autoUpdate.set(self.settings[1])        
        self.listGrid=tk.IntVar()
        self.listGrid.set(self.settings[2])        
        self.images=tk.IntVar()
        self.images.set(self.settings[3])       
        self.searchHistory=tk.IntVar()
        self.searchHistory.set(self.settings[4])        
        self.bottomSB=tk.IntVar()
        self.bottomSB.set(self.settings[5])
        self.lines=tk.IntVar()
        self.lines.set(self.settings[6])        
        self.fields=[]
        for i in range(8):
            self.fields.append(tk.IntVar())
            self.fields[i].set(int(self.settings[7][i]))
        self.listFont=tk.StringVar()
        self.listFont.set(self.settings[8])
        self.listFontSize=tk.StringVar()
        self.listFontSize.set(self.settings[9])
        self.doubleAddress=tk.IntVar()
        self.doubleAddress.set(self.settings[10])
        self.workedTerYear=tk.IntVar()
        self.workedTerYear.set(self.settings[11])        
        
        # Window set up
        #window.wm_state('iconic')     
        w = window.winfo_screenwidth()/1.8
        h = window.winfo_screenheight()/1.3
        ws = window.winfo_screenwidth()
        hs = window.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-50
        window.geometry('%dx%d+%d+%d' % (w, h, x, y))
        window.minsize(260,285)
        if os.name=="nt": window.iconbitmap(self.ico[0])
        window.title("Halieus")
        window.grid_columnconfigure (0, weight=1)
        window.grid_rowconfigure    (2, weight=1)
        self.padx=3
        self.pady=3
        self.stripe="#e8f0ff"        
        window.bind("<Insert>", self.newTer)
        window.bind("<Alt-Home>", self.giveSelected)
        window.bind("<Alt-End>", self.submitSelected)
        window.bind("<Control-f>", lambda x: self.search.focus_force())
        window.bind("<Alt-0>", lambda x: self.chosenPublisher.focus_force())
        
        # Main menu
        menubar = tk.Menu(window)
        filemenu1 = tk.Menu(menubar, tearoff=0)                                 # Файл
        menubar.add_cascade(label="Файл", menu=filemenu1)
        filemenu1.add_command(label="Импорт", image=self.img[38], compound="left", command=self.importDB) 
        filemenu1.add_command(label="Экспорт", image=self.img[39], compound="left", command=self.exportDB)
        filemenu1.add_command(label="Очистка", image=self.img[40], compound="left", command=self.clearDB)
        filemenu1.add_command(label="Восстановление", image=self.img[51], compound="left", command=self.restoreDB)
        filemenu1.add_separator()
        filemenu1.add_command(label="Выход", command=window.quit)
        filemenu2 = tk.Menu(menubar, tearoff=0)                                 # Инструменты
        menubar.add_cascade(label="Инструменты", menu=filemenu2)
        filemenu2.add_command(label="Массовое создание участков", image=self.img[11], compound="left", command=lambda: tools.massCreate(self))
        filemenu2.add_command(label="Импорт участков из Excel", image=self.img[14], compound="left", command=lambda: tools.importXLS(self))
        filemenu2.add_command(label="Экспорт данных в Excel", image=self.img[13], compound="left", command=lambda: tools.exportXLS(self))
        filemenu3 = tk.Menu(menubar, tearoff=0)                                 # Настройки
        menubar.add_cascade(label="Настройки", menu=filemenu3)
        filemenu3.add_checkbutton(label="Автообновление программы", variable=self.autoUpdate, command=self.saveSettings)
        filemenu3.add_checkbutton(label="Картинки в участках", variable=self.images, command=self.saveSettings)
        filemenu3.add_checkbutton(label="Поиск включая возвещателей в истории", variable=self.searchHistory, command=self.saveSettings)
        #filemenu3.add_checkbutton(label="Обработанный за год участок должен быть выдан не раньше года назад", variable=self.workedTerYear, command=self.saveSettings)        
        filemenu3.add_separator()
        self.tableMenu=tk.Menu(menubar, tearoff=1)                              # Настройки списка участков
        filemenu3.add_cascade(label="Настройки списка участков", image=self.img[50], compound="left", menu=self.tableMenu)
        fontMenu=tk.Menu(self.tableMenu, tearoff=1)                             # Шрифт
        self.tableMenu.add_cascade(label="Шрифт", menu=fontMenu)
        fontMenu.add_radiobutton(label="Courier New", variable=self.listFont, value="Courier New", command=self.saveSettings)
        fontMenu.add_radiobutton(label="Liberation Mono", variable=self.listFont, value="Liberation Mono", command=self.saveSettings)
        fontMenu.add_radiobutton(label="Lucida Console", variable=self.listFont, value="Lucida Console", command=self.saveSettings)
        fontSizeMenu=tk.Menu(self.tableMenu, tearoff=1)                         # Размер шрифта
        self.tableMenu.add_cascade(label="Размер шрифта", menu=fontSizeMenu)
        fontSizeMenu.add_radiobutton(label="Очень мелкий", variable=self.listFontSize, value="7", command=self.saveSettings)
        fontSizeMenu.add_radiobutton(label="Мелкий", variable=self.listFontSize, value="8", command=self.saveSettings)
        fontSizeMenu.add_radiobutton(label="Средний", variable=self.listFontSize, value="9", command=self.saveSettings)
        fontSizeMenu.add_radiobutton(label="Крупный", variable=self.listFontSize, value="10", command=self.saveSettings)
        fontSizeMenu.add_radiobutton(label="Очень крупный", variable=self.listFontSize, value="11", command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Сетка", variable=self.listGrid, command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Вертикальные линии", variable=self.lines, command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Горизонтальная полоса прокрутки", variable=self.bottomSB, command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Расширенное поле адреса", variable=self.doubleAddress, command=self.saveSettings)
        self.tableMenu.add_separator()
        self.tableMenu.add_checkbutton(label="Поле статуса", variable=self.fields[0], command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Поле номера", variable=self.fields[1], command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Поле типа", variable=self.fields[2], command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Поле адреса", variable=self.fields[3], command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Поле возвещателя", variable=self.fields[4], command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Поле даты сдачи", variable=self.fields[5], command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Поле числа обработок", variable=self.fields[6], command=self.saveSettings)
        self.tableMenu.add_checkbutton(label="Поле заметки", variable=self.fields[7], command=self.saveSettings)
        filemenu4 = tk.Menu(menubar, tearoff=0)                                 # Помощь
        menubar.add_cascade(label="Помощь", menu=filemenu4)
        filemenu4.add_command(label="Важно знать", image=self.img[4], compound="left", command=self.showTips)
        filemenu4.add_command(label="Поддержка", image=self.img[31], compound="left", command=lambda: webbrowser.open("http://halieus.blogspot.com/"))
        filemenu4.add_command(label="О программе", image=self.img[47], compound="left", command=self.about)
        window.config(menu=menubar)        
        self.menubar = tk.Menu(window)
        self.filemenu1 = tk.Menu(self.menubar, tearoff=0)                       # Файл
        self.menubar.add_cascade(label="Файл", menu=self.filemenu1)
        self.filemenu1.add_command(label="Импорт", image=self.img[38], compound="left", command=self.importDB)
        
        # Standard context menu
        self.conMenu = tk.Menu(window, tearoff=0)
        self.conMenu.add_command(label="Вырезать")
        self.conMenu.add_command(label="Копировать")
        self.conMenu.add_command(label="Вставить")
        self.conMenu.add_command(label="Удалить")
        self.conMenu.add_separator()
        self.conMenu.add_command(label="Выделить все")
        
        # Search
        self.searchBar=ttk.Frame(window)
        self.searchBar.grid(column=1, row=0, padx=self.padx)
        self.search=ttk.Entry(self.searchBar, width=30)                         
        self.search.grid(column=4, row=0, sticky="e")
        self.search.bind("<Button-3>", self.standardMenu)
        self.CreateToolTip(self.search, "Поиск участков по любым полям")
        tk.Label(self.searchBar, text="Поиск", fg="gray20").grid(column=3, row=0, padx=3, sticky="e")                          
        self.search.focus_force()
        self.search.bind("<Return>", self.find)
        ttk.Button(self.searchBar, image=self.img[29], command=self.find).grid(column=5, row=0, sticky="w")
        
        # Main notebook
        self.notebook=ttk.Notebook(window)
        self.notebook.grid(column=0, row=1, columnspan=2, rowspan=4, padx=self.padx*0, pady=self.pady*0, sticky="nwes")
        self.tabList=ttk.Frame(self.notebook)
        self.tabList.columnconfigure(0, weight=1)
        self.tabList.rowconfigure(2, weight=1)
        self.tabReports=ttk.Frame(self.notebook)
        self.tabReports.columnconfigure(0, weight=1)
        self.tabReports.rowconfigure(0, weight=1)
        self.notebook.add(self.tabList, text="Участки", image=self.img[25], compound="left")
        self.notebook.add(self.tabReports, text="Отчеты", image=self.img[43], compound="left")
        self.tabReports.bind("<Visibility>", self.updateR)
        
        # Sorting
        self.sortFrame = ttk.Frame(self.tabList)
        self.sortFrame.grid(column=0, row=0, columnspan=2, padx=self.padx, sticky="nwe")
        self.sortFrame.columnconfigure(9, weight=1)
        self.sort=[]                                                            
        for value, image, column, tip in zip(["Статус","Номер (1)","Номер (1а)","Тип","Адрес","Возвещатель","Давность","Обработки","Заметка"], [self.img[3],self.img[22],self.img[23],self.img[26],self.img[21],self.img[17],self.img[18],self.img[5],self.img[20]], [1,2,3,4,5,6,7,8,9], ["Сортировка участков по статусу","Сортировка участков по номеру (числовая)","Сортировка участков по номеру (алфавитная)","Сортировка участков по типу","Сортировка участков по адресу","Сортировка участков по текущему возвещателю","Сортировка участков по давности последней обработки","Сортировка участков по числу обработок","Сортировка участков по заметке"]):
                self.sort.append(ttk.Radiobutton(self.sortFrame, variable=self.sortType, value=value, image=image, compound="left", text=value, command=self.setSort))
                self.sort[column-1].grid(column=column, row=0, padx=self.padx, pady=self.pady, sticky="w")
                self.CreateToolTip(self.sort[column-1], tip)        
        self.tableMenuButton=ttk.Button(self.sortFrame, image=self.img[50])     # table settings
        self.tableMenuButton.grid(column=9, row=0, sticky="e")                  
        self.tableMenuButton.bind("<1>", lambda event: self.tableMenu.post(event.x_root, event.y_root))
        self.CreateToolTip(self.tableMenuButton, "Настройки списка участков")
        
        # Mass selection bar 
        self.massFrame=ttk.Frame(self.tabList)                                        
        self.massFrame.grid(column=0, row=1, columnspan=2, sticky="we")                                            
        self.massFrame.grid_columnconfigure(4, weight=1)        
        self.selCount=tk.Label(self.massFrame, fg="MidnightBlue")               # selection count 
        self.selCount.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="ws")
        self.massEditButton=ttk.Button(self.massFrame, text="Правка выборки", image=self.img[10], compound="left",\
            command=lambda: tools.massEdit(self))                               # mass edit
        self.massEditButton.grid(column=1, row=0, padx=3, sticky="ws")
        self.CreateToolTip(self.massEditButton, "Правка выбранных участков")        
        self.massStatsButton=ttk.Button(self.massFrame, text="Статистика выборки", image=self.img[24], compound="left", command=self.showMassStats) # mass (slice) statistics
        self.massStatsButton.grid(column=2, row=0, padx=3, sticky="ws")                
        self.CreateToolTip(self.massStatsButton, "Статистика выбранных участков")        
        self.massCopyButton=ttk.Button(self.massFrame, text="Скопировать номера", image=self.img[49], compound="left", command=lambda: self.massCopy(window)) # mass copy
        self.massCopyButton.grid(column=3, row=0, padx=3, sticky="ws")
        self.CreateToolTip(self.massCopyButton, "Скопировать номера выбранных участков в буфер обмена")        
        self.filterYear = tk.IntVar()                                           # checkbuttons
        self.filterYear.set(0)
        self.yearCheckbutton=ttk.Checkbutton(self.massFrame, text="Обработано за год   ", variable=self.filterYear, command=self.update)
        self.yearCheckbutton.grid(column=5, row=0, pady=self.pady, sticky="w")                         
        self.CreateToolTip(self.yearCheckbutton, "Участки, обработанные за последние 365 дней")
        self.filterWorked = tk.IntVar()
        self.filterWorked.set(0)
        self.nonWorkedCheckbutton=ttk.Checkbutton(self.massFrame, text="Не обрабатывалось", variable=self.filterWorked, command=self.update)
        self.nonWorkedCheckbutton.grid(column=6, row=0, pady=self.pady, sticky="w") 
        self.CreateToolTip(self.nonWorkedCheckbutton, "Участки, которые никогда не обрабатывались")
        
        # Main list        
        self.list = tk.Listbox(self.tabList, activestyle="dotbox", width=50, bd=1, selectmode="extended", relief="sunken")
        self.list.grid(column=0, row=2, columnspan=2, padx=self.padx, pady=self.pady, sticky="nwes")  
        self.rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=self.rightScrollbar.set)      
        self.rightScrollbar.pack(side="right", fill="y")
        self.bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
        self.list.configure(xscrollcommand=self.bottomScrollbar.set)
        #self.bottomScrollbar.pack(side="bottom", fill="x")
        self.list.bind("<Return>", self.openSelected)
        if os.name!="posix": self.list.bind("<Double-1>", self.openSelected)
        self.list.bind("<<ListboxSelect>>", self.activateButtons)
        self.list.bind("<3>", self.listPopup)
        self.list.bind("<space>", self.listPopup)
        
        # Main list context menu
        listbar = tk.Menu(self.list)
        self.listmenu = tk.Menu(listbar, tearoff=0)
        self.listmenu.add_command(label=" Открыть", image=self.img[27], compound="left", command=self.openSingleTer)
        self.listmenu.add_command(label=" Выдать", image=self.img[9], compound="left", command=self.giveSelected)
        self.listmenu.add_command(label=" Сдать", image=self.img[8], compound="left", command=self.submitSelected)
        self.listmenu.add_command(label=" Правка выборки", image=self.img[10], compound="left", command=lambda: tools.massEdit(self))
        self.listmenu.add_command(label=" Статистика выборки", image=self.img[24], compound="left", command=self.showMassStats)
        self.listmenu.add_command(label=" Скопировать номера", image=self.img[49], compound="left", command=lambda: self.massCopy(window))
        self.listmenu.add_command(label=" Удалить", image=self.img[28], compound="left", command=self.deleteSelected)
        listbar.add_cascade(label="Действия", menu=self.listmenu)
        self.list.bind("<Delete>", self.deleteSelected)
        self.list.bind("<BackSpace>", self.deleteSelected)
        
        # Operations
        self.statsMass=ttk.LabelFrame(self.tabList, text="Действия")
        self.statsMass.grid(column=0, row=3, columnspan=4, padx=self.padx, pady=self.pady, sticky="wns")                
        self.buttonGive = ttk.Button(self.statsMass, text="Выдать", image=self.img[6], compound="left", command=self.giveSelected)
        self.buttonGive.grid(column=0, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")
        self.CreateToolTip(self.buttonGive, "Выдать участок (участки) выбранному возвещателю в выбранную дату")
        self.buttonSubmit = ttk.Button(self.statsMass, text="Сдать", image=self.img[7], compound="left", command=self.submitSelected)
        self.buttonSubmit.grid(column=1, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")        
        self.CreateToolTip(self.buttonSubmit, "Сдать (вернуть в картотеку) участок (участки) в выбранную дату")
        ttk.Separator(self.statsMass, orient='vertical').grid(column=3, row=0, rowspan=2, padx=self.padx*4, pady=self.pady*4, sticky='ns')       
        self.publisherLabel=tk.Label(self.statsMass, image=self.img[17], compound="left", text="Возвещатель")
        self.publisherLabel.grid(column=4, row=0, padx=self.padx*2.5, sticky="ws")
        ttk.Label(self.statsMass, image=self.img[19], compound="left", text="Дата").grid(column=5, row=0, columnspan=2, sticky="ws")        
        self.chosenPublisher=ttk.Entry(self.statsMass)
        self.chosenPublisher.grid(column=4, row=1, padx=self.padx*3, pady=5, sticky="wn")
        self.CreateToolTip(self.chosenPublisher, "Имя возвещателя для выдачи участков")
        self.chosenPublisher.bind("<Button-3>", self.standardMenu)
        self.chosenPublisher.bind("<Return>", self.giveSelected)
        self.chosenDate=ttk.Entry(self.statsMass, width=8)
        self.chosenDate.grid(column=5, row=1, pady=5, sticky="wn")
        self.chosenDate.bind("<FocusOut>", self.checkDate)        
        self.chosenDate.bind("<Button-3>", self.standardMenu)
        self.CreateToolTip(self.chosenDate, "Дата для операций выдачи и сдачи участков")
        style = ttk.Style()
        style.configure("small3.TButton", font=('', 7))
        ttk.Button(self.statsMass, text="Сегодня", style="small3.TButton", command=self.insertDate).grid(column=6, row=1, padx=5, pady=5, sticky="wn")
        self.newTerButton=ttk.Button(self.tabList, text="Новый участок", compound="left", style='big.TButton', image=self.img[0], command=self.newTer)
        self.newTerButton.grid(column=1, row=3, padx=self.padx*2, pady=self.pady*2, ipadx=10, ipady=10, sticky="se")
        self.CreateToolTip(self.newTerButton, "Создание нового участка")
        
        # Reports (Tab 2)
        self.frameReports=tk.Frame(self.tabReports)
        self.frameReports.grid(column=0,row=0,padx=self.padx, pady=self.pady, sticky="nesw")
        self.frameReports.columnconfigure(0, weight=5)
        self.frameReports.columnconfigure(1, weight=5)
        self.frameReports.rowconfigure(0, weight=2)
        self.frameReports.rowconfigure(1, weight=3)        
        self.subframe1=tk.Frame(self.frameReports, bg="white")                  # statistics [0,0]
        self.subframe1.grid(column=0,columnspan=2,row=0,rowspan=2,sticky="nesw")
        self.subframe1.rowconfigure(0, weight=1)
        self.subframe1.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe1, text=" Статистика", image=self.img[24], font="Tahoma 10 bold", compound="left").pack(fill="both")
        self.statsFrame=tk.Frame(self.subframe1, bg="white")
        self.statsFrame.pack(fill="both",padx=self.padx, pady=self.pady)        
        self.stat=[]
        for i, img in zip([0,1,2,3,4,5,6,7], [45,3,44,15,5,32,46,41]):
            self.stat.append(tk.Label(self.statsFrame, bg="white", cursor="hand2", image=self.img[img], compound="left"))
            self.stat[i].grid(column=0, row=i, sticky="wn")     
        self.stat[7]["cursor"]="arrow"
        self.stat[0].bind("<1>", lambda x: self.find(query="*"))
        self.stat[1].bind("<1>", lambda x: self.findStat("checked"))
        self.stat[2].bind("<1>", lambda x: self.findStat("given"))
        self.stat[3].bind("<1>", lambda x: self.findStat("timedout"))
        self.stat[4].bind("<1>", lambda x: self.findStat("workedYear"))
        self.stat[5].bind("<1>", lambda x: self.findStat("workedYearNot"))
        self.stat[6].bind("<1>", lambda x: self.findStat("notWorked"))       
        self.statFootnote=tk.Label(self.statsFrame, bg="white", justify="left", text="* Все проценты – от общего\n  числа участков")
        self.statFootnote.grid(column=0, row=8, padx=self.padx, pady=self.pady, sticky="wn")
        self.copyStats=ttk.Button(self.frameReports, image=self.img[49], command=lambda: self.pasteToClipboard(form=window, content=self.contentFullStats))
        self.copyStats.grid(column=0,row=0,padx=2, pady=2,sticky="se")
        self.CreateToolTip(self.copyStats, "Скопировать в буфер обмена")
        
        self.subframe2=tk.Frame(self.frameReports, bd=0, bg="white")            # count types [1,0]
        self.subframe2.grid(column=1,row=0,sticky="nesw")
        self.subframe2.rowconfigure(1, weight=1)
        self.subframe2.columnconfigure(0, weight=1)        
        self.labelTypes=ttk.Label(self.subframe2, text=" Типы", image=self.img[48], font="Tahoma 10 bold", compound="left")
        self.labelTypes.pack(fill="x")        
        self.typeList=tk.Listbox(self.subframe2, bd=0, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.typeList, orient="vertical", command=self.typeList.yview) 
        self.typeList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")        
        self.typeList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        listbar = tk.Menu(self.list)
        self.typeMenu=tk.Menu(listbar, tearoff=0)
        self.typeMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=lambda: self.findFromReport(self.typeList, "type"))
        self.typeList.bind("<3>", lambda event: self.typeMenu.post(event.x_root, event.y_root))
        self.typeList.bind("<Return>", lambda x: self.findFromReport(self.typeList, "type"))
        self.typeList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.typeList, "type"))        
        self.copyTypes=ttk.Button(self.subframe2, image=self.img[49], command=lambda: self.pasteToClipboard(form=window, content=self.contentTypes))
        self.copyTypes.pack(side="right",padx=2,pady=2)
        self.CreateToolTip(self.copyTypes, "Скопировать в буфер обмена")
        
        self.subframe3=tk.Frame(self.frameReports, bg="white")                  # count publishers [0,1]
        self.subframe3.grid(column=0, row=1, sticky="nesw")
        self.subframe3.rowconfigure(1, weight=1)
        self.subframe3.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe3, text=" Возвещатели", image=self.img[17], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.pubList=tk.Listbox(self.subframe3, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.pubList, orient="vertical", command=self.pubList.yview) 
        self.pubList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")
        self.pubList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")    
        listbar = tk.Menu(self.list)
        self.pubMenu=tk.Menu(listbar, tearoff=0)
        self.pubMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=lambda: self.findFromReport(self.pubList, "publisher"))
        self.pubList.bind("<3>", lambda event: self.pubMenu.post(event.x_root, event.y_root))
        self.pubList.bind("<Return>", lambda x: self.findFromReport(self.pubList, "publisher"))
        self.pubList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.pubList, "publisher"))
        self.copyPubs=ttk.Button(self.subframe3, image=self.img[49], command=lambda: self.pasteToClipboard(form=window, content=self.contentPubs))
        self.copyPubs.pack(side="right",padx=2, pady=2,)
        self.CreateToolTip(self.copyPubs, "Скопировать в буфер обмена")        
        self.subframe4=tk.Frame(self.frameReports, bg="white")                  # count notes [1,1]
        self.subframe4.grid(column=1, row=1, sticky="nesw")
        self.subframe4.rowconfigure(1, weight=1)
        self.subframe4.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe4, text=" Заметки", image=self.img[20], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.noteList=tk.Listbox(self.subframe4, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.noteList, orient="vertical", command=self.noteList.yview) 
        self.noteList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")
        self.noteList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        listbar = tk.Menu(self.list)
        self.noteMenu=tk.Menu(listbar, tearoff=0)
        self.noteMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=lambda: self.findFromReport(self.noteList, "note"))
        self.noteList.bind("<3>", lambda event: self.noteMenu.post(event.x_root, event.y_root))
        self.noteList.bind("<Return>", lambda x: self.findFromReport(self.noteList, "note"))
        self.noteList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.noteList, "note"))
        self.copyNotes=ttk.Button(self.subframe4, image=self.img[49], command=lambda: self.pasteToClipboard(form=window, content=self.contentNotes))
        self.copyNotes.pack(side="right",padx=2, pady=2,)
        self.CreateToolTip(self.copyNotes, "Скопировать в буфер обмена")
        
        #ttk.Button(self.frameReports, text="Отчет", compound="left", style='big.TButton', image=self.img[42]).grid()        
        
        # Footer
        self.statusFrame=tk.Frame(window)
        self.statusFrame.grid(column=0, row=6, sticky="w")      
        self.timedoutCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[15], compound="left")
        self.timedoutCount.pack(side="left", fill="y")
        self.timedoutCount.bind("<1>", lambda x: self.findStat("timedout"))
        self.CreateToolTip(self.timedoutCount, "Участки, просроченные возвещателями (нажмите для фильтрации)")
        self.nonWorkedYearCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[32], compound="left")
        self.nonWorkedYearCount.pack(side="left", fill="y")
        self.nonWorkedYearCount.bind("<1>", lambda x: self.findStat("workedYearNot"))
        self.CreateToolTip(self.nonWorkedYearCount, "Участки, не обработанные за последние 365 дней (нажмите для фильтрации)")
        self.nonWorkedCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[46], compound="left")
        self.nonWorkedCount.pack(side="left", fill="y")
        self.nonWorkedCount.bind("<1>", lambda x: self.findStat("notWorked"))
        self.CreateToolTip(self.nonWorkedCount, "Участки, которые никогда не обрабатывались (нажмите для фильтрации)")
        self.medal=tk.Label(self.statusFrame, fg="gray20", image=self.img[60], compound="left")
        self.medal.pack(side="left", fill="y")
        self.CreateToolTip(self.medal, "Поздравляем, вы отлично справляетесь! :)")      
        self.terCount=tk.Label(window, fg="gray20", image=self.img[45], compound="left")
        self.terCount.grid(column=0, columnspan=1, row=6, sticky="e")
        self.CreateToolTip(self.terCount, "Всего участков в базе данных")   
        self.statusBar=tk.Label(window, fg="gray20")
        self.statusBar.grid(column=1, columnspan=1, row=6, sticky="e")             
        self.CreateToolTip(self.statusBar, "Дата и время последней модификации встроенной базы данных")
        ttk.Separator(window, orient='horizontal').grid (column=0, row=6, columnspan=2, sticky='nwe')
        ttk.Sizegrip(window).grid(column=1, row=0, rowspan=7, sticky="se")                
        
        # Prepare to launch
        self.activateButtons(None)
        self.insertDate()        
        self.update()        
        self.updateR()
        if not os.path.exists("settings.ini"):
            self.showTips("Добро пожаловать в Halieus! Пожалуйста, уделите всего минуту на следующую важную информацию (вы можете вернуться к ней позже в Меню → Помощь).\n\n" + self.tips)                       
        if not os.path.exists("settings.ini") and len(self.db)==0:
            color="SeaGreen"
            tip=tk.Toplevel(bg=color)
            w = window.winfo_screenwidth()/3
            h = window.winfo_screenheight()/6
            ws = window.winfo_screenwidth()
            hs = window.winfo_screenheight()
            x = (ws/2) - (w/2)
            y = (hs/2) - (h/2)-50
            tip.geometry('%dx%d+%d+%d' % (w, h, x, y))            
            tip.wm_overrideredirect(True)        
            tip.focus_force()
            tip.grab_set()
            frame=tk.Frame(tip, bg=color, relief='flat')
            frame.pack(expand=True, padx=self.padx, pady=self.pady, fill="y")
            frame.rowconfigure(0,weight=1)
            frame.columnconfigure(0,weight=1)
            frame.columnconfigure(1,weight=1)            
            frame.columnconfigure(2,weight=1)           
            tk.Button(frame, image=self.img[2], width=200, compound="top", relief="raised", bd=3, justify="center", font="Tahoma 10 bold", text="Импортировать\nучастки из Excel", command=lambda: tools.importXLS(self, tip)).grid(column=0,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw")
            tk.Button(frame, image=self.img[37], width=200, compound="top", relief="raised", bd=3, justify="center", font="Tahoma 10 bold", text="Создать участки\nмассово", command=lambda: tools.massCreate(self, tip)).grid(column=1,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw")
            tk.Button(frame, image=self.img[55], width=200, compound="top", relief="raised", bd=3, justify="center", font="Tahoma 10 bold", text="Не сейчас", command=tip.destroy).grid(column=2,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw")            
        self.saveSettings()
        window.wm_state('normal')
        
        # Launch
        
        window.mainloop()
        
        # After close        
        if self.autoUpdate.get()==1: d.updateApp(self)        
            
    # FUNCTIONS ---------------------------------------------------------------------------    
    
    def update(self, sort="unchanged"):
        """ Redraw ter list and update interface """
        if sort=="unchanged": sort = str(self.sortType.get())                   # sort
        if sort=="Давность": self.db.sort(key=lambda x: d.convert(x.getDateLastSubmit()), reverse=False) 
        elif sort=="Номер (1)":
            try: self.db.sort(key=lambda x: float(x.number), reverse=False) 
            except:
                mb.showwarning("Ошибка сортировки", "В номерах участков используются нецифровые символы либо пустые номера, поэтому числовая сортировка невозможна. Переключаюсь на алфавитную.")
                sort="Номер (1а)"
                self.sortType.set("Номер (1а)")
                self.settings[0]=str(self.sortType.get())
                self.saveSettings()
                self.db.sort(key=lambda x: x.number, reverse=False)                
        elif sort=="Номер (1а)": self.db.sort(key=lambda x: x.number, reverse=False) 
        elif sort=="Статус": self.db.sort(key=lambda x: x.getStatus(), reverse=True) 
        elif sort=="Тип": self.db.sort(key=lambda x: x.type, reverse=False) 
        elif sort=="Адрес": self.db.sort(key=lambda x: x.address, reverse=False) 
        elif sort=="Возвещатель": self.db.sort(key=lambda x: x.getCurrentPublisher(), reverse=False) 
        elif sort=="Обработки": self.db.sort(key=lambda x: x.getWorks(), reverse=False) 
        elif sort=="Заметка": self.db.sort(key=lambda x: x.note, reverse=False)         
        else: self.sortType.set(None)
        self.listContent = tk.StringVar(value=tuple(["%4s) %s" % (str(i+1), self.db[i].retrieve(self)) for i in range(len(self.db))])) # fill list        
        self.list.configure(listvariable=self.listContent)        
        self.list["font"]="{%s} %s" % (self.listFont.get(), self.listFontSize.get())           
        worked,nonWorked,year,given,timedout,averagesSum=self.getStats()
        if self.bottomSB.get()==1: self.bottomScrollbar.pack(side="bottom", fill="x")
        else: self.bottomScrollbar.pack_forget()        
        if timedout!=0:
            self.timedoutCount.pack(side="left", fill="y")
            self.timedoutCount["text"]=str(timedout)+" "
        else: self.timedoutCount.pack_forget()        
        if (len(self.db)-year)!=0:
            self.nonWorkedYearCount.pack(side="left", fill="y")            
            self.nonWorkedYearCount["text"]=str(len(self.db)-year)+" "
        else: self.nonWorkedYearCount.pack_forget()        
        if nonWorked!=0:
            self.nonWorkedCount.pack(side="left", fill="y")
            self.nonWorkedCount["text"]=str(nonWorked)+" "
        else: self.nonWorkedCount.pack_forget()        
        if timedout!=0 or (len(self.db)-year)!=0 or nonWorked!=0:
            self.medal.pack_forget()        
        else: self.medal.pack()        
        try: self.statusBar["text"] = "База изменена %s      " % datetime.datetime.fromtimestamp(os.path.getmtime("core.hal")) # last core save
        except: pass
        self.terCount["text"]=str(len(self.db))+" "
        
    def updateR(self,  event=None):
        """ Redraw report tab """   
        self.fontReport="{%s} %s" % (self.listFont.get(), self.listFontSize.get())
        allStats=self.getStats()
        worked,nonWorked,year,given,timedout,averagesSum=allStats
        for i in range(8): self.stat[i]["font"]=self.fontReport
        self.stat[0]["text"] =          "%-36s %4d"   % (" Всего участков:", len(self.db))                                       
        try: self.stat[1]["text"] =     "%-36s %4d (%.1f%%)*"   % (" В картотеке:", (len(self.db)-given), (len(self.db)-given)/len(self.db)*100)       
        except: self.stat[1]["text"] =  "%-36s    0   (0.0%%)"  %  " В картотеке:"         
        try: self.stat[2]["text"] =     "%-36s %4d (%.1f%%)"    % (" На руках:", given, (given/len(self.db))*100)
        except: self.stat[2]["text"] =  "%-36s    0   (0.0%%)"  %  " На руках:"        
        try: self.stat[3]["text"] =     "%-36s %4d (%.1f%%)"    % (" Просрочено:", timedout, (timedout/len(self.db))*100)      
        except: self.stat[3]["text"] =  "%-36s    0   (0.0%%)"  %  " Просрочено:"         
        try: self.stat[4]["text"] =     "%-36s %4d (%.1f%%)"    % (" Обработано за год:", year, (year/len(self.db))*100)
        except: self.stat[4]["text"] =  "%-36s    0   (0.0%%)"  %  " Обработано за год:"        
        try: self.stat[5]["text"] =     "%-36s %4d (%.1f%%)"    % (" Не обработано за год:", len(self.db)-year, (100-(year/len(self.db))*100))      
        except: self.stat[5]["text"] =  "%-36s    0   (0.0%%)"  %  " Не обработано за год:"         
        try: self.stat[6]["text"] =     "%-36s %4d (%.1f%%)"    % (" Никогда не обрабатывалось:", nonWorked, (nonWorked/len(self.db))*100)
        except: self.stat[6]["text"] =  "%-36s    0   (0.0%%)"  %  " Никогда не обрабатывалось:"
        self.stat[7]["text"]=           "%-37s %.1f мес."    %    (" Среднее время обработки:", allStats[5]/30.5)
        self.statFootnote["font"]="{%s} %d" % (self.listFont.get(), int(self.listFontSize.get())-1)
        self.contentFullStats=self.stat[0]["text"]+"\n"+self.stat[1]["text"]+"\n"+self.stat[2]["text"]+"\n"+self.stat[3]["text"]+"\n"+self.stat[4]["text"]+"\n"+self.stat[5]["text"]+"\n"+self.stat[6]["text"]+"\n"+self.stat[7]["text"]
        
        self.types=[]                                                           # calculate other reports / types
        numbers=[]
        content=[]
        for ter in self.db: self.types.append(ter.type)
        self.types = list(set(self.types))
        self.types.sort()        
        for i in range(len(self.types)):
            numbers.append([self.types[i], 0])
            for ter in self.db: 
                if ter.type==self.types[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без типа"
            content.append("%3s) %-34s %3s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))            
        listContent=tk.StringVar(value=tuple(content))
        self.typeList.configure(font=self.fontReport, listvariable=listContent)
        self.contentTypes=""
        for i in content: self.contentTypes+=i+"\n"
        
        self.publishers=[]                                                      # publishers
        numbers=[]
        content=[]
        for ter in self.db: self.publishers.append(ter.getCurrentPublisher())
        self.publishers = list(set(self.publishers))
        self.publishers.sort()        
        for i in range(len(self.publishers)):
            numbers.append([self.publishers[i], 0])
            for ter in self.db: 
                if ter.getCurrentPublisher()==self.publishers[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без возвещателя"
            content.append("%3s) %-34s %3s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))
        listContent=tk.StringVar(value=tuple(content))
        self.pubList.configure(listvariable=listContent, font=self.fontReport)
        self.contentPubs=""
        for i in content: self.contentPubs+=i+"\n"
        
        self.notes=[]                                                           # notes
        numbers=[]
        content=[]
        for ter in self.db: self.notes.append(ter.note)
        self.notes = list(set(self.notes))
        self.notes.sort()        
        for i in range(len(self.notes)):
            numbers.append([self.notes[i], 0])
            for ter in self.db: 
                if ter.note==self.notes[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без заметки"
            content.append("%3s) %-34s %3s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))
        listContent=tk.StringVar(value=tuple(content))
        self.noteList.configure(listvariable=listContent, font=self.fontReport)
        self.contentNotes=""
        for i in content: self.contentNotes+=i+"\n"
        
    def popupForCopy(self, content, event=None):
        if content=="email": self.menuEmail.post(event.x_root, event.y_root)
        else: self.menuWeb.post(event.x_root, event.y_root)
            
    def about(self):
        about=tk.Toplevel(bg="white")
        about.wm_overrideredirect(True)
        about.focus_force()
        about.grab_set()
        w = 700#440
        h = 300#230
        x = (about.winfo_screenwidth()/2) - (w/2)
        y = (about.winfo_screenheight()/2) - (h/2)-40
        about.geometry('%dx%d+%d+%d' % (w, h, x, y))
        about.minsize(w,h)        
        frame=tk.Frame(about, bg="white")
        frame.pack(expand=True, fill="both")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(2, weight=1)
        tk.Label(frame, bd=0,image=self.img[56]).place(x=0,y=0)
        ttk.Label(frame, text="Halieus %s" % self.currentVersion, font="Arial 12 bold italic").grid(column=0,row=0,padx=5,pady=5,sticky="nw")        
        menubar=tk.Menu(about)
        self.menuEmail=tk.Menu(menubar, tearoff=0)                                 
        menubar.add_cascade(label="Файл", menu=self.menuEmail)        
        self.menuEmail.add_command(label="Копировать", compound="left", command=lambda: self.pasteToClipboard(about, "antorix@gmail.com"))        
        self.menuWeb=tk.Menu(menubar, tearoff=0)                                 
        self.menubar.add_cascade(label="Файл", menu=self.menuWeb)
        self.menuWeb.add_command(label="Копировать", compound="left", command=lambda: self.pasteToClipboard(about, "http://halieus.blogspot.com/"))            
        email=tk.Label(frame, bg="white", font="Arial 9 underline", text="antorix@gmail.com", cursor="hand2", image=self.img[57], compound="left")
        email.grid(column=1, row=0, padx=self.padx*8, pady=self.pady*8, sticky="w")
        email.bind("<Button-1>", lambda x: webbrowser.open("mailto:antorix@gmail.com"))
        email.bind("<Button-3>", lambda event: self.popupForCopy("email", event))                        
        web=tk.Label(frame, bg="white", font="Arial 9 underline", text="halieus.blogspot.com", cursor="hand2", image=self.img[58], compound="left")
        web.grid(column=1, row=1, padx=self.padx*8, sticky="w")              
        web.bind("<Button-1>", lambda x: webbrowser.open("http://halieus.blogspot.com/"))
        web.bind("<Button-3>", lambda event: self.popupForCopy("web", event))              
        tk.Label(frame, fg="gray20", bg="white", font="Arial 9 italic", justify="left", text=\
        "Иисус сказал им: «Идите за мной,\n\
и я сделаю вас ловцами (греч. halieus)\n\
людей» (Мк. 1:17)").grid(column=1, row=2, padx=self.padx*4, pady=self.pady*2, sticky="es")
        frame2=tk.Frame(frame, bg="Teal",bd=5)
        frame2.grid(column=0,row=5,columnspan=2,sticky="wes")
        tk.Label(frame, fg="white", bg="Teal", font="Arial 7", text="Лицензия GNU GPL").grid(column=1,row=4,sticky="se")
        about.bind("<Escape>", lambda x: about.destroy())
        close=tk.Label(frame, bg="white", image=self.img[59])
        close.grid(column=1,row=0,sticky="ne")
        close.bind("<1>", lambda x: about.destroy())
        
    def showTips(self, text=None):
        if text==None: text=self.tips
        tip=tk.Toplevel(bg="white")
        tip.wm_overrideredirect(True)        
        tip.focus_force()
        tip.grab_set()
        frame=tk.Frame(tip, bg="white", relief='solid', borderwidth=1)
        frame.pack(expand=True, padx=self.padx, pady=self.pady*3, fill="both")
        frame.columnconfigure(0, weight=2)
        frame.columnconfigure(0, weight=5)
        tk.Label(frame, background="white", image=self.img[52]).grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="wens")
        tk.Label(frame, text="Важно знать", background="white", font="Arial 11 bold").grid(column=1, row=0, padx=self.padx, pady=self.pady, sticky="wns")
        tk.Message(frame, width=400, background="white", text=text).grid(column=1, row=1, padx=self.padx, pady=self.pady, sticky="e")
        x = (tip.winfo_screenwidth()/2)-200
        y = (tip.winfo_screenheight()/5)
        tip.geometry('+%d+%d' % (x, y))
        tip.bind("<Escape>", lambda x: tip.destroy())
        tip.bind("<3>", lambda x: tip.destroy())
        close=tk.Label(frame, bg="white", image=self.img[59])
        close.grid(column=1,row=0,sticky="ne")
        close.bind("<1>", lambda x: tip.destroy())        
        tip.wait_window()
        
    def listPopup(self, event=None):
        if len(self.list.curselection())==0:
            self.listmenu.entryconfig(" Открыть", state="disabled")
            self.listmenu.entryconfig(" Выдать", state="disabled")
            self.listmenu.entryconfig(" Сдать", state="disabled")
            self.listmenu.entryconfig(" Удалить", state="disabled")
        elif len(self.list.curselection())==1:
            self.listmenu.entryconfig(" Открыть", state="normal")
            self.listmenu.entryconfig(" Выдать", state="normal")
            self.listmenu.entryconfig(" Сдать", state="normal")
            self.listmenu.entryconfig(" Удалить", state="normal")
        else:
            self.listmenu.entryconfig(" Открыть", state="disabled")
            self.listmenu.entryconfig(" Выдать", state="normal")
            self.listmenu.entryconfig(" Сдать", state="normal")
            self.listmenu.entryconfig(" Удалить", state="normal")
        self.listmenu.post(event.x_root, event.y_root)
    
    def saveSettings(self):
        fields=""
        for i in range(8): fields+=str(self.fields[i].get())        
        with open("settings.ini", "w", encoding="utf-8") as file:
            file.write( "Sort type="    + str(self.sortType.get())  +"\n"+\
                        "Auto update="  + str(self.autoUpdate.get())+"\n"+\
                        "List grid="    + str(self.listGrid.get())  +"\n"+\
                        "Images in cards="+ str(self.images.get())  +"\n"+\
                        "Search in history="   + str(self.searchHistory.get()) +"\n"+\
                        "Bottom scrollbar="+ str(self.bottomSB.get())+"\n"+\
                        "Lines in grid="+ str(self.lines.get())     +"\n"+\
                        "Table fields=" + fields                    +"\n"+\
                        "List font="    + self.listFont.get()       +"\n"+\
                        "List font size="+ self.listFontSize.get()  +"\n"+\
                        "Double address="+ str(self.doubleAddress.get())+"\n"+\
                        "Worked ter given within year="+ str(self.workedTerYear.get())+"\n"
            )            
        self.update()
        self.updateR()
    
    def save(self, filename=False):
        try: os.remove("backup3.hal")
        except: print("can't delete backup3")
        try: os.rename("backup2.hal", "backup3.hal")
        except: print("can't rename backup2 to backup3")
        try: os.rename("backup1.hal", "backup2.hal")
        except: print("can't rename backup1 to backup2")
        try: os.rename("core.hal", "backup1.hal")
        except: print("can't rename core to backup1")
        if filename==False: filename="core.hal"                                 
        with open(filename, "wb") as file: pickle.dump(self.db, file) 
        self.update()
    
    def importDB(self, filename=None, backup=False):
        ftypes = [('База данных Halieus (*.hal)', '.hal')]
        if filename==None: filename = filedialog.askopenfilename(filetypes=ftypes, defaultextension='.hal')
        if filename!="":
            print("import attempt…")
            load=d.load(filename)
            if load[0]==True:
                self.db=load[1]
                self.save()
                self.updateR()
                print("import of %s successful, set acquired array as core" % filename)
            elif backup==False: mb.showerror("Ошибка", "Импорт файла %s не удался! Файл испорчен или имеет неправильный формат." % filename)
            else:
                print("import error")                                          # backup restore attempt failed
                return False                                                  
                
    def exportDB(self):
            ftypes = [('База данных Halieus (*.hal)', '.hal')]
            filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile='Территория собрания.hal', defaultextension='.hal')
            if filename!="":
                try:
                    self.save(filename=filename)
                    mb.showinfo("Экспорт", "Экспорт базы данных в файл %s выполнен успешно." % filename)
                except: mb.showerror("Ошибка", "Экспорт не удался!")
        
    def clearDB(self):
        if mb.askyesno("Очистка", "Вы уверены, что хотите безвозвратно удалить все участки?")==True: self.deleteSelected(all=True)                              
        
    def restoreDB(self):
        if mb.askyesno("Восстановление", "Восстановить базу данных из наиболее свежей имеющейся резервной копии?")==True:
            if self.importDB(filename="backup1.hal", backup=True)==False:
                print("backup1 not found")
                if self.importDB(filename="backup2.hal", backup=True)==False:
                    print("backup2 not found")
                    if self.importDB(filename="backup3.hal", backup=True)==False:
                        print("backup3 not found")
                        mb.showwarning("Восстановление", "К сожалению, резервные копии не найдены.")
    
    def newTer(self, event=None, number="", type="", address="", note="", map="", image="", work=[], silent=False): 
        self.db.append(Ter(number=number, type=type, address=address, note=note, map=map, image=image, work=work))      
        if silent==False: self.db[len(self.db)-1].show(self, new=True)          # if true, it is mass generation
            
    def checkDate(self, event):
        if d.verifyDate(self.chosenDate.get())==False:
            self.chosenDate.delete(0, "end")
            self.chosenDate.insert(0, self.prevDate)
        else:
            self.prevDate=self.chosenDate.get()            

    def find(self, event=None, query=None):
        if query==None: query=self.search.get().strip()
        if query=="" and query!="*": return
        elif query=="*": query=""        
        count=0
        for i in range(len(self.db)):
            if self.searchHistory.get()==1:
                for w in self.db[i].works:
                    if query in w[0]:
                        self.db.insert(0, self.db.pop(i))
                        count+=1
            if query in self.db[i].number\
            or query in self.db[i].type\
            or query in self.db[i].address\
            or query in self.db[i].getDate1()\
            or query in self.db[i].getCurrentPublisher()\
            or query in self.db[i].getDate2()\
            or query in str(self.db[i].getWorks())\
            or query in self.db[i].note\
            or query in self.db[i].image\
            or query in self.db[i].map:
                self.db.insert(0, self.db.pop(i))
                count+=1
        self.notebook.select(self.tabList)
        self.list.yview(0)        
        if count==0: self.quickTip("Ничего не найдено", 130)
        else: 
            self.update(sort=None)
            for i in range(count): self.list.itemconfig(i, bg="yellow")
            
    def openSingleTer(self, event=None):
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
    
    def openSelected(self, event=None):
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
        else: self.listPopup(event)
        
    def giveSelected(self, event=None):
        if len(self.list.curselection())==0: return
        elif self.chosenPublisher.get().strip()=="": self.setPublisher()                     
        if self.chosenPublisher.get().strip()!="":
            for i in range(len(self.list.curselection())):
                self.db[self.list.curselection()[i]].give(self)    
    
    def submitSelected(self, event=None):
        if len(self.list.curselection())==0: return
        elif self.chosenDate.get().strip()=="": self.chosenDate.focus_force()
        else:
            for i in range(len(self.list.curselection())): self.db[self.list.curselection()[i]].submit(self)
            
    def deleteSelected(self, event=None, all=False):
        if all==True:
            del self.db[:]
            self.save()
            self.updateR()
        elif len(self.list.curselection())==0: return                
        elif len(self.list.curselection())==1:
            if mb.askyesno("Удаление", "Удалить участок %s?" % self.db[self.list.curselection()[0]].number)==True:
                del self.db[self.list.curselection()[0]]
                self.save()
        else:
            if mb.askyesno("Удаление", "Удалить эти участки (%d)?" % len(self.list.curselection()))==True:
                count=0
                for i in self.list.curselection():
                    del self.db[i-count]
                    count+=1
                self.save()        
    
    def activateButtons(self, event=None):
        if len(self.list.curselection())!=0:
            self.selCount["text"]="Выбрано %d" % len(self.list.curselection())
            self.massEditButton.grid()
            self.massStatsButton.grid()
            self.massCopyButton.grid()
        else:
            self.selCount["text"]=""
            self.massEditButton.grid_remove()        
            self.massCopyButton.grid_remove()
            self.massStatsButton.grid_remove()
        self.buttonGive.state(["!disabled"])
        self.buttonSubmit.state(["!disabled"])
        if len(self.list.curselection())==0:
            self.buttonGive.state(["disabled"])
            self.buttonSubmit.state(["disabled"])
            
    def setPublisher(self):
        publisher=tk.Toplevel()
        publisher.wm_overrideredirect(True)
        publisher.title("Возвещатель")
        publisher.grab_set()
        publisher.focus_force()
        w = 270
        h = 40
        x = (publisher.winfo_screenwidth()/2) - (w/2)
        y = (publisher.winfo_screenheight()/2) - (h/2)-40
        publisher.geometry('%dx%d+%d+%d' % (w, h, x, y))
        frame=tk.Frame(publisher, bg="white", relief="solid", bd=1, padx=self.padx*3, pady=self.pady*3)
        frame.pack(expand=True, fill="both")
        tk.Label(frame, bg="white", text="Возвещатель:").pack(side="left")
        newPub=tk.Entry(frame, width=50, relief="flat")
        newPub.pack(side="left", fill="both")
        newPub.bind("<3>", self.standardMenu)
        def save(event):
            self.chosenPublisher.delete(0, "end")
            self.chosenPublisher.insert(0, newPub.get())
            publisher.destroy()
        newPub.bind("<Return>", save)
        publisher.bind("<Escape>", lambda x: publisher.destroy())
        newPub.focus_set()
        publisher.wait_window()
            
    def massCopy(self, window):
        window.clipboard_clear()
        for i in range(len(self.list.curselection())): window.clipboard_append("%s, " % self.db[self.list.curselection()[i]].number)               
        self.quickTip("Номера участков в буфере", 170)
    
    def setSort(self):
        self.settings[0]=str(self.sortType.get())
        self.saveSettings()
        self.update(sort=str(self.sortType.get()))
        
    def insertDate(self):
        self.chosenDate.delete(0, "end")
        self.chosenDate.insert(0, time.strftime("%d.%m", time.localtime()) + "." + str(int(time.strftime("%Y", time.localtime()))-2000))
        self.prevDate=self.chosenDate.get()
        
    def findFromReport(self, list, object, event=None):
        count=0
        if object=="type":
            query=self.types[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].type:
                    self.db.insert(0, self.db.pop(i))
                    count+=1   
        elif object=="publisher":
            query=self.publishers[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].getCurrentPublisher():
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        else:
            query=self.notes[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].note:
                    self.db.insert(0, self.db.pop(i))
                    count+=1      
        self.update(sort=None)
        for i in range(count): self.list.itemconfig(i, bg="yellow")
        self.notebook.select(self.tabList)

    def findStat(self, type, event=None):
        """ Functions to find stats from the stat list """
        count=0
        if type=="checked":
            for i in range(len(self.db)):
                if self.db[i].getStatus()==0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="given":
            for i in range(len(self.db)):
                if self.db[i].getStatus()!=0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="timedout":
            for i in range(len(self.db)):
                if self.db[i].getStatus()==2:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="workedYear":
            for i in range(len(self.db)):
                if self.db[i].getDelta2()<365:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="workedYearNot":
            for i in range(len(self.db)):
                if self.db[i].getDelta2()>=365:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="notWorked":
            for i in range(len(self.db)):
                if self.db[i].getWorks()==0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        else: return
        self.update(sort=None)
        self.notebook.select(self.tabList)
        for i in range(count): self.list.itemconfig(i, bg="yellow")
        self.list.yview(0)    

    def getStats(self, selection=None):
        """ Return statistics of selection of ters or all database is none"""
        if selection==None: selection=list(range(0, len(self.db)))
        worked=year=given=timedout=nonWorked=0
        averages=[]          
        for i in range(len(selection)):                                         # coloring
            if self.db[selection[i]].getPublisher()!="" and self.db[selection[i]].getStatus()!=0: given+=1
            if self.db[selection[i]].getWorks()==0: nonWorked+=1
            if self.db[selection[i]].getStatus()==2: timedout+=1
            if self.db[selection[i]].getWorks()==0 and self.filterWorked.get()==1:         
                self.list.itemconfig(i,                 fg="DodgerBlue")               # color for non-worked ters
            else: self.list.itemconfig(i,               fg="gray15")            # color for regular ters
            delta2=self.db[selection[i]].getDelta2()
            thisTerisNonWorked=0
            if delta2<=365:
                if self.workedTerYear.get()==0:
                    year+=1
                    thisTerisNonWorked=1
                elif self.db[selection[i]].getDelta1()<=365:
                    year+=1
                    thisTerisNonWorked=1
            if self.filterYear.get()==1 and thisTerisNonWorked==1:  self.list.itemconfig(i, bg='PaleGreen')
            elif i % 2 == 0: self.list.itemconfig(i,                bg="white") # 2 bg colors for stripes
            else:
                if self.listGrid.get()==1: self.list.itemconfig(i,  bg=self.stripe)
                else: self.list.itemconfig(i,                       bg="white")
            averages+=self.db[selection[i]].getAverageWork()
        worked=len(selection)-nonWorked
        try: averagesSum=sum(averages)/float(len(averages))
        except: averagesSum=0.0        
        return worked,nonWorked,year,given,timedout,averagesSum

    def showMassStats(self):        
        form=tk.Toplevel(bg="white")
        form.title("Статистика выборки (%d)" % len(self.list.curselection()))
        form.minsize(300,0)
        if os.name=="nt": form.iconbitmap(self.ico[5])
        form.focus_force()
        form.grid_columnconfigure (1, weight=1)
        form.bind("<Escape>", lambda x: form.destroy())
        padx=pady=1
        frame=tk.Frame(form, bg="white")                
        frame.pack(expand=True)
        frame.columnconfigure(0, weight=1)        
        form.columnconfigure(0, weight=1)        
        form.rowconfigure(0, weight=1)        
        stat=[]        
        for i, img in zip([0,1,2,3,4,5,6,7], [45,3,44,15,5,32,46,41]):
            stat.append(tk.Label(frame, bg="white", text="", image=self.img[img], compound="left"))
            stat[i].grid(column=0, row=i, padx=padx, pady=pady, sticky="w")        
        allStats=self.getStats(self.list.curselection())
        worked,nonWorked,year,given,timedout,averagesSum=allStats        
        for i in range(8): stat[i]["font"]=self.fontReport
        stat[0]["text"] =          "%-27s %4d, из них:"   % (" Участков в выборке:", len(self.list.curselection()))                                       
        try: stat[1]["text"] =     "%-27s %4d (%.1f%%)"   % (" В картотеке:", (len(self.list.curselection())-given), (len(self.list.curselection())-given)/len(self.list.curselection())*100)       
        except: stat[1]["text"] =  "%-27s    0   (0.0%%)" %  " В картотеке:"         
        try: stat[2]["text"] =     "%-27s %4d (%.1f%%)"   % (" На руках:", given, (given/len(self.list.curselection()))*100)
        except: stat[2]["text"] =  "%-27s    0   (0.0%%)" %  " На руках:"        
        try: stat[3]["text"] =     "%-27s %4d (%.1f%%)"   % (" Просрочено:", timedout, (timedout/len(self.list.curselection()))*100)      
        except: stat[3]["text"] =  "%-27s    0   (0.0%%)" %  " Просрочено:"         
        try: stat[4]["text"] =     "%-27s %4d (%.1f%%)"   % (" Обработано за год:", year, (year/len(self.list.curselection()))*100)
        except: stat[4]["text"] =  "%-27s    0   (0.0%%)" %  " Обработано за год:"        
        try: stat[5]["text"] =     "%-27s %4d (%.1f%%)"   % (" Не обработано за год:", len(self.list.curselection())-year, (100-(year/len(self.list.curselection()))*100))      
        except: stat[5]["text"] =  "%-27s    0   (0.0%%)" %  " Не обработано за год:"         
        try: stat[6]["text"] =     "%-27s %4d (%.1f%%)"   % (" Никогда не обрабатывалось:", nonWorked, (nonWorked/len(self.list.curselection()))*100)
        except: stat[6]["text"] =  "%-27s    0   (0.0%%)" %  " Никогда не обрабатывалось:"
        stat[7]["text"]=           "%-28s %.1f мес."      % (" Среднее время обработки:", allStats[5]/30.5)        
        content=stat[0]["text"]+"\n"+stat[1]["text"]+"\n"+stat[2]["text"]+"\n"+stat[3]["text"]+"\n"+stat[4]["text"]+"\n"+stat[5]["text"]+"\n"+stat[6]["text"]+"\n"+stat[7]["text"]        
        copyButton=ttk.Button(form, image=self.img[49], command=lambda: self.pasteToClipboard(form, content))
        copyButton.pack(side="right")
        self.CreateToolTip(copyButton, "Скопировать статистику в буфер обмена")        
        
    def standardMenu(self, e):
        self.conMenu.entryconfigure("Вырезать", command=lambda: e.widget.event_generate("<<Cut>>"))
        self.conMenu.entryconfigure("Копировать", command=lambda: e.widget.event_generate("<<Copy>>"))
        self.conMenu.entryconfigure("Вставить", command=lambda: e.widget.event_generate("<<Paste>>"))
        self.conMenu.entryconfigure("Удалить", command=lambda: e.widget.event_generate("<<Clear>>"))
        self.conMenu.entryconfigure("Выделить все", command=lambda: e.widget.event_generate("<<SelectAll>>"))              
        self.conMenu.tk.call("tk_popup", self.conMenu, e.x_root, e.y_root)
        
    class CreateToolTip(object):
        def __init__(self, widget, text='widget info', waittime=400):
            self.waittime = waittime #miliseconds
            self.wraplength = 180    #pixels
            self.widget = widget
            self.text = text
            self.widget.bind("<Enter>", self.enter)
            self.widget.bind("<Leave>", self.leave)
            self.widget.bind("<ButtonPress>", self.leave)
            self.id = None
            self.tw = None
        def enter(self, event=None): self.schedule()
        def leave(self, event=None):
            self.unschedule()
            self.hidetip()
        def schedule(self):
            self.unschedule()
            self.id = self.widget.after(self.waittime, self.showtip)
        def unschedule(self):
            id = self.id
            self.id = None
            if id: self.widget.after_cancel(id)
        def showtip(self, event=None):
            x = y = 0
            x, y, cx, cy = self.widget.bbox("insert")
            x += self.widget.winfo_rootx() + 25
            y += self.widget.winfo_rooty() + 20
            # creates a toplevel window
            self.tw = tk.Toplevel(self.widget)
            # Leaves only the label and removes the app window
            self.tw.wm_overrideredirect(True)
            self.tw.wm_geometry("+%d+%d" % (x, y))
            label = tk.Label(self.tw, text=self.text, justify='left',
                           background="#ffffff", relief='solid', borderwidth=1,
                           wraplength = self.wraplength)
            label.pack(ipadx=1)
        def hidetip(self):
            tw = self.tw
            self.tw= None
            if tw: tw.destroy()
        
    def quickTip(self, text, width, time=1000):
        confirm=tk.Toplevel(bg="white")
        confirm.wm_overrideredirect(True)        
        frame=tk.Frame(confirm, bg="white", relief='solid', borderwidth=1)
        frame.pack(expand=True, fill="both")
        tk.Label(frame, text=text, background="white", highlightbackground="gray50").pack(padx=self.padx, pady=self.pady, expand=True, fill="both")
        x = (confirm.winfo_screenwidth()/2) - (width/2)
        y = (confirm.winfo_screenheight()/2.5)
        confirm.geometry('+%d+%d' % (x, y))        
        confirm.after(time, lambda: confirm.destroy())

    def pasteToClipboard(self, form, content):
        form.clipboard_clear()
        form.clipboard_append(content)
