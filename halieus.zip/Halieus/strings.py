with open("root.py", "r", encoding="utf-8") as f: file=f.read()
#print(file[1])
start=count=0
while 1:
    if file[count]=="\"" and file[count+1]!="\"" and file[count+2]!="\"":
        start=count
        cur=count+1
        while 1:
            if file[cur]=="\"":
                print(file[start:cur])
                break
            else: cur+=1
    count+=1
    
