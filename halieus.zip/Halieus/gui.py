import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
import os
import datetime
import pickle
import data as d
from save import saveSettings
from icons import icon
from mass import massCreate
import time
import tkinter.messagebox as mb

class GUI:    
    
    def __init__(self, parent, load):
        
        self.db=load[0]
        self.settings=load[1]
        
        # Window set up         
        w = parent.winfo_screenwidth()/1.8
        h = parent.winfo_screenheight()/1.3
        ws = parent.winfo_screenwidth()
        hs = parent.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-50
        parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        parent.minsize(250,550)
        if os.name=="nt": parent.iconbitmap("icon.ico")
        parent.title("Halieus")
        parent.grid_columnconfigure (0, weight=1)
        parent.grid_rowconfigure    (5, weight=1)
        self.padx=3
        self.pady=2
        
        # Main menu
        menubar = tk.Menu(parent)
        filemenu1 = tk.Menu(menubar, tearoff=1) # Файл
        menubar.add_cascade(label="Файл", menu=filemenu1)
        def __save(): d.save(self, self.db)
        filemenu1.add_command(label="Сохранить", command=__save)
        def __export():
            ftypes = [('База данных Halieus', '.hal'), ('Все файлы', '*')]
            filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile='export.hal', defaultextension='.hal')#filetypes=ftypes, title=title, initialfile='--this directory--')
            if filename!="":
                try:
                    d.save(self, self.db, filename=filename)
                    mb.showinfo("Экспорт", "Экспорт в файл %s выполнен успешно." % filename)
                except: mb.showerror("Ошибка", "Экспорт не удался!")
        filemenu1.add_command(label="Экспорт базы", command=__export)
        def __import():
            ftypes = [('Файлы базы данных Halieus', '.hal'), ('Все файлы', '*')]
            filename = filedialog.askopenfilename(filetypes=ftypes, defaultextension='.hal')#filetypes=ftypes, title=title, initialfile='--this directory--')
            if filename!="":
                try:
                    with open(filename, "rb") as f: newDB = pickle.load(f) # load database 
                    del self.db[:]
                    self.db=newDB
                    self.update()
                    d.save(self, self.db)
                    mb.showinfo("Импорт", "Импорт файла %s выполнен успешно." % filename)
                except: mb.showerror("Ошибка", "Экспорт файла %s не удался! Файл испорчен или имеет неправильный формат." % filename)
        filemenu1.add_command(label="Импорт базы", command=__import)        
        def __clear():
            if mb.askyesno("Очистка базы", "Вы уверены, что хотите безвозвратно удалить все участки?")==True: # help window
                d.deleteTer(self, self.db, self.settings, all=True)
                self.update()
        filemenu1.add_command(label="Очистить базу", command=__clear)
        filemenu1.add_separator()
        filemenu1.add_command(label="Выход", command=parent.quit)
        filemenu2 = tk.Menu(menubar, tearoff=1) # Инструменты
        menubar.add_cascade(label="Инструменты", menu=filemenu2)
        def __massCreate(): massCreate(self, parent, self.db, self.settings)
        filemenu2.add_command(label="Массовое создание участков", command=__massCreate)
        filemenu2.add_command(label="Генерация .xls-файла")
        filemenu2.add_command(label="Настройки")
        filemenu3 = tk.Menu(menubar, tearoff=1) # Помощь
        menubar.add_cascade(label="Помощь", menu=filemenu3)
        filemenu3.add_command(label="Горячие клавиши")
        filemenu3.add_command(label="Поддержка")
        filemenu3.add_command(label="Проверка обновлений")
        def __about(): mb.showinfo("О программе", "Halieus 0.9.2\nEmail: antorix@gmail.com") # help window
        filemenu3.add_command(label="О программе", command=__about)
        #editmenu = tk.Menu(menubar, tearoff=0)
        parent.config(menu=menubar)
  
        # Selection count
        self.selCount=tk.Label(parent, fg="darkblue")
        self.selCount.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="w")
        
        # Main list        
        self.list = tk.Listbox(parent, bd=5, height=10, selectmode="extended", font="Tahoma 9", relief="flat")
        self.list.grid(column=0, row=1, rowspan=5, padx=3, pady=3, sticky="nwes")  
        rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=rightScrollbar.set)      
        rightScrollbar.pack(side="right", fill="y")
        bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
        self.list.configure(xscrollcommand=bottomScrollbar.set)
        bottomScrollbar.pack(side="bottom", fill="x")      
        
        # Operations on main list        
        def __open(event): # show ter card
            selected=self.list.curselection()
            if len(selected)==1: self.db[selected[0]].show(self, parent, self.db, self.settings)                    
            else: __listPopup(event)
        def __deactivateButtons(event):
            self.selCount["text"]=""
            self.buttonGive.state(["disabled"])
            self.buttonSubmit.state(["disabled"])
            self.massDelete.state(["disabled"])
        def __checkList():
            self.list.after(200, __checkList)
            if len(self.list.curselection())==0: __deactivateButtons(None)
        self.list.after_idle(__checkList)
        def __activateButtons(event):
            if len(self.list.curselection())!=0: self.selCount["text"]="Выбрано %d" % len(self.list.curselection())
            self.buttonGive.state(["!disabled"])
            self.buttonSubmit.state(["!disabled"])
            self.massDelete.state(["!disabled"])
        self.list.bind("<<ListboxSelect>>", __activateButtons)
        self.list.bind("<Double-Button-1>", __open)
        self.list.bind("<Return>", __open)
        def __listPopup(event): listmenu.post(event.x_root, event.y_root)
        self.list.bind("<Button-3>", __listPopup)
        self.list.bind("<space>", __listPopup)
        
        # Main list context menu
        listbar = tk.Menu(self.list)
        listmenu = tk.Menu(listbar, tearoff=0)
        def __give():
            d.giveTer(self, self.list.curselection(), self.db, self.settings)
            self.update()
        listmenu.add_command(label="Выдать", command=__give)        
        def __submit():
            d.submitTer(self, self.list.curselection(), self.db, self.settings)
            self.update()
        listmenu.add_command(label="Сдать", command=__submit)
        def __delete():
            d.deleteTer(self, self.db, self.settings) # delete from list
            self.update()
        listmenu.add_command(label="Удалить", command=__delete)
        listbar.add_cascade(label="Действия", menu=listmenu)
        #self.list.config(menu=listbar)
        def __give2(event):
            d.giveTer(self, self.list.curselection(), self.db, self.settings)
            self.update()
        self.list.bind("<KeyPress-1>", __give2)
        #self.list.bind("<Home>", __give2)
        def __submit2(event):
            d.submitTer(self, self.list.curselection(), self.db, self.settings)
            self.update()
        self.list.bind("<KeyPress-0>", __submit2)
        #self.list.bind("<End>", __submit2)                
        def __delete2(event):
            d.deleteTer(self, self.db, self.settings)
            self.update()
        self.list.bind("<Delete>", __delete2)
        self.list.bind("<BackSpace>", __delete2)        

        # Search
        self.searchFrame=ttk.Frame(parent)
        self.searchFrame.grid(column=0, row=0, sticky="e")
        ttk.Label(self.searchFrame, text="Поиск").grid(column=0, row=0, padx=3, sticky="e")
        self.search=ttk.Entry(self.searchFrame, width=30)
        self.search.grid(column=1, row=0, padx=self.padx, sticky="e")
        def __search(event): # enter search
            query = self.search.get()
            count=0
            for i in range(len(self.db)):
                if query in self.db[i].number\
                or query in self.db[i].type\
                or query in self.db[i].address\
                or query in self.db[i].getDate1()\
                or query in self.db[i].getPublisher()\
                or query in self.db[i].getDate2()\
                or query in str(self.db[i].getWorks())\
                or query in self.db[i].note\
                or query in self.db[i].image\
                or query in self.db[i].map:
                    self.db.insert(0, self.db.pop(i))
                    self.update(sort=None)
                    count+=1            
            for i in range(count): self.list.itemconfig(i, {"bg":'green2'})                
        self.search.bind("<Return>", __search)
        
        # Statistics        
        self.statsFrame=ttk.LabelFrame(parent, width=500, text="Статистика")
        self.statsFrame.grid(column=1, row=3, padx=self.padx, pady=self.pady*3, sticky="nwes")
        self.stat1=ttk.Label(self.statsFrame)
        self.stat2=ttk.Label(self.statsFrame)
        self.stat3=ttk.Label(self.statsFrame)
        self.stat4=ttk.Label(self.statsFrame)
        self.stat5=ttk.Label(self.statsFrame)
        self.stat1.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="w")
        self.stat2.grid(column=0, row=1, padx=self.padx, pady=self.pady, sticky="w")
        self.stat3.grid(column=0, row=2, padx=self.padx, pady=self.pady, sticky="w")
        self.stat4.grid(column=0, row=3, padx=self.padx, pady=self.pady, sticky="w")
        self.stat5.grid(column=0, row=4, padx=self.padx, pady=self.pady, sticky="w")
        self.filterNonWorked = tk.IntVar()
        self.filterNonWorked.set(0)
        ttk.Checkbutton(self.statsFrame, variable=self.filterNonWorked, onvalue=1, offvalue=0, command=self.update).grid(column=1, row=3, padx=self.padx, pady=self.pady, sticky="e")        
        self.filterYear = tk.IntVar()
        self.filterYear.set(0)
        ttk.Checkbutton(self.statsFrame, variable=self.filterYear, onvalue=1, offvalue=0, command=self.update).grid(column=1, row=4, padx=self.padx, pady=self.pady, sticky="e")                         
        
        # Sorting
        self.sortFrame = ttk.LabelFrame(parent, text="Сортировка")
        self.sortFrame.grid(column=1, row=4, padx=self.padx, pady=self.pady*3, sticky="nwes")
        self.sortType = tk.StringVar() # radio buttons
        self.sortType.set(self.settings[0])
        def setSort():
            self.settings[0]=str(self.sortType.get())
            saveSettings(self.settings)
            self.update(sort=str(self.sortType.get()))
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По номеру алфавитная", text="По номеру алфавитная (№1А)", command=setSort).grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="w")
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По номеру числовая", text="По номеру числовая (№1)", command=setSort).grid(column=0, row=1, padx=self.padx, pady=self.pady, sticky="w")
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По статусу", text="По статусу (%s)" % icon("сheck"), command=setSort).grid(column=0, row=2, padx=self.padx, pady=self.pady, sticky="w")
        self.sort2=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По типу", text="По типу (%s)" % icon("type"), command=setSort).grid(column=0, row=3, padx=self.padx, pady=self.pady, sticky="w")
        self.sort3=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По адресу", text="По адресу (%s)" % icon("cottage"), command=setSort).grid(column=0, row=4, padx=self.padx, pady=self.pady, sticky="w")
        self.sort4=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По возвещателю", text="По возвещателю (☺)", command=setSort).grid(column=0, row=5, padx=self.padx, pady=self.pady, sticky="w")        
        self.sort5=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По дате сдачи", text="По дате сдачи (%s)" % icon("calendar"), command=setSort).grid(column=0, row=6, padx=self.padx, pady=self.pady, sticky="w")
        self.sort6=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По числу обработок", text="По числу обработок (%s)" % icon("worked"), command=setSort).grid(column=0, row=7, padx=self.padx, pady=self.pady, sticky="w")
        self.sort7=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="По заметке", text="По заметке (%s)" % icon("note"), command=setSort).grid(column=0, row=8, padx=self.padx, pady=self.pady, sticky="w")             
        # Operations
        self.statsMass=ttk.LabelFrame(parent, text="Действия")
        self.statsMass.grid(column=0, row=6, columnspan=4, padx=self.padx, pady=self.pady, sticky="wns")        
        self.buttonGive = ttk.Button(self.statsMass, text="Выдать", command=__give)
        self.buttonGive.grid(column=0, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")
        self.buttonSubmit = ttk.Button(self.statsMass, text="Сдать", command=__submit)
        self.buttonSubmit.grid(column=1, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")
        self.massDelete=ttk.Button(self.statsMass, text="Удалить", command=__delete)
        self.massDelete.grid(column=2, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")
        ttk.Separator(self.statsMass, orient='vertical').grid(column=3, row=0, rowspan=2, padx=self.padx*4, pady=self.pady*4, sticky='ns')       
        ttk.Label(self.statsMass, text="Возвещатель").grid(column=4, row=0, padx=self.padx*3, sticky="ws")
        ttk.Label(self.statsMass, text="Дата (ДД.ММ.ГГ)").grid(column=5, row=0, columnspan=2, padx=self.padx, sticky="ws")        
        self.chosenPublisher=ttk.Entry(self.statsMass, width=15)
        self.chosenPublisher.grid(column=4, row=1, padx=self.padx*3, pady=self.pady*3, sticky="wn")
        self.chosenDate=ttk.Entry(self.statsMass, width=8)
        self.chosenDate.grid(column=5, row=1, pady=self.pady*3, sticky="wn")        
        def __checkDate(event):
            date=self.chosenDate.get().strip()            
            try:
                if  d.ifInt(date[0])==True and\
                    d.ifInt(date[1])==True and\
                    date[2]=="." and\
                    d.ifInt(date[3])==True and\
                    d.ifInt(date[4])==True and\
                    date[5]=="." and\
                    d.ifInt(date[6])==True and\
                    d.ifInt(date[7])==True and\
                    len(date)==8:        
                        correct=True
                else: correct=False
            except: correct=False
            if correct==False:
                self.chosenDate.delete(0, "end")
                mb.showerror("Ошибка даты", "Дата введена неправильно. Проверьте формат: ДД.ММ.ГГ, например 30.12.16.")
        self.chosenDate.bind("<FocusOut>", __checkDate)        
        style = ttk.Style()
        style.configure("small3.TButton", font=('', 7))
        def __insertDate():
            self.chosenDate.delete(0, "end")
            self.chosenDate.insert(0, self.getTodayDate())
        ttk.Button(self.statsMass, text="Сегодня", style="small3.TButton", command=__insertDate).grid(column=6, row=1, pady=self.pady*3, sticky="wn")       
        
        # New ter
        def __newTer2(event): d.newTer(self, parent, self.db, self.settings)            
        def __newTer(): d.newTer(self, parent, self.db, self.settings)            
        self.home = tk.PhotoImage(file="home.png")
        style = ttk.Style()
        style.configure("big.TButton", font=('', 10), color="green", image=self.home)
        new = ttk.Button(parent, text=" Новый участок", compound="left", style='big.TButton', command=__newTer)        
        new.grid(column=1, row=5, padx=0, pady=0, ipadx=10, ipady=10)
        
        # Footer
        self.statusBar = tk.Label(fg="gray20")
        self.statusBar.grid(column=0, columnspan=2, row=7, sticky="w")
        ttk.Separator(parent, orient='horizontal').grid (column=0, row=7, columnspan=2, sticky='nwe')
        ttk.Sizegrip(parent).grid(column=1, row=7, sticky="se")                
        
        # Parent window bindings
        parent.bind("<Insert>", __newTer2)        
        
        # Final preparation
        __insertDate()
        self.update()
        
    def update(self, sort="default"):
        """ Redraw ter list and update all stats """
        if sort=="default": sort = str(self.sortType.get()) # sort
        if sort=="По дате сдачи": self.db.sort(key=lambda x: d.convert(x.getDate2()), reverse=False) 
        if sort=="По номеру числовая":
            try: self.db.sort(key=lambda x: int(x.number), reverse=False) 
            except:
                mb.showerror("Ошибка сортировки", "В номерах участков используются нецифровые символы либо пустые номера, поэтому числовая сортировка невозможна. Переключаюсь на алфавитную.")
                sort="По номеру алфавитная"
                self.sortType.set("По номеру алфавитная")
                self.settings[0]=str(self.sortType.get())
                saveSettings(self.settings)
                self.db.sort(key=lambda x: x.number, reverse=False)                
        if sort=="По номеру алфавитная": self.db.sort(key=lambda x: x.number, reverse=False) 
        if sort=="По статусу": self.db.sort(key=lambda x: x.getStatus(), reverse=True) 
        if sort=="По типу": self.db.sort(key=lambda x: x.type, reverse=False) 
        if sort=="По адресу": self.db.sort(key=lambda x: x.address, reverse=False) 
        if sort=="По возвещателю": self.db.sort(key=lambda x: x.getPublisher(), reverse=False) 
        if sort=="По числу обработок": self.db.sort(key=lambda x: x.getWorks(), reverse=False) 
        if sort=="По заметке": self.db.sort(key=lambda x: x.note, reverse=False)         
        if sort==None: self.sortType.set(None)
        self.listContent = tk.StringVar(value=tuple(["%d) %s" % (i+1, self.db[i].retrieve()) for i in range(len(self.db))])) # fill list        
        self.list.configure(listvariable=self.listContent)    
        worked=0
        year=0
        for i in range(len(self.db)):            
            if self.db[i].getWorks()<=0 and self.filterNonWorked.get()==1: # set fg color
                self.list.itemconfig(i, fg="red")
                worked+=1
            else: self.list.itemconfig(i, fg="MidnightBlue")            
            delta=self.db[i].getDelta2()
            if delta==None or delta>365: year+=1
            if self.filterYear.get()==1 and (delta==None or delta>365): self.list.itemconfig(i, {"bg":'yellow2'}) # set bg color
            elif i % 2 == 0: self.list.itemconfig(i, bg="cornsilk") # set bg color
            else: self.list.itemconfig(i, bg="gray98")            
        given = nonWorked = 0 # stats
        for number in range(len(self.db)):
            if self.db[number].getPublisher() != "": given+=1
            if self.db[number].getWorks()==0: nonWorked+=1
        self.stat1["text"] = "Всего участков:\t\t%d" % len(self.db)
        self.stat2["text"] = "В картотеке:\t\t%d" % (len(self.db)-given)        
        try: self.stat3["text"] = "На руках:\t\t%d (%d%%)" % (given, (given/len(self.db))*100)
        except: self.stat3["text"] = "На руках:\t\t0"
        try: self.stat4["text"] = "Не обрабатывалось:\t%d (%d%%)" % (nonWorked, (nonWorked/len(self.db))*100)
        except: self.stat4["text"] = "Не обрабатывалось:\t0"
        try: self.stat5["text"] = "Не обработано за год:\t%d (%d%%)" % (year, (year/len(self.db))*100)
        except: self.stat5["text"] = "Не обработано за год:\t0"
        try: self.statusBar["text"] = "Последнее сохранение базы данных: %s" % datetime.datetime.fromtimestamp(os.path.getmtime("core.hal"))#(strftime("%Y-%m-%d", localtime()) + " " + strftime("%H:%M:%S", localtime()))    
        except: pass

    def getTodayDate(self):
        return time.strftime("%d.%m", time.localtime()) + "." + str(int(time.strftime("%Y", time.localtime()))-2000)
