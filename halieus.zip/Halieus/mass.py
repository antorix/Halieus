import tkinter as tk
from tkinter import ttk
import os
import data as d

def massCreate(gui, window, db, settings):
    
    """ Interface to create multiple ters """    
    # Window
    dialog = tk.Toplevel()
    dialog.grab_set()
    dialog.focus_force()
    w = 330
    h = 210
    ws = dialog.winfo_screenwidth()
    hs = dialog.winfo_screenheight()
    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2)-40
    dialog.geometry('%dx%d+%d+%d' % (w, h, x, y))
    dialog.grid_columnconfigure (1, weight=1)
    dialog.grid_rowconfigure (6, weight=1)
    dialog.minsize(w,h)
    dialog.maxsize(w,h)
    padx=5
    pady=5
    dialog.title("Массовое создание участков")
    if os.name=="nt": dialog.iconbitmap("icon.ico")
    
    # Text and values
    tip=tk.Message(dialog, text="Введите номера первого и последнего участков диапазона и их тип (необязательно)", width=300)
    tip.grid(column=0, columnspan=3, row=0, padx=padx, pady=pady, sticky="w")
    tk.Label(dialog, text="От:").grid(column=0, row=1, padx=padx*3, sticky="w")
    tk.Label(dialog, text="До:").grid(column=1, row=1, padx=padx*3, sticky="w")
    tk.Label(dialog, text="Тип:").grid(column=2, row=1, padx=padx*3, sticky="w")
    value1=ttk.Entry(dialog, width=8)
    value1.grid(column=0, row=2, padx=padx*3, sticky="wn")
    value2=ttk.Entry(dialog, width=8)
    value2.grid(column=1, row=2, padx=padx*3, sticky="wn")
    value3=ttk.Entry(dialog, width=8)
    value3.grid(column=2, row=2, padx=padx*3, sticky="wn") 
    
    # Error string
    error=tk.Label(dialog, fg="red")
    error.grid(column=0, row=4, columnspan=3, padx=padx*3, sticky="we")
    
    # Checkbutton
    var=tk.IntVar()
    var.set(0)
    if gui.chosenDate.get()=="": date=gui.getTodayDate()
    else: date=gui.chosenDate.get()
    ttk.Checkbutton(dialog, text="Добавить в участки одну обработку (обе даты:\n%s, возвещатель: «?»)" % date, variable=var, onvalue=1, offvalue=0).grid(column=0, row=5, columnspan=3, padx=padx, pady=pady, sticky="w")  
    
    # Button
    def __generate():        
        error["text"]=""
        try:
            if gui.chosenDate.get()=="": gui.chosenDate.insert(0, gui.getTodayDate())            
            for i in range(int(value1.get().strip()), int(value2.get().strip())+1):
                if var.get()==1: d.newTer(gui, window, db, settings, number=str(i), type=value3.get().strip(), worked=True, silent=True)
                else: d.newTer(gui, window, db, settings, number=str(i), type=value3.get().strip(), silent=True)            
        except: error["text"]="Введены некорректные числа, попробуйте еще"
        else:
            d.save(gui, db)
            gui.update()
    ttk.Button(dialog, text="Создать участки", command=__generate).grid(column=0, row=7, columnspan=3, ipady=5, padx=padx, pady=pady, sticky="wes")  
