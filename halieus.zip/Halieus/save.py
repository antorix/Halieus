import pickle

def save(gui, db, filename=False):
    if filename==False: filename="core.hal"
    with open(filename, "wb") as file: pickle.dump(db, file) 
    gui.update()

def saveSettings(settings):    
    with open("settings.ini", "w", encoding="utf-8") as file: file.write("Sort type="+settings[0])
