#!/usr/bin/python
# -*- coding: utf-8 -*-
import xlwt
import xlrd
import os
from tkinter import filedialog
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox as mb

def massCreate(root):
    """ Interface to create multiple ters """    
    dialog = tk.Toplevel()
    dialog.title("Массовое создание участков")
    if os.name=="nt": dialog.iconbitmap("icon.ico")
    dialog.grab_set()
    dialog.focus_force()
    w = 330
    h = 220
    x = (dialog.winfo_screenwidth()/2) - (w/2)
    y = (dialog.winfo_screenheight()/2) - (h/2)-40
    dialog.geometry('%dx%d+%d+%d' % (w, h, x, y))
    dialog.grid_columnconfigure (1, weight=1)
    dialog.grid_rowconfigure (5, weight=1)
    dialog.minsize(w,h)
    padx=pady=5
    tip=tk.Message(dialog, text="Введите номера первого и последнего участков диапазона и их тип (необязательно)", width=300)
    tip.grid(column=0, columnspan=3, row=0, padx=padx, sticky="w")
    tk.Label(dialog, text="От:").grid(column=0, row=1, padx=padx*3, sticky="w")
    tk.Label(dialog, text="До:").grid(column=1, row=1, padx=padx*3, sticky="w")
    tk.Label(dialog, text="Тип:").grid(column=2, row=1, padx=padx*3, sticky="w")
    value1=ttk.Entry(dialog, width=8)
    value1.grid(column=0, row=2, padx=padx*3, sticky="wn")
    value2=ttk.Entry(dialog, width=8)
    value2.grid(column=1, row=2, padx=padx*3, sticky="wn")
    value3=ttk.Entry(dialog, width=8)
    value3.grid(column=2, row=2, padx=padx*3, sticky="wn") 
    error=tk.Label(dialog, fg="red")
    error.grid(column=0, row=3, columnspan=3, padx=padx*3, sticky="wes")
    var=tk.IntVar()
    var.set(0)
    if root.chosenDate.get()=="": date=root.getTodayDate()
    else: date=root.chosenDate.get()
    ttk.Checkbutton(dialog, text="Добавить в участки одну обработку (обе даты:\n%s, возвещатель: «?»)" % date, variable=var).grid(column=0, row=4, columnspan=3, padx=padx, pady=pady, sticky="w")  
    def generate():        
        error["text"]=""
        try:
            if root.chosenDate.get()=="": root.chosenDate.insert(0, root.getTodayDate())            
            for i in range(int(value1.get().strip()), int(value2.get().strip())+1):
                if var.get()==1: root.newTer(root, number=str(i), type=value3.get().strip(), worked=True, silent=True)
                else: root.newTer(root, number=str(i), type=value3.get().strip(), silent=True)            
        except: error["text"]="Введены некорректные числа, попробуйте еще"
        else: root.save()    
    ttk.Button(dialog, text="Создать участки", style="big.TButton", image=root.imgMass, compound="left", command=generate).grid(column=0, row=6, columnspan=3, ipadx=5, ipady=5, padx=padx, pady=pady, sticky="s")
    def quit(event): dialog.destroy()
    dialog.bind("<Escape>", quit)

def massEdit(root):
    print(root.list.curselection())

def exportXLS(root):
    wb = xlwt.Workbook()
    ws1=wb.add_sheet("Статистика")    
    content =  (    ("Всего участков:",     "%d " % len(root.db),),
                    ("В картотеке:",   "%d " % int(len(root.db)-(root.given)),),
                    ("На руках:", "%d (%d%%) " % (root.given, (root.given/len(root.db))*100),),
                    ("Обработано за год*:", "%d (%d%%) " % (root.year, (root.year/len(root.db))*100),),
                    ("Не обрабатывалось:", "%d (%d%%) " % (root.nonWorked, (root.nonWorked/len(root.db))*100),),
                    ("",""),
                    ("*В S-13 обработанные за год",""),
                    ("участки помечены звездочкой",""),
                    ("",""),
                    ("(Смотрите следующие вкладки)","")
    )
    for i, row in enumerate(content):
        for j, col in enumerate(row):
            ws1.write(i, j, col)
    ws1.col(0).width = 256 * max([len(row[0]) for row in content])
    ws2 = wb.add_sheet("Список участков")
    try: root.db.sort(key=lambda x: float(x.number), reverse=False) 
    except: root.db.sort(key=lambda x: x.number, reverse=False)
    content = [root.db[i].exportXLS_List() for i in range(len(root.db))]
    for i, row in enumerate(content):
        for j, col in enumerate(row):
            ws2.write(i, j, col)
    ws2.col(0).width = 3000     # number
    ws2.col(1).width = 3000     # type
    ws2.col(2).width = 15000    # address
    ws2.col(3).width = 5000     # note
    ws2.col(4).width = 12000    # map
    ws2.col(5).width = 4000     # image
    terPerPage=100
    totalPages = len(root.db) // terPerPage
    ws3=[]
    border = xlwt.easyxf('border: left thin')
    for subpage in range(totalPages+1):
        x=subpage+1
        ws3.append(wb.add_sheet("S-13 (%d)" % x))
        start=subpage*terPerPage
        end=start+terPerPage
        column=0
        for index in range(start, end):
            if index==len(root.db): break
            if root.db[index].getDelta2()<365: asterisk="*"
            else: asterisk=""
            ws3[subpage].write(0,column, "%s%s " % (root.db[index].number, asterisk), style=border)# ter number        
            ws3[subpage].write(1,column, "", style=border)
            row=2
            for work in range(len(root.db[index].works)):                       # single work            
                ws3[subpage].write(row,column, "%d) %s:" % (work+1, root.db[index].works[work][0]), style=border) 
                ws3[subpage].write(row+1,column, root.db[index].works[work][1]+" – ", style=border) 
                ws3[subpage].write(row+1,column+1, "%s " % root.db[index].works[work][2])
                if work+2<=len(root.db[index].works):
                    ws3[subpage].write(row+2,column, "", style=border)
                    ws3[subpage].write(row+3,column, "", style=border)
                row+=4
            column+=2
    ftypes = [('Книга Excel 97-2003 (*.xls)', '.xls')]
    filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile='Территория собрания.xls', defaultextension='.xls')
    if filename!="":
        try: wb.save(filename)
        except: mb.showerror("Ошибка", "Не удалось сохранить файл %s!" % filename)
    
def importXLS(root):
    dialog=tk.Toplevel()
    dialog.title("Импорт участков из Excel")
    if os.name=="nt": dialog.iconbitmap("icon.ico")
    dialog.grab_set()
    dialog.focus_force()
    w = 520
    h = 430
    x = (dialog.winfo_screenwidth()/2) - (w/2)
    y = (dialog.winfo_screenheight()/2) - (h/2)-40
    dialog.geometry('%dx%d+%d+%d' % (w, h, x, y))
    dialog.minsize(w,h)
    tk.Message(dialog, text=
    "Для импорта участков из Excel-файла он должен отвечать следующим условиям:\n\n\
● Формат файла – .xls (Excel 97–2003).\n\n\
● Участки находятся на первой вкладке (листе).\n\n\
● Каждому участку соответствует одна строка.\n\n\
● Полям участка соответствуют следующие столбцы: A – номер, B – тип, C – адрес, D – заметка, E – карта, F – картинка. Ни одно поле не обязательно, но если между участками есть полностью пустые строки, они будут импортированы как пустые участки.\n\n\
Примерно так:", justify="left", width=400).pack(side="top", padx=5, pady=5)
    ttk.Label(dialog, image=root.imgExcel).pack(side="top", padx=5, pady=5)
    var=tk.IntVar()
    var.set(0)
    if root.chosenDate.get()=="": date=root.getTodayDate()
    else: date=root.chosenDate.get()
    ttk.Checkbutton(dialog, text="Добавить в участки одну обработку (обе даты: %s, возвещатель: «?»)" % date, variable=var).pack(pady=10, side="top")
    
    def format(value):
        value=(str(value)).strip()
        if ".0" in value: value=value[ : value.index(".0")]
        return value
    
    def generate():
        ftypes = [('Книга Excel 97-2003 (*.xls)', '.xls')]
        filename=filedialog.askopenfilename(filetypes=ftypes, defaultextension='.xls')
        if filename!="":                        
            try: book = xlrd.open_workbook(filename, formatting_info=True)
            except: mb.showerror("Ошибка", "Не удалось импортировать файл %s. Он поврежден или имеет неверный формат." % filename)
            else:
                sheet = book.sheet_by_index(0)    
                for row in range(sheet.nrows):
                    if sheet.ncols>=1: number=format(sheet.cell(row,0).value)
                    else: number=""
                    if sheet.ncols>=2: type=format(sheet.cell(row,1).value)
                    else: type=""
                    if sheet.ncols>=3: address=format(sheet.cell(row,2).value)
                    else: address=""
                    if sheet.ncols>=4: note=format(sheet.cell(row,3).value)
                    else: note=""
                    if sheet.ncols>=5: map=format(sheet.cell(row,4).value)
                    else: image=""
                    if sheet.ncols>=6: image=format(sheet.cell(row,5).value)
                    else: map=""
                    if var.get()==1: root.newTer(number=number, type=type, address=address, note=note, image=image, map=map, silent=True, worked=True)
                    else: root.newTer(number=number, type=type, address=address, note=note, image=image, map=map, silent=True)                   
                dialog.destroy()
                root.save()
                mb.showinfo("Импорт", "Импорт успешно выполнен! Если вас не устраивает результат, восстановите резервную копию (Файл → Импорт → \"backup.hal\").")
    ttk.Button(dialog, text="Импортировать участки", style="big.TButton", image=root.imgXLS, compound="left", command=generate).pack(side="bottom", padx=5, pady=5, ipadx=5, ipady=5)
    def quit(event): dialog.destroy()
    dialog.bind("<Escape>", quit)

"""def exportS13txt(root):        
    content =   "Общая статистика территории:\n\n"
    content +=  "Всего участков: %d\n" % len(root.db)
    content +=  "В картотеке: %d\n" % int(len(root.db)-(root.given))
    content +=  "На руках: %d (%d%%)\n" % (root.given, (root.given/len(root.db))*100)
    content +=  "Обработано за год: %d (%d%%)\n" % (root.year, (root.year/len(root.db))*100)
    content +=  "Не обрабатывалось: %d (%d%%)\n" % (root.nonWorked, (root.nonWorked/len(root.db))*100)
    content +=  "════════════════════════════\n\n"
    content +=  "Данные о назначении участков (участки,\nобработанные за последний\nгод, помечены звездочкой):\n\n"
    for index in range(len(root.db)):
        if root.db[index].getDelta2()<365: asterisk="*"
        else: asterisk=""
        content +=      "┌─────── %s%s ─────────\n" % (root.db[index].number, asterisk)
        content +=      "\n"
        for work in range(len(root.db[index].works)):                           # single work            
            content +=  "%d) %s:\n" % (work+1, root.db[index].works[work][0])
            content +=  "%s — %s\n\n" % (root.db[index].works[work][1], root.db[index].works[work][2])
        content +=      "════════════════════════════\n\n"
    ftypes = [('Текстовый файл (*.txt)', '.txt')]
    filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile='S-13.txt', defaultextension='.txt')
    if filename!="":
        try:
            with open(filename, "w", encoding="utf-8") as file: file.write(content)         
        except: mb.showerror("Ошибка", "Не удалось сохранить файл %s!" % filename)"""
