#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk
import os
import webbrowser
import data as d
import tkinter.messagebox as mb

def terCard(ter, root, new):
    """ Show ter card"""
    
    # Card set up    
    card = tk.Toplevel()
    card.focus_force()
    card.grab_set()
    w = 520
    h = 400
    ws = card.winfo_screenwidth()
    hs = card.winfo_screenheight()
    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2)-40
    card.geometry('%dx%d+%d+%d' % (w, h, x, y))
    card.minsize(w,h)
    card.maxsize(w,h)
    padx=5
    pady=5
    card.grid_columnconfigure (0, weight=1)
    card.grid_rowconfigure    (0, weight=0)
    card.grid_rowconfigure    (1, weight=5)
    card.title("№%s" % ter.number)
    if os.name=="nt": card.iconbitmap("images/card.ico")
    
    # Images set up
    img=[]
    img.append(tk.PhotoImage(file="images/check.png"))     # 0
    img.append(tk.PhotoImage(file="images/clock.png"))     # 1
    img.append(tk.PhotoImage(file="images/timeout.png"))   # 2
    img.append(tk.PhotoImage(file="images/info.png"))      # 3
    img.append(tk.PhotoImage(file="images/work.png"))      # 4
    img.append(tk.PhotoImage(file="images/map.png"))       # 5
    img.append(tk.PhotoImage(file="images/image.png"))     # 6
    img.append(tk.PhotoImage(file="images/submit.png"))    # 7
    img.append(tk.PhotoImage(file="images/give.png"))      # 8
    img.append(tk.PhotoImage(file="images/save.png"))      # 9
    img.append(tk.PhotoImage(file="images/warning.png"))   # 10
    img.append(tk.PhotoImage(file="images/delete.png"))    # 11
    
    # Status frame        
    def action(event):        
        if ter.getStatus()==0:
            ter.give(root.chosenPublisher.get().strip(), root, fromTerCard=True)            
            buttonAction["text"]="Выдать"
        else:
            ter.submit(root, fromTerCard=True)
            buttonAction["text"]="Сдать"
        drawStatus()
        drawHistory()
    def drawStatus():
        """ Draw and update status information for card """  
        if ter.getStatus()==0:
            statusLabel["text"]="В картотеке"
            statusLabel["image"]=img[0]
            buttonAction["text"]="Выдать"
            buttonAction["image"]=img[8]
            card.bind("<Alt-Home>", action)
            card.bind("<Alt-End", None)
        elif ter.getStatus()==1:
            statusLabel["text"]="Обрабатывается возвещателем %s\nВыдан %s (%s дн. назад)" % (ter.getPublisher(), ter.getDate1(), ter.getDelta1())
            statusLabel["image"]=img[1]
            buttonAction["text"]="Сдать"
            buttonAction["image"]=img[7]
            card.bind("<Alt-Home>", None)
            card.bind("<Alt-End>", action)
        else:
            statusLabel["text"]="Просрочен возвещателем %s\nВыдан %s (%s дн. назад)" % (ter.getPublisher(), ter.getDate1(), ter.getDelta1())
            statusLabel["image"]=img[2]
            buttonAction["text"]="Сдать"
            buttonAction["image"]=img[7]
            card.bind("<Alt-Home>", None)
            card.bind("<Alt-End>", action)    
    statusFrame=ttk.LabelFrame(card, text="Статус участка")
    statusFrame.grid_columnconfigure (1, weight=1)
    statusFrame.grid(column=0, row=0, columnspan=3, padx=padx, pady=pady, sticky="nesw")
    statusLabel=tk.Label(statusFrame, compound="left", justify="left", padx=5)
    statusLabel.pack(padx=5, pady=5, side="left") 
    buttonAction=ttk.Button(statusFrame, compound="left")
    buttonAction.bind("<1>", action)
    drawStatus()
    ttk.Label(statusFrame).pack(pady=5, side="left")    
    buttonAction.pack(padx=5, pady=5, side="right")
    
    # Notebook set up
    nb=ttk.Notebook(card)
    nb.grid(column=0, row=1, columnspan=3, padx=padx, pady=pady, sticky="nesw")
    tab1=ttk.Frame(nb)    
    nb.add(tab1, text="Данные", image=img[3], compound="left")
    tab2=ttk.Frame(nb)
    nb.add(tab2, text="История", image=img[4], compound="left")
    
    # Tab 1 (info)
    tab1.grid_columnconfigure(1, weight=1) # tags
    tab1.grid_rowconfigure(0, weight=1)
    tab1.grid_rowconfigure(1, weight=1)
    tab1.grid_rowconfigure(2, weight=1)
    tab1.grid_rowconfigure(3, weight=1)
    tab1.grid_rowconfigure(4, weight=1)
    tab1.grid_rowconfigure(5, weight=1)
    ttk.Label(tab1, text="Номер").grid(column=0, row=0, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Тип").grid(column=0, row=1, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Адрес").grid(column=0, row=2, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Заметка").grid(column=0, row=3, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Карта").grid(column=0, row=4, padx=padx, pady=pady, sticky="e")
    number=ttk.Entry(tab1)
    number.grid(column=1, row=0, padx=padx, pady=pady, sticky="we")
    number.focus_force()
    number.insert(0, ter.number)
    def updateTitle(event): card.title("№%s" % number.get().strip())        
    number.bind("<KeyRelease>", updateTitle)
    type=ttk.Entry(tab1)                                                        # fields
    type.grid(column=1, row=1, padx=padx, pady=pady, sticky="we")
    type.insert(0, ter.type)
    address=ttk.Entry(tab1)
    address.grid(column=1, row=2, padx=padx, pady=pady, sticky="we")
    address.insert(0, ter.address)
    note=ttk.Entry(tab1)
    note.grid(column=1, row=3, padx=padx, pady=pady, sticky="we")
    note.insert(0, ter.note)
    map=ttk.Entry(tab1)
    map.grid(column=1, row=4, padx=padx, pady=pady, sticky="we")
    map.insert(0, ter.map)
    if root.images.get()==1:
        ttk.Label(tab1, text="Картинка").grid(column=0, row=5, padx=padx, pady=pady, sticky="e")
        image=ttk.Entry(tab1)
        image.grid(column=1, row=5, padx=padx, pady=pady, sticky="we")
        image.insert(0, ter.image)
        def insertImage():
            image.delete(0, "end")
            image.insert(0, "%s" % number.get().strip())
            if image.get().strip()!="": buttonImage.state(["!disabled"])
            else: buttonImage.state(["disabled"])
        ttk.Button(tab1, text="Как номер", style="small2.TButton", command=insertImage).grid(padx=5, pady=5, column=2, row=5, sticky="w")
    style = ttk.Style()                                                         # buttons
    style.configure("small2.TButton", font=('', 8))
    def insertMap():
        map.delete(0, "end")
        map.insert(0, "https://yandex.ru/maps/?text=%s" % address.get().strip())
        if map.get().strip()!="": buttonMap.state(["!disabled"])
        else: buttonMap.state(["disabled"])
    ttk.Button(tab1, text="Как адрес", style="small2.TButton", command=insertMap).grid(padx=5, pady=5, column=2, row=4, sticky="w") 
    
    # Map & Image
    buttonSize=1
    subframe=ttk.Frame(tab1)
    subframe.grid(column=1, row=8, padx=4, pady=3, sticky="ws")    
    def openMap(): webbrowser.open(map.get())
    buttonMap = ttk.Button(subframe, image=img[5], command=openMap)
    buttonMap.grid(column=0, row=0, ipadx=buttonSize, ipady=buttonSize, sticky="ws")
    def openImage():
        if os.path.exists("%s.png" % image.get().strip()): webbrowser.open("%s.png" % image.get().strip())
        else: mb.showerror("Ошибка", "Файл не найден! Проверьте наличие файла %s.png в папке программы." % image.get())
    def checkButtonMapState(event):
        if map.get().strip()!="": buttonMap.state(["!disabled"])
        else: buttonMap.state(["disabled"])
    map.bind("<KeyRelease>", checkButtonMapState)
    checkButtonMapState(None)
    def checkButtonImageState(event):
        if image.get().strip()!="": buttonImage.state(["!disabled"])
        else: buttonImage.state(["disabled"])
    if root.images.get()==1:
        buttonImage = ttk.Button(subframe, image=img[6], command=openImage)
        buttonImage.grid(column=1, row=0, padx=2, ipadx=buttonSize, ipady=buttonSize, sticky="ws")
        image.bind("<KeyRelease>", checkButtonImageState)
        checkButtonImageState(None)
    
    # Tab 2 (history)
    def drawHistory():
        """ Draw and update history information on tab 2 """
        text2=" "
        if ter.getWorks()==0: info.configure(image=img[10])
        elif ter.getWorks()>0:
            text2=". Последняя: %s (%d дн. назад) " % (ter.getDate2(), ter.getDelta2())
            if ter.getDelta2()>365: info.configure(image=img[10])
        info["text"]="Обработок: %d%s" % (ter.getWorks(), text2)
        workContent=tk.StringVar(value=tuple(["%d) %s: %s – %s" % (i+1, ter.works[i][0], ter.works[i][1], ter.works[i][2]) for i in range(len(ter.works))])) # fill list        
        workList.configure(listvariable=workContent)
    tab2.grid_columnconfigure (1, weight=1)
    tab2.grid_rowconfigure (1, weight=1)
    info=tk.Label(tab2, image=None, compound="right")
    info.grid(column=0, row=0, padx=3, pady=pady, sticky="w")       
    workList=tk.Listbox(tab2, relief="flat", activestyle="dotbox", font="Tahoma 9")    
    workList.grid(column=0, row=1, columnspan=2, padx=padx*2, pady=pady, sticky="nesw")    
    drawHistory()    
    rightScrollbar = ttk.Scrollbar(workList, orient="vertical", command=workList.yview)
    workList.configure(yscrollcommand=rightScrollbar.set)      
    rightScrollbar.pack(side="right", fill="y")

    # History edit
    def openVisit(event):
        sel=workList.curselection()[0]
        if ter.works[sel][0]=="" or ter.works[sel][1]=="" or ter.works[sel][2]=="":
            mb.showwarning("Ошибка", "Нельзя отредактировать незаконченную обработку.")
            return
        visit=tk.Toplevel()
        visit.focus_force()
        visit.grab_set()
        w = 320
        h = 150
        ws = visit.winfo_screenwidth()
        hs = visit.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        visit.geometry('%dx%d+%d+%d' % (w, h, x, y))
        visit.minsize(w,h)
        visit.maxsize(w,h)
        visit.grid_columnconfigure (0, weight=1)
        visit.grid_rowconfigure    (0, weight=0)
        sel2=sel+1
        visit.title("%d)" % sel2)
        if os.name=="nt": visit.iconbitmap("images/work.ico")
        def quitVisit(event):
            visit.destroy()
            card.grab_set()
            workList.focus_force()
        visit.bind("<Escape>", quitVisit)
        visit.columnconfigure(1, weight=1)
        visit.rowconfigure(3, weight=1)
        ttk.Label(visit, text="Возвещатель:").grid(column=0, row=0, padx=padx, pady=pady, sticky="e")
        ttk.Label(visit, text="Дата выдачи участка:").grid(column=0, row=1, padx=padx, pady=pady, sticky="e")
        ttk.Label(visit, text="Дата сдачи участка:").grid(column=0, row=2, padx=padx, pady=pady, sticky="e")
        name=ttk.Entry(visit)
        name.grid(column=1, columnspan=2, row=0, padx=padx, pady=pady, sticky="we")
        name.insert(0, ter.works[sel][0])
        date1=ttk.Entry(visit)
        date1.grid(column=1, columnspan=2, row=1, padx=padx, pady=pady, sticky="we")
        date1.insert(0, ter.works[sel][1])
        date2=ttk.Entry(visit)
        date2.grid(column=1, columnspan=2, row=2, padx=padx, pady=pady, sticky="we")
        date2.insert(0, ter.works[sel][2])
        wrongDate=tk.Label(visit, fg="red")
        wrongDate.grid(column=0, columnspan=3, padx=padx, row=3)
        def delete():
            del ter.works[sel]
            drawHistory()
            quitVisit(None)
        ttk.Button(visit, text="Удалить", image=img[11], compound="left", command=delete).grid(column=0, row=4, padx=padx, pady=pady, sticky="w")
        def saveVisit():
            if d.checkDate(date1.get(), silent=True)==False or d.checkDate(date2.get(), silent=True)==False: wrongDate["text"]="Проверьте правильность ввода дат (ДД.ММ.ГГ)"
            elif name.get().strip()=="": wrongDate["text"]="Имя не может быть пустым"
            else:
                ter.works[sel][0]=name.get().strip()
                ter.works[sel][1]=date1.get().strip()
                ter.works[sel][2]=date2.get().strip()
                drawHistory()
                quitVisit(None)
        ttk.Button(visit, text="Сохранить", image=img[9], compound="left", command=saveVisit).grid(column=1, row=4, padx=padx, pady=pady, sticky="e")
        def __quit(): quitVisit(None)
        ttk.Button(visit, text="Отмена", command=__quit).grid(column=2, row=4, padx=padx, pady=pady, sticky="w")
    workList.bind("<Double-Button-1>", openVisit)
    workList.bind("<Return>", openVisit)
    
    # Save and cancel    
    buttonSave=ttk.Button(card, text="Сохранить", image=img[9], compound="left")
    def saveCard(event): 
        ter.number=number.get().strip()
        ter.type=type.get().strip()
        ter.address=address.get().strip()
        ter.map=map.get().strip()
        if root.images.get()==1: ter.image=image.get().strip()
        ter.note=note.get().strip()
        root.save()
        card.destroy()
        root.list.focus_force()
    buttonSave.bind("<Button-1>", saveCard)
    buttonSave.grid(padx=padx, pady=pady*2, ipadx=padx*5, ipady=3, column=1, row=2)
    def cancelChanges(event):
        result, root.db, root.settings=d.load()
        root.update()
        card.destroy()
        root.list.focus_force()
    buttonCancel=ttk.Button(card, text="Отмена")   
    buttonCancel.bind("<Button-1>", cancelChanges)
    buttonCancel.grid(padx=padx, pady=pady*2, ipadx=padx*5, ipady=3, column=2, row=2)
    
    # Main list context menu
    listbar = tk.Menu(workList)
    listmenu = tk.Menu(listbar, tearoff=0)
    def paste(): number.insert(number.index(tk.INSERT), card.selection_get(selection = "CLIPBOARD"))
    listmenu.add_command(label="Вставить", command=paste)
    listbar.add_cascade(label="Действия", menu=listmenu)                           
    
    # Hotkeys    
    number.bind("<Return>", saveCard)
    def popup(event): listmenu.post(event.x_root, event.y_root)
    number.bind("<3>", popup)
    type.bind("<Return>", saveCard)
    address.bind("<Return>", saveCard)
    note.bind("<Return>", saveCard)
    map.bind("<Return>", saveCard)
    if root.images.get()==1: image.bind("<Return>", saveCard)
    card.bind("<Escape>", cancelChanges)
