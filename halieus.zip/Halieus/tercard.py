import tkinter as tk
from tkinter import ttk
import os
import webbrowser
from save import save
import data as d
from icons import icon
import tkinter.messagebox as mb

def drawStatus(statusFrame, statusLabel, buttonAction, ter, img, gui):
    """ Draw and update status information for card """  
    if ter.getStatus()==0:
        statusLabel["text"]="В картотеке"
        statusLabel["image"]=img[0]
        buttonAction["text"]="Выдать"
    elif ter.getStatus()==1:
        statusLabel["text"]="Обрабатывается возвещателем %s\nВыдан %s (%s дн. назад)" % (ter.getPublisher(), ter.getDate1(), ter.getDelta1())
        statusLabel["image"]=img[1]
        buttonAction["text"]="Сдать"
    else:
        statusLabel["text"]="Просрочен возвещателем %s\nВыдан %s (%s дн. назад)" % (ter.getPublisher(), ter.getDate1(), ter.getDelta1())
        statusLabel["image"]=img[2]
        buttonAction["text"]="Сдать"

def drawHistory(workList, info, timeout, ter, image):
    """ Draw and update history information on tab 2 """
    if ter.getWorks()>0:
        text2=". Последняя: %s (%d дн. назад)" % (ter.getDate2(), ter.getDelta2())
        if ter.getDelta2()>365:
            text2+=" %s" % icon("warning")
            #timeout.configure(image=image)
        #else: warning["image"]=None
    else: text2=""
    info["text"]="Обработок: %d%s" % (ter.getWorks(), text2)
    workContent=tk.StringVar(value=tuple(["%d) %s: %s – %s" % (i+1, ter.works[i][0], ter.works[i][1], ter.works[i][2]) for i in range(len(ter.works))])) # fill list        
    workList.configure(listvariable=workContent)

def open(ter, gui, window, db, settings, new=False):
    
    """ Show ter card"""    
    # Card set up    
    card = tk.Toplevel()
    card.focus_force()
    card.grab_set()
    w = 520
    h = 420
    ws = card.winfo_screenwidth()
    hs = card.winfo_screenheight()
    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2)-40
    card.geometry('%dx%d+%d+%d' % (w, h, x, y))
    card.minsize(w,h)
    card.maxsize(w,h)
    padx=5
    pady=5
    card.grid_columnconfigure (0, weight=1)
    card.grid_rowconfigure    (0, weight=0)
    card.grid_rowconfigure    (1, weight=5)
    card.title("%s" % ter.number)
    def __quit(event):
        if new==True: del db[len(db)-1]
        gui.update()
        card.destroy() # close card
    card.bind("<Escape>", __quit)
    if os.name=="nt": card.iconbitmap("card.ico")
    
    # Images set up
    img=[]
    img.append(tk.PhotoImage(file="check.png"))     # 0
    img.append(tk.PhotoImage(file="clock.png"))     # 1
    img.append(tk.PhotoImage(file="timeout.png"))   # 2
    img.append(tk.PhotoImage(file="info.png"))      # 3
    img.append(tk.PhotoImage(file="work.png"))      # 4
    img.append(tk.PhotoImage(file="map.png"))       # 5
    img.append(tk.PhotoImage(file="image.png"))     # 6      
    
    # Status frame    
    statusFrame=ttk.LabelFrame(card, text="Статус участка")
    statusFrame.grid_columnconfigure (1, weight=1)
    statusFrame.grid(column=0, row=0, columnspan=3, padx=padx, pady=pady, sticky="nesw")
    statusLabel=tk.Label(statusFrame, compound="left", justify="left", padx=5)
    statusLabel.pack(padx=5, pady=5, side="left") 
    def __action():        
        if ter.getStatus()==0:
            d.giveTer(gui, gui.list.curselection(), db, settings, ter=ter)
            buttonAction["text"]="Выдать"
        else:
            d.submitTer(gui, gui.list.curselection(), db, settings, ter=ter)
            buttonAction["text"]="Сдать"
        drawStatus(statusFrame, statusLabel, buttonAction, ter, img, gui)
        drawHistory(workList, info, timeout, ter, img)
    buttonAction=ttk.Button(statusFrame, command=__action)
    drawStatus(statusFrame, statusLabel, buttonAction,ter, img, gui)
    ttk.Label(statusFrame).pack(pady=5, side="left")    
    buttonAction.pack(padx=5, pady=5, side="right")
    
    # Notebook set up
    nb=ttk.Notebook(card)
    nb.grid(column=0, row=1, columnspan=3, padx=padx, pady=pady, sticky="nesw")
    tab1=ttk.Frame(nb)    
    nb.add(tab1, text="Данные", image=img[3], compound="left")
    tab2=ttk.Frame(nb)
    nb.add(tab2, text="История", image=img[4], compound="left")
    
    # Tab 1 (info)
    tab1.grid_columnconfigure(1, weight=1) # tags
    tab1.grid_rowconfigure(0, weight=1)
    tab1.grid_rowconfigure(1, weight=1)
    tab1.grid_rowconfigure(2, weight=1)
    tab1.grid_rowconfigure(3, weight=1)
    tab1.grid_rowconfigure(4, weight=1)
    tab1.grid_rowconfigure(5, weight=1)
    ttk.Label(tab1, text="Номер").grid(column=0, row=0, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Тип").grid(column=0, row=1, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Адрес").grid(column=0, row=2, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Карта").grid(column=0, row=3, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Картинка").grid(column=0, row=4, padx=padx, pady=pady, sticky="e")
    ttk.Label(tab1, text="Заметка").grid(column=0, row=5, padx=padx, pady=pady, sticky="e")
    number=ttk.Entry(tab1)
    number.grid(column=1, row=0, padx=padx, pady=pady, sticky="we")
    number.insert(0, ter.number)
    def __updateTitle(event): card.title(number.get().strip())        
    number.bind("<KeyRelease>", __updateTitle)
    type=ttk.Entry(tab1) # fields
    type.grid(column=1, row=1, padx=padx, pady=pady, sticky="we")
    type.insert(0, ter.type)
    address=ttk.Entry(tab1)
    address.grid(column=1, row=2, padx=padx, pady=pady, sticky="we")
    address.insert(0, ter.address)
    map=ttk.Entry(tab1)
    map.grid(column=1, row=3, padx=padx, pady=pady, sticky="we")
    map.insert(0, ter.map)
    image=ttk.Entry(tab1)
    image.grid(column=1, row=4, padx=padx, pady=pady, sticky="we")
    image.insert(0, ter.image)
    note=ttk.Entry(tab1)
    note.grid(column=1, row=5, padx=padx, pady=pady, sticky="we")
    note.insert(0, ter.note)
    style = ttk.Style() # buttons
    style.configure("small2.TButton", font=('', 8))
    def __insertMap():
        map.delete(0, "end")
        map.insert(0, "https://yandex.ru/maps/?text=%s" % address.get().strip())
        if map.get().strip()!="": buttonMap.state(["!disabled"])
        else: buttonMap.state(["disabled"])
    ttk.Button(tab1, text="Как адрес", style="small2.TButton", command=__insertMap).grid(padx=5, pady=5, column=2, row=3, sticky="w") 
    def __insertImage():
        image.delete(0, "end")
        image.insert(0, "%s" % number.get().strip())
        if image.get().strip()!="": buttonImage.state(["!disabled"])
        else: buttonImage.state(["disabled"])
    ttk.Button(tab1, text="Как номер", style="small2.TButton", command=__insertImage).grid(padx=5, pady=5, column=2, row=4, sticky="w")
    
    # Map & Image
    buttonSize=1    
    def __openMap(): webbrowser.open(map.get())
    buttonMap = ttk.Button(tab1, image=img[5], command=__openMap)
    buttonMap.grid(column=0, row=8, padx=padx, pady=pady, ipadx=buttonSize, ipady=buttonSize, sticky="ws")
    def __openImage():
        if os.path.exists(image.get()+".png"): webbrowser.open(image.get()+".png")
        else: mb.showerror("Ошибка", "Файл не найден! Проверьте наличие файла %s.png в папке программы." % image.get())
    buttonImage = ttk.Button(tab1, image=img[6], command=__openImage)
    buttonImage.grid(column=1, row=8, pady=pady, ipadx=buttonSize, ipady=buttonSize, sticky="ws")
    def __checkButtonMapState(event):
        if map.get().strip()!="": buttonMap.state(["!disabled"])
        else: buttonMap.state(["disabled"])
    map.bind("<KeyRelease>", __checkButtonMapState)
    def __checkButtonImageState(event):
        if image.get().strip()!="": buttonImage.state(["!disabled"])
        else: buttonImage.state(["disabled"])
    image.bind("<KeyRelease>", __checkButtonImageState)
    __checkButtonMapState(None)
    __checkButtonImageState(None)
    
    # Tab 2 (history)         
    tab2.grid_columnconfigure (1, weight=1)
    tab2.grid_rowconfigure (1, weight=1)
    info=tk.Label(tab2)
    info.grid(column=0, row=0, padx=3, pady=pady, sticky="w")       
    timeout=tk.Label(tab2).grid(column=1, row=0, sticky="w")
    workList=tk.Listbox(tab2, relief="flat", font="Tahoma 9")    
    workList.grid(column=0, row=1, columnspan=2, padx=padx*2, pady=pady, sticky="nesw")    
    drawHistory(workList, info, timeout, ter, img)
    rightScrollbar = ttk.Scrollbar(workList, orient="vertical", command=workList.yview)
    workList.configure(yscrollcommand=rightScrollbar.set)      
    rightScrollbar.pack(side="right", fill="y")    
    
    # Save and cancel    
    buttonSave=ttk.Button(card, text="Сохранить")
    def __save(event): 
        ter.number=(number.get()).strip()
        ter.type=(type.get()).strip()
        ter.address=(address.get()).strip()
        ter.map=(map.get()).strip()
        ter.image=(image.get()).strip()
        ter.note=(note.get()).strip()
        save(gui, db)
        gui.update()
        card.destroy() # close card
    buttonSave.bind("<Button-1>", __save)
    buttonSave.grid(padx=padx, pady=pady*2, ipadx=padx*5, ipady=3, column=1, row=2)
    buttonCancel=ttk.Button(card, text="Отмена")
    buttonCancel.bind("<Button-1>", __quit)
    buttonCancel.grid(padx=padx, pady=pady*2, ipadx=padx*5, ipady=3, column=2, row=2)
