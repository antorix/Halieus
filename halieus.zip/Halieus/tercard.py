#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk
import os
import webbrowser
import data as d
import tkinter.messagebox as mb
import tkinter.scrolledtext as ScrolledText
from classes import CreateToolTip

class Visit():
    
    def __init__(self, workNumber, card, master=None, event=None):        
        self.master = tk.Toplevel()        
        self.card=card        
        self.workNumber=workNumber
        self.work=self.card.ter.works[workNumber]        
        if self.work[0]=="" or self.work[1]=="" or self.work[2]=="":
            self.card.root.quickTip("Нельзя отредактировать незаконченную обработку", 200, 2000)
            self.master.destroy()
            return
            
        #self.master.focus_force()
        #visit.grab_set()
        self.padx=5
        self.pady=5
        self.master.grid_columnconfigure (0, weight=1)
        self.master.grid_rowconfigure    (0, weight=0)
        self.master.title("№%s – %d)" % (self.card.ter.number, self.workNumber+1))
        if os.name=="nt": self.master.iconbitmap(self.card.root.ico[4])
        self.card.master.unbind("<Escape>")
        self.master.bind("<Escape>", lambda x: self.master.destroy())
        self.master.columnconfigure(1, weight=1)
        self.master.rowconfigure(3, weight=1)
        ttk.Label(self.master, text="Возвещатель:").grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="e")
        ttk.Label(self.master, text="Дата выдачи участка:").grid(column=0, row=1, padx=self.padx, pady=self.pady, sticky="e")
        ttk.Label(self.master, text="Дата сдачи участка:").grid(column=0, row=2, padx=self.padx, pady=self.pady, sticky="e")
        self.name=ttk.Entry(self.master)
        self.name.grid(column=1, columnspan=2, row=0, padx=self.padx, pady=self.pady, sticky="we")
        self.name.insert(0, self.work[0])
        self.date1=ttk.Entry(self.master)
        self.date1.grid(column=1, columnspan=2, row=1, padx=self.padx, pady=self.pady, sticky="we")
        self.date1.insert(0, self.work[1])
        self.date2=ttk.Entry(self.master)
        self.date2.grid(column=1, columnspan=2, row=2, padx=self.padx, pady=self.pady, sticky="we")
        self.date2.insert(0, self.work[2])
        self.wrongDate=tk.Label(self.master, fg="red")
        self.wrongDate.grid(column=0, columnspan=3, padx=self.padx, row=3)
        ttk.Button(self.master, text="Удалить", image=self.card.root.img[28], compound="left", command=self.delete).grid(column=0, row=4, padx=self.padx, pady=self.pady, sticky="w")
        ttk.Button(self.master, text="Сохранить", image=self.card.root.img[36], compound="left", command=self.saveVisit).grid(column=1, row=4, padx=self.padx, pady=self.pady, sticky="e")
        ttk.Button(self.master, text="Отмена", command=lambda: self.master.destroy()).grid(column=2, row=4, padx=self.padx, pady=self.pady, sticky="w")
        
    def saveVisit(self):
        if d.verifyDate(self.date1.get().strip(), silent=True)==False or d.verifyDate(self.date2.get().strip(), silent=True)==False: self.wrongDate["text"]="Проверьте правильность ввода дат (ДД.ММ.ГГ)"
        elif self.name.get().strip()=="": self.wrongDate["text"]="Имя не может быть пустым"
        else:
            self.work[0]=self.name.get().strip()
            self.work[1]=self.date1.get().strip()
            self.work[2]=self.date2.get().strip()
            self.card.drawHistory()
            self.master.destroy()
            self.card.savedAction=True    
    
    def delete(self):
        del self.card.ter.works[self.workNumber]
        self.card.drawHistory()
        self.master.destroy()
        self.card.savedAction=True

class Tercard():
    """ Show ter card"""
    
    def __init__(self, ter, root, new):
        self.master = tk.Toplevel()        
        
        # Variables
        self.ter=ter
        self.new=new
        self.root=root
        self.saved=False
        self.savedAction=False
        
        # Form set up
        if os.name=="nt": self.master.iconbitmap(root.ico[3])
        self.master.focus_force()
        #self.master.grab_set()
        self.master.minsize(200,170)
        self.padx=5
        self.pady=5
        self.master.grid_columnconfigure (1, weight=1)        
        self.master.grid_rowconfigure    (1, weight=1)        
        self.master.title("№%s" % ter.number)
        self.master.bind("<Escape>", self.cancel)
        self.style=ttk.Style()
        ttk.Sizegrip(self.master).grid(column=2, row=4, rowspan=9,sticky="se")                
        
        # Status frame        
        self.statusFrame=ttk.LabelFrame(self.master, text="Статус участка")
        self.statusFrame.grid_columnconfigure (1, weight=1)
        self.statusFrame.grid(column=0, row=0, columnspan=3, padx=self.padx, pady=self.pady, sticky="nesw")
        self.statusLabel=tk.Label(self.statusFrame, compound="left", justify="left", padx=5)
        self.statusLabel.pack(padx=self.padx, pady=self.pady, side="left") 
        self.buttonAction=ttk.Button(self.statusFrame, compound="left")
        self.buttonAction.bind("<1>", self.action)
        ttk.Label(self.statusFrame).pack(pady=5, side="left")    
        #if os.name!="posix":
        self.buttonAction.pack(padx=self.padx, pady=self.pady, side="right")
        
        # Notebook set up
        nb=ttk.Notebook(self.master)
        nb.grid(column=0, row=1, columnspan=3, rowspan=2, padx=self.padx, pady=self.pady, sticky="nesw")
        tab1=tk.Frame(nb)    
        nb.add(tab1, text="Данные", image=root.img[30], compound="left")
        tab2=ttk.Frame(nb)
        if ter.getDelta2()==999999: delta2="∞"
        else: delta2=ter.getDelta2()
        nb.add(tab2, text="Обработка (%d/%s)" % (ter.getWorks(), delta2), image=root.img[5], compound="left")
        
        # Tab 1 (info)
        tab1.grid_columnconfigure(1, weight=1)                                  # tags
        tab1.grid_rowconfigure(3, weight=5)
        self.yellow="#fffdd8"
        tk.Label(tab1, image=root.img[22], compound="left", text=" Номер").grid(column=0, row=0, padx=self.padx, sticky="w")
        tk.Label(tab1, image=root.img[26], compound="left", text=" Тип").grid(column=0, row=1, padx=self.padx, sticky="w")
        tk.Label(tab1, image=root.img[21], compound="left", text=" Адрес").grid(column=0, row=2, padx=self.padx, sticky="w")
        tk.Label(tab1, image=root.img[20], compound="left", text=" Заметка").grid(column=0, row=3, padx=self.padx, sticky="w")
        self.buttonMap=ttk.Button(tab1, image=root.img[53], compound="left", text=" Карта", command=lambda: webbrowser.open(self.entry[4].get()))
        self.buttonMap.grid(column=0, row=4, padx=self.padx, sticky="w")
        CreateToolTip(self.buttonMap, "Чтобы открыть участок на карте, введите URL-адрес")
        self.entry=[]                                                           # fields            
        for i in range(6): self.entry.append(tk.Entry(tab1, relief="flat"))
        self.entry[0].grid(column=1, columnspan=2, row=0, padx=self.padx, sticky="we")
        self.entry[0].focus_force()
        self.entry[0].insert(0, ter.number)
        self.entry[0].bind("<KeyRelease>", lambda x: self.master.title("№%s" % self.entry[0].get().strip()))    
        self.entry[1].grid(column=1, columnspan=2, row=1, padx=self.padx, sticky="we")
        self.entry[1].insert(0, ter.type)
        self.entry[2].grid(column=1, columnspan=2, row=2, padx=self.padx, sticky="we")
        self.entry[2].insert(0, ter.address)
        if root.noteAsText.get()==1:                                            # enlarged note         
            self.note=ScrolledText.ScrolledText(tab1, wrap="word", bg=self.yellow, height=6, width=0, font="{%s} 9" % root.listFont.get(), relief="flat")
            self.note.insert(0.0, ter.note)
            self.note.grid(column=1, columnspan=2, row=3, padx=self.padx, sticky="wesn")
            self.note.rowconfigure(0, weight=1)
            self.note.columnconfigure(0, weight=1)
            self.note.bind("<Button-3>", root.standardMenu)
            self.note.bind("<Control-Return>", lambda x: self.saveCard(exit=True))
        else:
            self.entry[3]["bg"]=self.yellow
            self.entry[3].grid(column=1, columnspan=2, row=3, padx=self.padx, sticky="we")
            self.entry[3].insert(0, ter.note)
        self.entry[4].grid(column=1, row=4, padx=self.padx, sticky="we")
        self.entry[4].insert(0, ter.map)
        if root.images.get()==1:
            self.buttonImage=ttk.Button(tab1, image=root.img[54], compound="left", text="Картинка", command=self.openImage)
            self.buttonImage.grid(column=0, row=5, padx=self.padx, sticky="w")
            CreateToolTip(self.buttonImage, "Чтобы открыть картинку в формате PNG, введите название файла (без расширения .png), который находится в папке программы")
            self.entry[5].grid(column=1, row=5, padx=self.padx, sticky="we")
            self.entry[5].insert(0, ter.image)
            ttk.Button(tab1, text="Как номер", style="small2.TButton", command=self.insertImage).grid(padx=self.padx, column=2, row=5, sticky="w")
            self.checkButtonMapState()
        style = ttk.Style()                                                     # buttons
        style.configure("small2.TButton", font=('', 8))
        ttk.Button(tab1, text="Как адрес", style="small2.TButton", command=self.insertMap).grid(padx=self.padx, column=2, row=4, sticky="w") 
        self.entry[4].bind("<KeyRelease>", self.checkButtonMapState)
        if root.images.get()==1:
            self.entry[5].bind("<KeyRelease>", self.checkButtonImageState)
            self.checkButtonImageState()
        
        # Tab 2 (history)
        tab2.grid_columnconfigure (1, weight=1)
        tab2.grid_rowconfigure (1, weight=1)
        self.info=tk.Label(tab2, image=None, compound="right")
        self.info.grid(column=0, row=0, padx=3, pady=self.pady, sticky="w")       
        self.workList=tk.Listbox(tab2, relief="flat", activestyle="dotbox", font="{%s} 9" % root.listFont.get())    
        self.workList.grid(column=0, row=1, columnspan=2, rowspan=2, padx=self.padx*2, sticky="nesw")    
        rightScrollbar = ttk.Scrollbar(self.workList, orient="vertical", command=self.workList.yview)
        self.workList.configure(yscrollcommand=rightScrollbar.set)      
        rightScrollbar.pack(side="right", fill="y")    
        self.workList.bind("<Double-Button-1>", self.openVisit)
        self.workList.bind("<Return>", self.openVisit)
        
        # Save and cancel        
        self.saveFrame=ttk.Frame(self.master)
        self.saveFrame.grid(column=1, columnspan=2, row=3, padx=self.padx*3, sticky="wesn")
        self.ipady=3        
        self.style.configure("savecard.TButton", justify="center")
        self.style.configure("savecardPressed.TButton", background="SteelBlue", justify="center")        
        self.cancelButton=ttk.Button(self.saveFrame, text="Отмена", style="savecard.TButton", image=root.img[61], compound="left", command=lambda: self.cancel())
        self.cancelButton.pack(ipady=self.ipady, side="right")
        self.cancelTip=CreateToolTip(self.cancelButton, text="[Escape]")
        self.saveCloseButton=ttk.Button(self.saveFrame, text="Сохранить и закрыть", style="savecard.TButton", image=root.img[62], compound="left", command=lambda: self.saveCard(exit=True))
        self.saveCloseButton.pack(ipady=self.ipady, side="right")
        CreateToolTip(self.saveCloseButton, "[Ctrl-Enter]")
        self.saveButton=ttk.Button(self.saveFrame, text="Сохранить", style="savecard.TButton", image=root.img[36], compound="left", command=lambda: self.saveCard())
        self.saveButton.pack(ipady=self.ipady, side="right")
        CreateToolTip(self.saveButton, "[Enter]")
        for e in self.entry:
            e.bind("<Return>", lambda x: self.saveCard(onReturn=True))    
            e.bind("<Control-Return>", lambda x: self.saveCard(exit=True))    
            e.bind("<Button-3>", root.standardMenu)
        
        # Launch
        self.drawStatus()
        self.drawHistory()
        self.master.wait_window()

    def checkButtonImageState(self, event=None):
        if self.entry[5].get().strip()!="": self.buttonImage.state(["!disabled"])
        else: self.buttonImage.state(["disabled"])
            
    def checkButtonMapState(self, event=None):
        if self.entry[4].get().strip()!="": self.buttonMap.state(["!disabled"])
        else: self.buttonMap.state(["disabled"])
            
    def insertMap(self):
        self.entry[4].delete(0, "end")
        self.entry[4].insert(0, "https://yandex.ru/maps/?text=%s" % self.entry[2].get().strip())
        if self.entry[4].get().strip()!="": self.buttonMap.state(["!disabled"])
        else: self.buttonMap.state(["disabled"])
            
    def insertImage(self):
        self.entry[5].delete(0, "end")
        self.entry[5].insert(0, self.entry[0].get().strip())
        if self.entry[5].get().strip()!="": self.buttonImage.state(["!disabled"])
        else: self.buttonImage.state(["disabled"])
                
    def openImage(self):
        if os.path.exists("%s.png" % self.entry[5].get().strip()): webbrowser.open("%s.png" % self.entry[5].get().strip())
        else: mb.showerror("Ошибка", "Файл не найден! Проверьте наличие файла %s.png в папке программы." % self.entry[5].get())
                
    def drawStatus(self):
        """ Draw and update status information for card """  
        if self.ter.getStatus(self.root)==0:
            self.statusLabel["text"]="В картотеке"
            self.statusLabel["image"]=self.root.img[3]
            self.buttonAction["text"]="Выдать"
            self.buttonAction["image"]=self.root.img[9]
            self.master.bind("<Alt-Home>", self.action)
            self.master.bind("<Alt-End", None)
        elif self.ter.getStatus(self.root)==1:
            self.statusLabel["text"]="Обрабатывается возвещателем %s\nВыдан %s (%s дн. назад)" % (self.ter.getPublisher(), self.ter.getDate1(), self.ter.getDelta1())
            self.statusLabel["image"]=self.root.img[33]
            self.buttonAction["text"]="Сдать"
            self.buttonAction["image"]=self.root.img[8]
            self.master.bind("<Alt-Home>", None)
            self.master.bind("<Alt-End>", self.action)
        else:
            self.statusLabel["text"]="Просрочен возвещателем %s\nВыдан %s (%s дн. назад)" % (self.ter.getPublisher(), self.ter.getDate1(), self.ter.getDelta1())
            self.statusLabel["image"]=self.root.img[15]
            self.buttonAction["text"]="Сдать"
            self.buttonAction["image"]=self.root.img[9]
            self.master.bind("<Alt-Home>", None)
            self.master.bind("<Alt-End>", self.action)    
            
    def action(self, event=None):       
        if self.ter.getStatus(self.root)==0:
            self.ter.give(self.root, fromTerCard=True)            
            self.buttonAction["text"]="Выдать"
        else:
            self.ter.submit(self.root, fromTerCard=True)
            self.buttonAction["text"]="Сдать"
        self.drawStatus()
        self.drawHistory()
        self.savedAction=True
        
    def drawHistory(self):
        """ Draw and update history information on tab 2 """
        if self.ter.getDelta2()==999999: delta2="∞"
        else: delta2=self.ter.getDelta2()
        text2=". Последняя – %s дн. назад " % delta2
        if self.ter.getWorks()==0: self.info.configure(image=self.root.img[32])
        elif self.ter.getWorks()>0:
            text2=". Последняя – %s дн. назад (%s) " % (delta2, self.ter.getDateLastSubmit())
            if self.ter.getDelta2()>365: self.info.configure(image=self.root.img[32])
        self.info["text"]="Обработок – %d%s" % (self.ter.getWorks(), text2)    
        self.workContent=tk.StringVar(value=tuple(["%3d) %-18s %8s–%8s" % (i+1, (self.ter.works[i][0][:18]+""), self.ter.works[i][1], self.ter.works[i][2]) for i in range(len(self.ter.works))])) # fill list        
        self.workList.configure(listvariable=self.workContent)
        
    def cancel(self, event=None):
        if self.new==True and self.saved==False: del self.root.db[len(self.root.db)-1] # if creation of new ter is cancelled without saving, delete it (by last index)            
        self.master.destroy()
    
    def saveCard(self, event=None, exit=False, onReturn=False):        
        if exit==False and onReturn==True:
            self.saveButton.configure(style="savecardPressed.TButton")
            self.saveButton.after(50, lambda: self.saveButton.configure(style="savecard.TButton"))
        self.master["cursor"]="watch"
        self.root["cursor"]="watch"
        self.master.update()
        self.ter.number=self.entry[0].get().strip()
        self.ter.type=self.entry[1].get().strip()
        self.ter.address=self.entry[2].get().strip()
        if self.root.noteAsText.get()==1: self.ter.note=self.note.get(0.0, "end").strip()
        else: self.ter.note=self.entry[3].get().strip()
        self.ter.map=self.entry[4].get().strip()
        if self.root.images.get()==1: self.ter.image=self.entry[5].get().strip()        
        self.root.save()                                                        # save, update, log
        self.root.updateL()
        self.root.updateS()        
        self.saved=True      
        if self.new==True: self.root.log("Создан участок %s (%s)." % (self.ter.number, self.ter.address))
        else: self.root.log("Сохранен участок %s (%s)." % (self.ter.number, self.ter.address))        
        if self.savedAction==True: self.root.updateP()        
        self.master["cursor"]="arrow"
        self.master.update()
        if exit==True: self.master.destroy()

    def openVisit(self, event=None):
        self.visit = Visit(self.workList.curselection()[0], self)
        self.master.bind("<Escape>", self.cancel)
