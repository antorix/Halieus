#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk
import os
import webbrowser
import data as d
import tkinter.messagebox as mb
import tkinter.scrolledtext as ScrolledText
from classes import CreateToolTip
import contacts

class Visit():
    
    def __init__(self, workNumber, card, window=None, event=None):        
        self.window = tk.Toplevel(card.window)        
        self.card=card        
        self.workNumber=workNumber
        self.work=self.card.ter.works[workNumber]        
        if self.work[0]=="" or self.work[1]=="" or self.work[2]=="":
            self.card.root.quickTip(self.card.root.msg[266], 200, 2000)
            self.window.destroy()
            return
            
        self.window.focus_force()        
        self.window.grid_columnconfigure (0, weight=1)
        self.window.grid_rowconfigure    (0, weight=0)
        self.window.title("№%s – %d)" % (self.card.ter.number, self.workNumber+1))
        self.window.tk.call('wm', 'iconphoto', self.window._w, self.card.root.img[73])
        self.card.window.unbind("<Escape>")
        self.window.bind("<Escape>", lambda x: self.window.destroy())
        self.window.columnconfigure(1, weight=1)
        self.window.rowconfigure(3, weight=1)
        ttk.Label(self.window, text=self.card.root.msg[96]).grid(column=0, row=0, padx=self.card.root.padx, pady=self.card.root.pady, sticky="e")
        ttk.Label(self.window, text=self.card.root.msg[216]).grid(column=0, row=1, padx=self.card.root.padx, pady=self.card.root.pady, sticky="e")
        ttk.Label(self.window, text=self.card.root.msg[217]).grid(column=0, row=2, padx=self.card.root.padx, pady=self.card.root.pady, sticky="e")
        self.name=ttk.Combobox(self.window, height=30, textvariable=self.card.root.pubInBox) # publisher combobox
        self.name["values"]=self.card.root.allPublishers        
        self.name.grid(column=1, columnspan=2, row=0, padx=self.card.root.padx, pady=self.card.root.pady, sticky="we")
        self.name.delete(0, "end")
        self.name.insert(0, self.work[0])
        self.date1=ttk.Entry(self.window)
        self.date1.grid(column=1, columnspan=2, row=1, padx=self.card.root.padx, pady=self.card.root.pady, sticky="we")
        self.date1.insert(0, self.work[1])
        self.date2=ttk.Entry(self.window)
        self.date2.grid(column=1, columnspan=2, row=2, padx=self.card.root.padx, pady=self.card.root.pady, sticky="we")
        self.date2.insert(0, self.work[2])
        self.wrongDate=tk.Label(self.window, fg="red")
        self.wrongDate.grid(column=0, columnspan=3, padx=self.card.root.padx, row=3)
        ttk.Button(self.window, text=self.card.root.msg[66], image=self.card.root.img[28], compound="left", command=self.delete).grid(column=0, row=4, padx=self.card.root.padx, pady=self.card.root.pady, sticky="w")
        ttk.Button(self.window, text=self.card.root.msg[222], image=self.card.root.img[36], compound="left", command=self.saveVisit).grid(column=1, row=4, padx=self.card.root.padx, pady=self.card.root.pady, sticky="e")
        ttk.Button(self.window, text=self.card.root.msg[267], command=lambda: self.window.destroy()).grid(column=2, row=4, padx=self.card.root.padx, pady=self.card.root.pady, sticky="w")
        
    def saveVisit(self):
        if d.verifyDate(self.card.root, self.date1.get().strip(), silent=True)==False or d.verifyDate(self.card.root, self.date2.get().strip(), silent=True)==False: self.wrongDate["text"]=self.card.root.msg[219]
        elif self.name.get().strip()=="": self.wrongDate["text"]=self.card.root.msg[220]
        else:
            self.work[0]=self.name.get().strip()
            self.work[1]=self.date1.get().strip()
            self.work[2]=self.date2.get().strip()
            self.card.drawHistory()
            self.window.destroy()
            self.card.savedAction=True
    
    def delete(self):
        del self.card.ter.works[self.workNumber]
        self.card.drawHistory()
        self.window.destroy()
        self.card.savedAction=True

class Tercard():
    """ Show ter card"""
    
    def __init__(self, ter, root, new):
        self.window = tk.Toplevel(root)
        self.window.withdraw()
        
        # Variables
        self.ter=ter
        self.new=new
        self.root=root
        self.saved=False
        self.savedAction=False
        
        # Form set up        
        self.root.tk.call('wm', 'iconphoto', self.window._w, root.img[71])        
        self.window.focus_force()
        self.window.minsize(200,170)
        self.window.grid_columnconfigure (1, weight=1)        
        self.window.grid_rowconfigure    (1, weight=1)        
        self.window.title("№%s" % ter.number)
        ttk.Sizegrip(self.window).grid(column=2, row=4, rowspan=9,sticky="se")                
        
        # Status frame        
        self.statusFrame=ttk.LabelFrame(self.window, text=self.root.msg[268])
        self.statusFrame.grid_columnconfigure (1, weight=1)
        self.statusFrame.grid(column=0, row=0, columnspan=3, padx=root.padx, pady=root.pady, sticky="nesw")
        self.statusLabel=tk.Label(self.statusFrame, compound="left", justify="left", padx=5)
        self.statusLabel.pack(padx=root.padx, pady=root.pady, side="left") 
        self.buttonAction=ttk.Button(self.statusFrame, compound="left")
        self.buttonAction.bind("<1>", self.action)
        ttk.Label(self.statusFrame).pack(pady=5, side="left")    
        #if os.name!="posix":
        self.buttonAction.pack(padx=root.padx, pady=root.pady, side="right")
        
        # Notebook set up
        self.nb=ttk.Notebook(self.window)
        self.nb.grid(column=0, row=1, columnspan=3, rowspan=2, padx=root.padx, pady=root.pady, sticky="nesw")
        tab1=tk.Frame(self.nb)    
        self.nb.add(tab1, text=self.root.msg[269], image=root.img[30], compound="left")
        tab2=ttk.Frame(self.nb)
        if ter.getDelta2()==999999: delta2="∞"
        else: delta2=ter.getDelta2()
        self.nb.add(tab2, text=self.root.msg[270] % (ter.getWorks(), delta2), image=root.img[5], compound="left")
        
        # Tab 1 (info)
        tab1.grid_columnconfigure(1, weight=1)                                  # tags
        tab1.grid_rowconfigure(3, weight=5)
        self.yellow="#fffdd8"
        tk.Label(tab1, image=root.img[22], compound="left", text=" "+self.root.msg[271]).grid(column=0, row=0, padx=root.padx, sticky="w")
        tk.Label(tab1, image=root.img[26], compound="left", text=" "+self.root.msg[272]).grid(column=0, row=1, padx=root.padx, sticky="w")
        tk.Label(tab1, image=root.img[21], compound="left", text=" "+self.root.msg[273]).grid(column=0, row=2, padx=root.padx, sticky="w")
        tk.Label(tab1, image=root.img[20], compound="left", text=" "+self.root.msg[274]).grid(column=0, row=3, padx=root.padx, sticky="w")
        self.buttonMap=ttk.Button(tab1, image=root.img[53], compound="left", text=" "+self.root.msg[275], command=lambda: webbrowser.open(self.entry[4].get()))
        self.buttonMap.grid(column=0, row=4, padx=root.padx, sticky="w")
        CreateToolTip(self.buttonMap, self.root.msg[277])
        self.entry=[]                                                           # fields            
        for i in range(6): self.entry.append(tk.Entry(tab1, relief="flat"))
        self.entry[0].grid(column=1, columnspan=2, row=0, padx=root.padx, sticky="we")
        self.entry[0].focus_force()
        self.entry[0].insert(0, ter.number)
        self.entry[0].bind("<KeyRelease>", lambda x: self.window.title("№%s" % self.entry[0].get().strip()))    
        self.entry[1].grid(column=1, columnspan=2, row=1, padx=root.padx, sticky="we")
        self.entry[1].insert(0, ter.type)
        self.entry[2].grid(column=1, columnspan=2, row=2, padx=root.padx, sticky="we")
        self.entry[2].insert(0, ter.address)
        if root.noteAsText.get()==1:                                            # enlarged note         
            self.note=ScrolledText.ScrolledText(tab1, wrap="word", bg=self.yellow, height=6, width=0, font="{%s} 9" % root.listFont.get(), relief="flat")
            self.note.insert(0.0, ter.note)
            self.note.grid(column=1, columnspan=2, row=3, padx=root.padx, sticky="wesn")
            self.note.rowconfigure(0, weight=1)
            self.note.columnconfigure(0, weight=1)
            self.note.bind("<Control-Return>", lambda x: self.saveCard(exit=True))
        else:
            self.entry[3]["bg"]=self.yellow
            self.entry[3].grid(column=1, columnspan=2, row=3, padx=root.padx, sticky="we")
            self.entry[3].insert(0, ter.note)
        self.entry[4].grid(column=1, row=4, padx=root.padx, sticky="we")
        self.entry[4].insert(0, ter.map)
        if root.images.get()==1:
            self.buttonImage=ttk.Button(tab1, image=root.img[54], compound="left", text=self.root.msg[276], command=self.openImage)
            self.buttonImage.grid(column=0, row=5, padx=root.padx, sticky="w")
            CreateToolTip(self.buttonImage, self.root.msg[278])
            self.entry[5].grid(column=1, row=5, padx=root.padx, sticky="we")
            self.entry[5].insert(0, ter.image)
            ttk.Button(tab1, text=self.root.msg[279], style="small2.TButton", command=self.insertImage).grid(padx=root.padx, column=2, row=5, sticky="w")
            self.checkButtonMapState() 
        ttk.Button(tab1, text=self.root.msg[280], style="small2.TButton", command=self.insertMap).grid(padx=root.padx, column=2, row=4, sticky="w") 
        self.entry[4].bind("<KeyRelease>", self.checkButtonMapState)
        if root.images.get()==1:
            self.entry[5].bind("<KeyRelease>", self.checkButtonImageState)
            self.checkButtonImageState()
        
        # Tab 2 (history)
        tab2.grid_columnconfigure (1, weight=1)
        tab2.grid_rowconfigure (1, weight=1)
        self.info=tk.Label(tab2, image=None, compound="right")
        self.info.grid(column=0, row=0, padx=3, pady=root.pady, sticky="w")       
        self.workList=tk.Listbox(tab2, relief="flat", activestyle="dotbox", font="{%s} 9" % root.listFont.get())    
        self.workList.grid(column=0, row=1, columnspan=2, rowspan=2, padx=root.padx, sticky="nesw")    
        rightScrollbar = ttk.Scrollbar(self.workList, orient="vertical", command=self.workList.yview)
        self.workList.configure(yscrollcommand=rightScrollbar.set)      
        rightScrollbar.pack(side="right", fill="y")
        self.listbar = tk.Menu(self.workList)
        self.listmenu = tk.Menu(self.listbar, tearoff=0)
        self.listmenu.add_command(label=" "+self.root.msg[134], image=self.root.img[27], compound="left", command=self.openVisit)    
        self.workList.bind("<Double-Button-1>", self.openVisit)        
        self.workList.bind("<3>", lambda event: self.listmenu.post(event.x_root, event.y_root))
        self.workList.bind("<Return>", self.openVisit)
        
        # Tab 3 (contacts, optional)
        if root.contactsEnabled.get()==1:
            self.tabContacts=contacts.TerTab(self)
            if contacts.Mod==True:
                import contacts_mod
                contacts_mod.terInit(self)
        
        # Save and cancel        
        self.saveFrame=ttk.Frame(self.window)
        self.saveFrame.grid(column=1, columnspan=2, row=3, padx=root.padx*3, sticky="wesn")
        self.ipady=3          
        self.cancelButton=ttk.Button(self.saveFrame, text=self.root.msg[267], style="savecard.TButton", image=root.img[61], compound="left", command=lambda: self.window.destroy())
        self.cancelButton.pack(ipady=self.ipady, side="right")
        self.cancelTip=CreateToolTip(self.cancelButton, text="[Escape]")
        self.saveCloseButton=ttk.Button(self.saveFrame, text=self.root.msg[281], style="savecard.TButton", image=root.img[62], compound="left", command=lambda: self.saveCard(exit=True))
        self.saveCloseButton.pack(ipady=self.ipady, side="right")
        CreateToolTip(self.saveCloseButton, "[Ctrl-Enter]")
        self.saveButton=ttk.Button(self.saveFrame, text=self.root.msg[222], style="savecard.TButton", image=root.img[36], compound="left", command=lambda: self.saveCard())
        self.saveButton.pack(ipady=self.ipady, side="right")
        CreateToolTip(self.saveButton, "[Enter]")
        for e in self.entry:
            e.bind("<Return>", lambda x: self.saveCard(onReturn=True))    
            e.bind("<Control-Return>", lambda x: self.saveCard(exit=True))    
        self.window.bind("<Escape>", lambda x: self.window.destroy())
        
        # Launch        
        self.drawStatus()
        self.drawHistory()
        self.window.deiconify()
        self.window.wait_window()
    
    def checkButtonImageState(self, event=None):
        if self.entry[5].get().strip()!="": self.buttonImage.state(["!disabled"])
        else: self.buttonImage.state(["disabled"])
            
    def checkButtonMapState(self, event=None):
        if self.entry[4].get().strip()!="": self.buttonMap.state(["!disabled"])
        else: self.buttonMap.state(["disabled"])
            
    def insertMap(self):
        self.entry[4].delete(0, "end")
        self.entry[4].insert(0, "https://yandex.ru/maps/?text=%s" % self.entry[2].get().strip())
        if self.entry[4].get().strip()!="": self.buttonMap.state(["!disabled"])
        else: self.buttonMap.state(["disabled"])
            
    def insertImage(self):
        self.entry[5].delete(0, "end")
        self.entry[5].insert(0, self.entry[0].get().strip())
        if self.entry[5].get().strip()!="": self.buttonImage.state(["!disabled"])
        else: self.buttonImage.state(["disabled"])
                
    def openImage(self):
        script_dir = os.path.dirname(__file__)
        if self.root.imageFolder.get()=="":
            rel_path = "%s.png" % self.entry[5].get().strip()
        else:
            rel_path = "%s/%s.png" % (self.root.imageFolder.get(), self.entry[5].get().strip())
        if os.path.exists(rel_path):            
            abs_file_path = os.path.join(script_dir, rel_path)
            webbrowser.open(abs_file_path)
        else: mb.showerror(self.root.msg[1], self.root.msg[282] % rel_path)
                
    def drawStatus(self):
        """ Draw and update status information for card """
        if self.ter.getDelta1()==999999: delta1="∞"
        else: delta1=self.ter.getDelta1()  
        if self.ter.getStatus(self.root)==0:
            self.statusLabel["text"]=self.root.msg[149]
            self.statusLabel["image"]=self.root.img[3]
            self.buttonAction["text"]=self.root.msg[290]
            self.buttonAction["image"]=self.root.img[9]
            self.window.bind("<Alt-Home>", self.action)
            self.window.bind("<Alt-End", None)
        elif self.ter.getStatus(self.root)==1:
            self.statusLabel["text"]=self.root.msg[283] % (self.ter.getPublisher(), self.ter.getDate1(), delta1)
            self.statusLabel["image"]=self.root.img[33]
            self.buttonAction["text"]=self.root.msg[291]
            self.buttonAction["image"]=self.root.img[8]
            self.window.bind("<Alt-Home>", None)
            self.window.bind("<Alt-End>", self.action)
        else:
            self.statusLabel["text"]=self.root.msg[284] % (self.ter.getPublisher(), self.ter.getDate1(), delta1)
            self.statusLabel["image"]=self.root.img[15]
            self.buttonAction["text"]=self.root.msg[291]
            self.buttonAction["image"]=self.root.img[8]
            self.window.bind("<Alt-Home>", None)
            self.window.bind("<Alt-End>", self.action)    
            
    def action(self, event=None):       
        if self.ter.getStatus(self.root)==0:
            self.ter.give(self.root, fromTerCard=True)            
            self.buttonAction["text"]=self.root.msg[290]
        else:
            self.ter.submit(self.root, fromTerCard=True)
            self.buttonAction["text"]=self.root.msg[291]
        self.drawStatus()
        self.drawHistory()
        self.savedAction=True
        
    def drawHistory(self):
        """ Draw and update history information on tab 2 """
        if self.ter.getDelta2()==999999: delta2="∞"
        else: delta2=self.ter.getDelta2()
        text2=self.root.msg[285] % delta2
        if self.ter.getWorks()==0: self.info.configure(image=self.root.img[32])
        elif self.ter.getWorks()>0:
            text2=self.root.msg[286] % (delta2, self.ter.getDateLastSubmit())
            if self.ter.getDelta2()>365: self.info.configure(image=self.root.img[32])
        self.info["text"]=self.root.msg[287] % (self.ter.getWorks(), text2)    
        self.workContent=tk.StringVar(value=tuple(["%3d) %-18s %8s–%8s" % (i+1, (self.ter.works[i][0][:18]+""), self.ter.works[i][1], self.ter.works[i][2]) for i in range(len(self.ter.works))])) # fill list        
        self.workList.configure(listvariable=self.workContent)
    
    def saveCard(self, event=None, exit=False, onReturn=False):        
        if exit==False and onReturn==True:
            self.saveButton.configure(style="savecardPressed.TButton")
            self.saveButton.after(50, lambda: self.saveButton.configure(style="savecard.TButton"))
        self.window["cursor"]="watch"
        self.root["cursor"]="watch"
        self.window.update()
        self.ter.number=self.entry[0].get().strip()
        self.ter.type=self.entry[1].get().strip()
        self.ter.address=self.entry[2].get().strip()
        if self.root.noteAsText.get()==1: self.ter.note=self.note.get(0.0, "end").strip()
        else: self.ter.note=self.entry[3].get().strip()
        self.ter.map=self.entry[4].get().strip()
        if self.root.images.get()==1: self.ter.image=self.entry[5].get().strip()        
        self.root.save()                                                        # save, update, log
        self.root.updateL()
        self.root.updateS()
        if self.root.contactsEnabled.get()==1: self.root.tabContacts.update()
        self.saved=True      
        if self.new==True: self.root.log(self.root.msg[288] % (self.ter.number, self.ter.address))
        else: self.root.log(self.root.msg[289] % (self.ter.number, self.ter.address))        
        self.root.updateLog()
        if self.savedAction==True: self.root.updateP()        
        self.window["cursor"]="arrow"
        self.window.update()
        if exit==True: self.window.destroy()

    def openVisit(self, event=None):
        self.visit = Visit(self.workList.curselection()[0], self)
        self.window.bind("<Escape>", lambda x: self.window.destroy())
