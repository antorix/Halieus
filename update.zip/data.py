#!/usr/bin/python
# -*- coding: utf-8 -*-
import pickle
import tkinter.messagebox as mb
import data as d
import tercard
import datetime
import time
import os
from glob import glob
import urllib.request
import zipfile
import _thread
from xlwt import Formula

class Ter(): # territory class

    def __init__(self, number="", type="", address="", note="", image="", map="", work=[]):
        self.number=number
        self.type=type
        self.address=address
        self.note=note
        self.map=map
        self.image=image
        self.works=[]
        self.extra=[]        
        if len(work)>0:
            self.works=[]
            self.works.append([work[0][0], work[0][1], work[0][2]])
        
    def retrieve(self, root):
        """ How to show individual ter line in list """        
        output=""
        try:            
            if root.lines.get()==1: line="│"
            else: line=" "
            if root.fields[0].get()==1:
                if self.getStatus(root)==0:     output += "v"#"√"
                elif self.getStatus(root)==1:   output += "о"
                else:                           output += "!"#"‼"
            if root.fields[1].get()==1: output += "%s№%-7s" % (line, self.number[:7])
            if root.fields[2].get()==1: output += "%s%-8s" % (line, self.type[:8])        
            if root.fields[3].get()==1:
                if root.doubleAddress.get()==0: output += "%s%-53s" % (line, self.address[:53]) 
                else: output += "%s%-85s" % (line, self.address[:85]) 
            if root.fields[4].get()==1: output += "%s%-17s" % (line, self.getCurrentPublisher()[:17])
            if root.fields[5].get()==1: output += "%s%-8s" % (line, self.getDateLastSubmit()[:8])        
            if root.fields[6].get()==1: output += "%s%-3s" % (line, str(self.getWorks()))        
            if root.fields[7].get()==1: output += "%s%s" % (line, self.note)
        except: print("output error")
        return output

    def show(self, root, new=False):
        card=tercard.Tercard(self, root, new=new)
        if card.saved==False:
            if card.savedAction==True:
                result, root.db, root.settings=d.load(root)
                root.log("Отменена операция выдачи/сдачи в участке %s." % self.number)
                root.updateS()
            elif card.new==True:
                del root.db[len(root.db)-1] # if creation of new ter is cancelled without saving, delete it (by last index)            
        
    
    def getStatus(self, root):
        if len(self.works)==0 or self.getDate2()!="": return 0
        elif self.getDate2()=="" and self.getDelta1()<root.timeoutDays: return 1
        else: return 2
        
    def getWorks(self):
        """ Return number of works """
        if len(self.works)==0: result=0
        elif self.works[len(self.works)-1][2]!="": result=len(self.works)
        else: result=len(self.works)-1
        return result
        
    def getPublisher(self):
        """ Return publisher of last work, if exists """
        if len(self.works)==0: return ""
        else: return self.works[len(self.works)-1][0]
        
    def getCurrentPublisher(self):
        """ Return current publisher, if he works on ter """
        if self.getDate1()!="" and self.getDate2()=="": return self.getPublisher()
        else: return ""
       
    def getDate1(self):
        """ Return date 1 of last work, if exists """
        if len(self.works)==0: return ""
        else: return self.works[len(self.works)-1][1]
        
    def getDate2(self):
        """ Return date 2 of last work, if exists """
        if len(self.works)==0: return ""
        else: return self.works[len(self.works)-1][2]
        
    def getDateLastSubmit(self):
        """ Return last submission date """
        if len(self.works)==0: return ""
        elif self.works[len(self.works)-1][2]!="": return self.works[len(self.works)-1][2]
        elif len(self.works)>1 and self.works[len(self.works)-2][2]!="": return self.works[len(self.works)-2][2]
        else: return ""
        
    def getDate2Prev(self):
        """ Return date 2 of previous to last work, if exists """
        return self.works[len(self.works)-2][2]
        
    def give(self, root, silent=False, fromTerCard=False):
        if silent==False and root.chosenPublisher.get().strip()=="": root.setPublisher()
        if root.actPrompts.get()==1: answer=mb.askyesno("Выдача участка", "Выдать участок %s возвещателю %s в дату %s?" % (self.number, root.chosenPublisher.get(), root.chosenDate.get().strip()))
        else: answer=True
        if answer==True:
            self.works.append([root.chosenPublisher.get(), root.chosenDate.get().strip(), ""])
            root.log("Выдан участок %s (%s, %s)." % (self.number, root.chosenPublisher.get(), root.chosenDate.get().strip()))
            if fromTerCard==False: root.save()                
        
    def submit(self, root, silent=False, fromTerCard=False):
        if silent==False:
            if root.actPrompts.get()==1: answer=mb.askyesno("Сдача участка", "Сдать участок %s возвещателя %s в дату %s?" % (self.number, self.getPublisher(), root.chosenDate.get()))
            else: answer=True
            if answer==True:
                self.works[len(self.works)-1][2]=root.chosenDate.get().strip()
                if fromTerCard==False: root.save()
                root.log("Сдан участок %s (%s, %s)." % (self.number, self.getPublisher(), root.chosenDate.get()))
        else: self.works[len(self.works)-1][2]=root.chosenDate.get().strip()

    def getDelta1(self):
        """ Calculates number of days since last date1 of selected ter """
        try: 
            d0 = datetime.date( int(d.convert(self.getDate1())[0:4]), int(d.convert(self.getDate1())[5:7]), int(d.convert(self.getDate1())[8:10]) )
            ds = time.strftime("%Y-%m-%d", time.localtime())
            d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
            return (d1-d0).days
        except: return 999999
        
    def getDelta2(self):
        """ Calculates number of days since last date2 of selected ter """
        try: 
            d0 = datetime.date( int(d.convert(self.getDate2())[0:4]), int(d.convert(self.getDate2())[5:7]), int(d.convert(self.getDate2())[8:10]) )
            ds = time.strftime("%Y-%m-%d", time.localtime())
            d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
            return (d1-d0).days
        except:
            try:
                d0 = datetime.date( int(d.convert(self.getDate2Prev())[0:4]), int(d.convert(self.getDate2Prev())[5:7]), int(d.convert(self.getDate2Prev())[8:10]) )
                ds = time.strftime("%Y-%m-%d", time.localtime())
                d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )
                return (d1-d0).days
            except: return 999999
            
    def getAverageWork(self):
        """ Return average number of days between works of this ter (as list)"""        
        average=[]
        if self.getWorks()!=0:            
            for i in range(len(self.works)):
                if self.works[i][2]!="":
                    d0 = datetime.date( int(d.convert(self.works[i][1])[0:4]), int(d.convert(self.works[i][1])[5:7]), int(d.convert(self.works[i][1])[8:10])) 
                    d1 = datetime.date( int(d.convert(self.works[i][2])[0:4]), int(d.convert(self.works[i][2])[5:7]), int(d.convert(self.works[i][2])[8:10]))
                    average.append((d1-d0).days)
        return average
            
    def exportXLS_List(self, root):
        if self.getCurrentPublisher()!="":
            publisher=self.getCurrentPublisher()
            date1=self.getDate1()+" "
            date2=""
        else:
            publisher=self.getPublisher()
            date1=self.getDate1()+" "
            date2=self.getDate2()+" "
        if publisher=="": date1=""
        if root.images.get()==1: return ["%s\u00A0" % self.number, self.type+"\u00A0", self.address+"\u00A0", self.note+"\u00A0", Formula("HYPERLINK(\"%s\u00A0\";\"%s\")" % (self.map, self.map)), self.image+"\u00A0", publisher+"\u00A0", date1+"\u00A0", date2+"\u00A0"]
        else: return ["%s\u00A0" % self.number, self.type+"\u00A0", self.address+"\u00A0", self.note+"\u00A0", Formula("HYPERLINK(\"%s\u00A0\";\"%s\")" % (self.map, self.map)), publisher+"\u00A0", date1+"\u00A0", date2+"\u00A0"]                                                                      #  if ter pics disabled, don't export
        
    def exportXLS_S13(self):
        return self.number

def load(root, filename="", onlySettings=False):    
    result=False
    db=[]
    settings=[]    
    if onlySettings==False:
        if filename=="": filename="core.hal"
        try:
            with open(filename, "rb") as f: db=pickle.load(f)                       # load database 
            if len(db)!=0 and db[0].address=="" and db[0].number=="" and db[0].type=="": pass
            result=True
        except:
            print("corrupt or absent file, create blank array")                     # if none, create blank list                                                                             
    try:
        with open("settings.ini", "r", encoding="utf-8") as file:
            content = [line.rstrip() for line in file]
            if len(content)!=20:
                print("content length is %d, raise error" % len(content))
                raise
            settings.append(content[0][content[0].index("=")+1:])
            settings.append(content[1][content[1].index("=")+1:])
            settings.append(content[2][content[2].index("=")+1:])
            settings.append(content[3][content[3].index("=")+1:])
            settings.append(content[4][content[4].index("=")+1:])
            settings.append(content[5][content[5].index("=")+1:])
            settings.append(content[6][content[6].index("=")+1:])
            settings.append(content[7][content[7].index("=")+1:])
            for i in range(8): settings[7]+=content[7][i]
            settings.append(content[8][content[8].index("=")+1:])
            settings.append(content[9][content[9].index("=")+1:])
            settings.append(content[10][content[10].index("=")+1:])
            settings.append(content[11][content[11].index("=")+1:])
            settings.append(content[12][content[12].index("=")+1:])
            settings.append(content[13][content[13].index("=")+1:])
            settings.append(content[14][content[14].index("=")+1:])
            settings.append(content[15][content[15].index("=")+1:])
            settings.append(content[16][content[16].index("=")+1:])
            settings.append(content[17][content[17].index("=")+1:])
            settings.append(content[18][content[18].index("=")+1:])
            settings.append(content[19][content[19].index("=")+1:])
            #print("all settings loaded from file")        
    except: 
        print("no settings, create blank")
        settings.append("Номер (1)")                                            # 0 default sort type
        settings.append(1)                                                      # 1 auto update
        settings.append(1)                                                      # 2 grid on list
        settings.append(1)                                                      # 3 images in ters
        settings.append(1)                                                      # 4 search in history
        settings.append(1)                                                      # 5 bottom scrollbar
        settings.append(0)                                                      # 6 lines in grid
        settings.append("11111111")                                             # 7 table fields
        settings.append(getWinFonts()[0])                                       # 8 list font
        settings.append("9")                                                    # 9 list font size
        settings.append(0)                                                      # 10 double address field
        settings.append(0)                                                      # 11 worked ter should be given within year (inactive for now)
        settings.append(0)                                                      # 12 note in card as text field
        settings.append(1)                                                      # 13 create new ter on Insert        
        settings.append(1)                                                      # 14 show splash screen
        settings.append(180)                                                    # 15 days of timedout ters
        settings.append(0)                                                      # 16 exact search
        settings.append("По всем полям")                                        # 17 search range
        settings.append(5000)                                                   # 18 log length
        settings.append(1)                                                      # 19 prompts on give/submit
    return result, db, settings    

def convert(d):
    """Convert DD.MM.YY date into YYYY-MM-DD"""    
    try: return "20"+d[6]+d[7]+"-"+d[3]+d[4]+"-"+d[0]+d[1]
    except: return ""
    
def convertBack(d):
    """Convert YYYY-MM-DD date into DD.MM.YY date"""        
    try: result = d[8]+d[9]+"."+d[5]+d[6]+"."+d[2]+d[3]
    except: result="01.01.01"
    else: 
        if verifyDate(result, silent=True)==False: result="01.01.01"
    return result

def ifInt(char):
    """Check if value is integer"""    
    try: int(char) + 1
    except: return False
    else: return True

def verifyDate(date, silent=False):
    """Return False if date is incorrect, and shows warning"""    
    try:
        if  ifInt(date[0])==True and\
            ifInt(date[1])==True and\
            date[2]=="." and\
            ifInt(date[3])==True and\
            ifInt(date[4])==True and\
            date[5]=="." and\
            ifInt(date[6])==True and\
            ifInt(date[7])==True and\
            int(date[0]+date[1])<=31 and\
            int(date[3]+date[4])<=12 and\
            len(date)==8:        
                correct=True
        else: correct=False
    except: correct=False
    if correct==False and silent==False: mb.showwarning("Неверная дата", "Дата введена неправильно. Проверьте формат: ДД.ММ.ГГ, например 30.12.16.")
    return correct
    
def verifyDateYYYY(date):
    """The same as verifyDate, but with YYYY (only for Excel imports), and returns truncated date to DD.MM.YY"""
    correct=False    
    if len(date)==8:    
        try:
            if  ifInt(date[0])==True and\
                ifInt(date[1])==True and\
                date[2]=="." and\
                ifInt(date[3])==True and\
                ifInt(date[4])==True and\
                date[5]=="." and\
                ifInt(date[6])==True and\
                int(date[0]+date[1])<=31 and\
                int(date[3]+date[4])<=12 and\
                ifInt(date[7])==True: 
                    correct=True
            else: pass
        except: pass    
    return correct
    
def updateApp(root):
    def run(threadName, delay):
        try:
            print("checking updates")
            file=urllib.request.urlopen("https://raw.githubusercontent.com/antorix/Halieus/master/version.txt")
        except:
            print("update check failed")
            return
        else:
            version=str(file.read())
            newversion=[int(version[2]), int(version[4]), int(version[6: len(version)-3 ])]
            with open("Halieus.pyw", "r", encoding="utf-8") as file: content = [line.rstrip() for line in file]
            thisversion=[int(content[0][10:][0]), int(content[0][10:][2]), int(content[0][10:][4: len(content)-3 ])]    
            print(thisversion)
            print(newversion)
            if newversion>thisversion:
                print("new version found!")
                try: urllib.request.urlretrieve("http://github.com/antorix/Halieus/raw/master/update.zip", "update.zip")
                except: print("download failed")
                else: print("download complete")                    
                try:
                    zip=zipfile.ZipFile("update.zip", "r")
                    zip.extractall("")
                    zip.close()
                    os.remove("update.zip")
                except: print("unpacking failed")
                else:
                    print("unpacking complete")
                    mb.showinfo("Обновление","Установлена новая версия Hаlieus! Изменения будут доступны после перезапуска программы.")
                    root.log("Установлена новая версия программы.")
                    try:
                        print("deleting obsolete files")                        # delete obsolete files from older versions
                        for f in glob ("images/*.png"): os.remove(f)
                        os.remove("icons.py")
                        os.remove("images/lens13.gif")
                        os.remove("images/timeout16.gif")
                        os.remove("images/book16.gif")                        
                        os.remove("images/bulb.ico")
                        os.remove("images/info.ico")
                    except: print("something went wrong (maybe no files)")
                    else: print("successfully deleted")
            else: print("no new version found")
    try: _thread.start_new_thread(run,("Thread-Load", 1,))
    except: print("can't run thread")

def getDelta(date):
    """ Calculates number of days since given date """
    try: 
        d0 = datetime.date( int(d.convert(date)[0:4]), int(d.convert(date)[5:7]), int(d.convert(date)[8:10]) )
        ds = time.strftime("%Y-%m-%d", time.localtime())
        d1 = datetime.date( int(ds[0:4]), int(ds[5:7]), int(ds[8:10]) )            
        return (d1-d0).days
    except: return 999999

def getWinFonts():
    """Try to get a nice font on Windows as default, return first font or Courier if none found"""
    fonts=[]
    if os.name=="nt":
        try:
            osFonts=os.listdir("C:/WINDOWS/fonts")
            if "LiberationMono-Regular.ttf" in osFonts: fonts.append("Liberation Mono")
            if "DejaVuSansMono_0.ttf" in osFonts: fonts.append("DejaVu Sans Mono")
            if "lucon.ttf" in osFonts: fonts.append("Lucida Console")
            if "cousine-regular.ttf" in osFonts: fonts.append("Cousine")
            if "firamono-regular.ttf" in osFonts: fonts.append("Fira Mono")
            if "PTM55F.ttf" in osFonts: fonts.append("PT Mono")
            if "ubuntumono-r.ttf" in osFonts: fonts.append("Ubuntu Mono")            
        except: print("no good font found on Windows")
    fonts.append("Courier New")
    return fonts
