#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk  
from tkinter import ttk 
import tkinter.messagebox as mb 
import xlwt
import xlrd
from tkinter import filedialog 
import webbrowser 
from classes import CreateToolTip

try: import contacts_mod                                                        # import file to modify some aspects of contacts, if exists
except: Mod=False
else: Mod=True
 
class MainTab(): 
    """Main tab of contacts""" 
    def __init__(self, root): 
 
        # Initialize tab
        global Mod
        self.Mod=Mod
        self.root=root 
        self.tabCon=tk.Frame(self.root.notebook)                                    
        self.root.notebook.add(self.tabCon, text=self.root.msg[293], image=self.root.img[66], compound="left") 
        self.tabCon.columnconfigure(0, weight=1) 
        self.tabCon.rowconfigure(0, weight=1)
        self.tabCon.rowconfigure(1, weight=1)
        self.tabCon.rowconfigure(2, weight=1)
        self.entryWidth=30                                                      
        self.selected=None 
        self.tabCon.bind("<Visibility>", self.update)
         
        # Contacts frame 
        self.conFrame=tk.Frame(self.tabCon) 
        self.conFrame.grid(column=0, columnspan=1, row=0, rowspan=4, sticky="wnse")
         
        self.statFrame=tk.Frame(self.conFrame)                                  # statistics 
        self.statFrame.pack(fill="x",padx=self.root.padx, pady=self.root.pady, ) 
        self.stat=tk.Label(self.statFrame) 
        self.stat.pack(side="left")
        ttk.Button(self.statFrame, text=self.root.msg[325], image=self.root.img[47], compound="left", command=lambda: mb.showinfo(self.root.msg[293], self.root.msg[326])).pack(side="top", anchor="e")
        
        self.headers=["", self.root.msg[294], self.root.msg[273], self.root.msg[295], self.root.msg[274]] # list
        if self.Mod==True: self.headers[4]=contacts_mod.noteField
        self.style = ttk.Style()
        self.conList=ttk.Treeview(self.conFrame, padding=(0,0,20,0), columns=self.headers, selectmode="browse", show="headings", style="Treeview")
        self.conList.heading(1, image=self.root.img[35])        
        self.rightScrollbar = ttk.Scrollbar(self.conList, orient="vertical", command=self.conList.yview) 
        self.conList.configure(yscrollcommand=self.rightScrollbar.set) 
        self.rightScrollbar.pack(side="right", fill="y") 
        self.conList.bind("<Return>", self.openTer) 
        self.conList.bind("<Double-1>", self.openTer) 
        self.conList.bind("<<TreeviewSelect>>", self.listSelect) 
        self.conList.bind("<3>", lambda event: self.listmenu.post(event.x_root, event.y_root)) 
        self.conList.bind("<space>", self.moveCon) 
        self.conList.bind("<Delete>", self.deleteCon) 
        self.conList.pack(fill="both", expand=True)
        self.conList.column(0, width=30)
        self.sortCon=tk.IntVar() 
        self.sortCon.set(0)
         
        self.listbar = tk.Menu(self.conList)                                    # list context menu 
        self.listmenu = tk.Menu(self.listbar, tearoff=0) 
        self.listmenu.add_command(label=self.root.msg[348], image=self.root.img[27], compound="left", command=self.openTer) 
        self.listmenu.add_command(label=self.root.msg[347], image=self.root.img[80], compound="left", command=self.moveCon) 
        self.listmenu.add_command(label=self.root.msg[346], image=self.root.img[79], compound="left", command=self.deleteCon) 
        self.listbar.add_cascade(label=self.root.msg[141], menu=self.listmenu) 
         
        self.editFrame=tk.Frame(self.tabCon, relief="flat")                     # editing 
        self.editFrame.grid(column=1, row=0, sticky="new") 
        self.editFrame.columnconfigure(1, weight=1) 
        self.editFrame.rowconfigure(0, weight=1) 
        self.ter=tk.Label(self.editFrame) 
        self.ter.grid(column=1, row=0, padx=self.root.padx, pady=self.root.pady, sticky="w") 
        ttk.Label(self.editFrame, text=self.root.msg[273]).grid(column=0, row=1, padx=self.root.padx, pady=self.root.pady, sticky="w") 
        self.address=ttk.Entry(self.editFrame, width=self.entryWidth, state="disabled") 
        self.address.grid(column=1, row=1, padx=self.root.padx, pady=self.root.pady, sticky="we")
        ttk.Label(self.editFrame, text=self.root.msg[295]).grid(column=0, row=2, padx=self.root.padx, pady=self.root.pady, sticky="w") 
        self.name=ttk.Entry(self.editFrame, width=self.entryWidth, state="disabled")         
        self.name.grid(column=1, row=2, padx=self.root.padx, pady=self.root.pady, sticky="we") 
        if self.Mod==False: ttk.Label(self.editFrame, text=self.root.msg[274]).grid(column=0, row=3, padx=self.root.padx, pady=self.root.pady, sticky="w") 
        self.note=ttk.Entry(self.editFrame, width=self.entryWidth, state="disabled")         
        self.note.grid(column=1, row=3, padx=self.root.padx, pady=self.root.pady, sticky="we")
        self.saveButton=ttk.Button(self.editFrame, text=self.root.msg[297], image=self.root.img[67], compound="left", style='action.TButton', state="disabled", command=self.editCon) 
        self.saveButton.grid(column=1, columnspan=1, row=4, rowspan=2, padx=self.root.padx, pady=self.root.pady, sticky="nesw")  
        self.address.bind("<Return>", lambda x: self.editCon())
        self.name.bind("<Return>", lambda x: self.editCon())
        self.note.bind("<Return>", lambda x: self.editCon())
         
        self.buttonFrame=tk.Frame(self.tabCon)                                  # import/export
        self.buttonFrame.grid(column=1,row=1, sticky="ew") 
        self.buttonFrame.columnconfigure(0, weight=1)
        self.buttonFrame.columnconfigure(2, weight=1)        
        ttk.Button(self.buttonFrame, text=self.root.msg[298], image=self.root.img[75], compound="top", command=self.importCon)\
        .grid(column=0,row=0, padx=self.root.padx*3, pady=self.root.pady, sticky="wnes")
        ttk.Separator(self.buttonFrame, orient='vertical').grid (column=1, row=0, rowspan=3, pady=self.root.pady, sticky='nswe')
        self.exportButton=ttk.Button(self.buttonFrame, text=self.root.msg[299], image=self.root.img[42], compound="top")
        self.exportButton.grid(column=2,row=0, padx=self.root.padx*3, pady=self.root.pady, sticky="wnes")
        if self.Mod==False: self.exportButton.bind("<1>", self.export)        
        self.exportType=tk.IntVar()                                                   
        self.exportType.set(0)
        ttk.Radiobutton(self.buttonFrame, text=self.root.msg[300], variable=self.exportType, value=0).grid(column=2,row=1, padx=self.root.padx*5, pady=self.root.pady, sticky="nw")
        if self.Mod==False: ttk.Radiobutton(self.buttonFrame, text=self.root.msg[301], variable=self.exportType, value=1).grid(column=2,row=2, padx=self.root.padx*5, pady=self.root.pady, sticky="nw")
        
        self.new=ttk.LabelFrame(self.tabCon, text=self.root.msg[302])           # new contact 
        self.new.grid(column=1,row=2, padx=self.root.padx, pady=self.root.pady, sticky="ew") 
        ttk.Label(self.new, text=self.root.msg[273]).grid(column=0, row=0, padx=self.root.padx, pady=self.root.pady, sticky="w") 
        self.addressNew=ttk.Entry(self.new, width=self.entryWidth, state="disabled") 
        self.addressNew.grid(column=1, row=0, padx=self.root.padx, pady=self.root.pady, sticky="we")         
        ttk.Label(self.new, text=self.root.msg[295]).grid(column=0, row=1, padx=self.root.padx, pady=self.root.pady, sticky="w") 
        self.nameNew=ttk.Entry(self.new, width=self.entryWidth, state="disabled") 
        self.nameNew.grid(column=1, row=1, padx=self.root.padx, pady=self.root.pady, sticky="we")         
        if self.Mod==False: ttk.Label(self.new, text=self.root.msg[274]).grid(column=0, row=2, padx=self.root.padx, pady=self.root.pady, sticky="w") 
        self.noteNew=ttk.Entry(self.new, width=self.entryWidth, state="disabled") 
        self.noteNew.grid(column=1, row=2, padx=self.root.padx, pady=self.root.pady, sticky="we")        
        self.newButton=ttk.Button(self.new, state="disabled", image=self.root.img[38], compound="left", style='action.TButton', command=self.newSave) 
        self.newButton.grid(column=1, columnspan=1, row=3, rowspan=2, padx=self.root.padx, pady=self.root.pady, sticky="nesw")        
        self.addressNew.bind("<Return>", lambda x: self.newSave())
        self.nameNew.bind("<Return>", lambda x: self.newSave())
        self.noteNew.bind("<Return>", lambda x: self.newSave())
        
        self.chosenTer=ttk.Label(self.tabCon, image=self.root.img[25], compound="left") # chosen ter on ter tab 
        self.chosenTer.grid(column=1,row=3, sticky="ws")
        self.chosenTer.bind("<1>", self.queryForTer)
        CreateToolTip(self.chosenTer, self.root.msg[303])
       
        self.hide=tk.IntVar()                                                   # hide all contacts not from chosen ter
        self.hide.set(0)
        self.hideButton=ttk.Checkbutton(self.tabCon, text=self.root.msg[304], variable=self.hide, command=self.update)
        self.hideButton.grid(column=1,row=3, sticky="es")
        CreateToolTip(self.hideButton, self.root.msg[305])
        
        self.drawList()
        self.conList.column(1, width=130)
        self.conList.column(2, width=150)
        self.conList.column(3, width=150)
        self.conList.column(4, width=110)
        
        if self.Mod==True: contacts_mod.init(self)
    
    def queryForTer(self, event=None):
        self.root.notebook.select(self.root.tabList)
        self.root.quickTip(self.root.msg[306])
     
    def drawList(self):
        self.style.configure("Treeview", font=self.root.font)
        self.conList.delete(*self.conList.get_children())
        self.values=tuple(self.getContent())
        for col in self.headers: self.conList.heading(col, text=col.title(), command=lambda c=col: self.sort(c))
        for item in self.values: self.conList.insert('', 'end', values=item)
        self.stat["text"]=self.root.msg[307] % (len(self.contentFormatted), self.noteNumber)       
        if self.Mod==True: self.stat["text"]=contacts_mod.contactStats % (len(self.contentFormatted), self.noteNumber)
        self.conList.column(0, width=50)
     
    def update(self, event=None):
        if len(self.root.list.curselection())>0: 
            self.selected=self.root.db[self.root.list.curselection()[0]]        # actual selected ter (db index)         
        if self.selected!=None: 
            self.chosenTer["text"]=self.root.msg[308]+" №%s" % self.selected.number[:5] 
            self.newButton["text"]=self.root.msg[309]+" №%s" % self.selected.number[:11] 
            self.newButton["state"]="!disabled" 
            self.addressNew["state"]="normal" 
            self.nameNew["state"]="normal" 
            self.noteNew["state"]="normal" 
        else: 
            self.chosenTer["text"]="?" 
            self.newButton["text"]=self.root.msg[309] 
            self.newButton["state"]="disabled" 
            self.addressNew["state"]="disabled" 
            self.nameNew["state"]="disabled" 
            self.noteNew["state"]="disabled"         
        self.drawList()        
         
    def listSelect(self, event=None): 
        if len(self.conList.selection())==1: 
            self.selectedCon=self.getSelectedCon()[0] 
            self.selectedTer=self.getSelectedTer()          
            self.address["state"]="normal" 
            self.address.delete(0, "end") 
            self.address.insert(0, self.getSelectedCon()[0][0]) 
            self.name["state"]="normal" 
            self.name.delete(0, "end") 
            self.name.insert(0, self.getSelectedCon()[0][1]) 
            self.note["state"]="normal" 
            self.note.delete(0, "end") 
            self.note.insert(0, self.getSelectedCon()[0][2])            
            self.saveButton["state"]="!disabled"
            curItem = self.conList.focus()
            s=self.conList.item(curItem)["values"][0]            
            self.saveButton["text"]=self.root.msg[310]+" %s" % s
        elif self.address.focus_get()=="" and self.name.focus_get()=="" and self.note.focus_get()=="": 
            self.name["state"]="disabled" 
            self.name.delete(0, "end") 
            self.address["state"]="disabled" 
            self.note["state"]="disabled" 
            self.ter["text"]="" 
            self.saveButton["text"]=self.root.msg[310]
            self.saveButton["state"]="disabled"         
         
    def getSelectedCon(self): 
        """Return ter.extra object of item selected from list as [0], and all self.content attributes as [1]""" 
        curItem = self.conList.focus()
        try: s=self.conList.item(curItem)["values"][0]-1
        except: return None
        return self.content[s][4].extra[0][self.content[s][5]], self.content[s] 
         
    def getSelectedTer(self): 
        """Return ter object of item selected from list""" 
        try:
            curItem = self.conList.focus()
            s=self.conList.item(curItem)["values"][0]-1
            return self.content[s][4] 
        except: pass
    
    def sort(self, col):
        """sort tree contents when a column header is clicked on"""
        if col==self.headers[1]:
            self.sortCon.set(0)
            self.conList.heading(0, image="")
            self.conList.heading(1, image=self.root.img[35])
            self.conList.heading(2, image="")
            self.conList.heading(3, image="")            
            self.conList.heading(4, image="")
        elif col==self.headers[2]:
            self.sortCon.set(1)
            self.conList.heading(0, image="")
            self.conList.heading(1, image="")
            self.conList.heading(2, image=self.root.img[35])
            self.conList.heading(3, image="")
            self.conList.heading(4, image="")
        elif col==self.headers[3]:
            self.sortCon.set(2)
            self.conList.heading(0, image="")
            self.conList.heading(1, image="")
            self.conList.heading(2, image="")
            self.conList.heading(3, image=self.root.img[35])
            self.conList.heading(4, image="")
        elif col==self.headers[4]:
            self.sortCon.set(3)
            self.conList.heading(0, image="")
            self.conList.heading(1, image="")
            self.conList.heading(2, image="")
            self.conList.heading(3, image="")
            self.conList.heading(4, image=self.root.img[35])            
        self.drawList()
   
    def editCon(self, event=None): 
        self.selectedCon[0]=self.address.get().strip() 
        self.selectedCon[1]=self.name.get().strip() 
        self.selectedCon[2]=self.note.get().strip() 
        self.root.log(self.root.msg[311] % (self.selectedTer.number, self.selectedCon[0], self.selectedCon[1], self.selectedCon[2])) 
        self.root.save() 
        self.update()
         
    def moveCon(self, event=None):         
        if self.selected==None: mb.showwarning(self.root.msg[1], self.root.msg[312]) 
        elif self.getSelectedCon()!=None:           
            if len(self.selected.extra)==0: self.selected.extra.append([]) 
            self.selected.extra[0].append([self.getSelectedCon()[0][0], self.getSelectedCon()[0][1], self.getSelectedCon()[0][2]]) 
            self.root.log(self.root.msg[313] %\
                (self.getSelectedCon()[0][0], self.getSelectedCon()[0][1], self.getSelectedCon()[0][2], self.getSelectedTer().number, self.selected.number)) 
            self.deleteCon(move=True)                         
         
    def deleteCon(self, event=None, move=False):        
        curItem = self.conList.focus()
        try: s=self.conList.item(curItem)["values"][0]-1
        except: return        
        con=self.content[s][4].extra[0][self.content[s][5]]
        if move==False and mb.askyesno(self.root.msg[344], self.root.msg[345] % (self.getSelectedTer().number, con[0], con[1], con[2]))==False: return
        self.root.log(self.root.msg[314] % (self.getSelectedTer().number, con[0], con[1], con[2]))             
        del self.content[s][4].extra[0][self.content[s][5]]        
        self.root.save() 
        self.update()
         
    def newSave(self, event=None): 
        if len(self.selected.extra)==0: self.selected.extra.append([]) 
        self.selected.extra[0].append([self.addressNew.get().strip(), self.nameNew.get().strip(), self.noteNew.get().strip()])        
        self.root.save() 
        self.root.log(self.root.msg[315] % (self.selected.number, self.addressNew.get().strip(), self.nameNew.get().strip(), 
self.noteNew.get().strip())) 
        self.update() 
         
    def getContent(self):
        self.content=[] 
        self.contentFormatted=[] 
        self.noteNumber=0 
        for ter in self.root.db: 
            if len(ter.extra)>0: 
                for e in range(len(ter.extra[0])):
                    if self.hide.get()==0 or self.selected==ter:
                        self.content.append([ter.number, ter.extra[0][e][0], ter.extra[0][e][1], ter.extra[0][e][2], ter, e])         
                        if ter.extra[0][e][2].strip()!="": self.noteNumber+=1 
        if self.sortCon.get()==0: 
            try: self.content.sort(key=lambda x: float(x[0]))  
            except:                
                self.content.sort     (key=lambda x: x[0])
                self.content.sort     (key=lambda x: x[4].getNumerical())                
        elif self.sortCon.get()==1: self.content.sort(key=lambda x: x[1])  
        elif self.sortCon.get()==2: self.content.sort(key=lambda x: x[2])  
        elif self.sortCon.get()==3: self.content.sort(key=lambda x: x[3])          
        for i in range(len(self.content)): 
            self.contentFormatted.append((i+1, "№%s–%s" % (self.content[i][0], self.content[i][4].address), self.content[i][1], self.content[i][2], self.content[i][3])) 
        return self.contentFormatted 
 
    def openTer(self, event=None): 
        try: self.getSelectedTer().show(self.root) 
        except: pass
             
    def export(self, event=None):
        wb=xlwt.Workbook() 
        ws=wb.add_sheet(self.root.msg[293]) 
        row=0
        shrink=xlwt.easyxf('alignment: shrink True')
        for i in range(len(self.content)): 
            if self.exportType.get()==0 or self.content[i][3]!="": 
                ws.write(row, 0, "№%s-%s" % (self.content[i][0], self.content[i][4].address), style=shrink) 
                ws.write(row, 1, self.content[i][1]+"\u00A0", style=shrink) 
                ws.write(row, 2, self.content[i][2]+"\u00A0", style=shrink)
                ws.write(row, 3, self.content[i][3]+"\u00A0", style=shrink)
                row+=1
        for i in range(4): ws.col(i).width = 7000
        
        ftypes=[(self.root.msg[240], '.xls')]                                             # save 
        filename=filedialog.asksaveasfilename(filetypes=ftypes, initialfile=self.root.msg[316]+".xls", defaultextension='.xls') 
        if filename!="": 
            try: wb.save(filename) 
            except: 
                mb.showerror(self.root.msg[1], self.root.msg[241] % filename) 
                print("export error") 
                self.card.root.log(self.root.msg[242] % filename) 
            else: 
                print("export successful") 
                self.root.log(self.root.msg[317] % filename) 
                if mb.askyesno(self.root.msg[244], self.root.msg[245])==True: webbrowser.open(filename) 
                
    def importCon(self):
        global Mod
        mb.showinfo(self.root.msg[298], self.root.msg[318])
        ftypes = [(self.root.msg[240], '.xls')]
        filename=filedialog.askopenfilename(filetypes=ftypes, defaultextension='.xls')        
        if filename!="":
            try: book = xlrd.open_workbook(filename, formatting_info=True)
            except:
                mb.showerror(self.root.msg[1], self.root.msg[250] % filename)
                print("import error")
                self.root.log(self.root.msg[319] % filename)
                self.root.updateLog()
            else:                
                if Mod==True: myNumber=contacts_mod.convertNumber(filename)
                else: myNumber="0"                
                self.root.newTer(silent=True, number=myNumber, type=self.root.msg[320], address=self.root.msg[321], note=self.root.msg[322])
                newTer=self.root.db[len(self.root.db)-1]
                newTer.extra.append([])
                sheet=book.sheet_by_index(0)
                for row in range(sheet.nrows):
                    newTer.extra[0].append([sheet.cell(row,0).value, sheet.cell(row,1).value, sheet.cell(row,2).value])        
                self.root.save()
                self.root.updateS()
                self.root.log(self.root.msg[323] % filename)
                print("import successful")
                self.update()

class TerTab(): 
    """Tab inside ter"""     
    def __init__(self, card):
        global Mod
        self.Mod=Mod
        self.card=card 
        self.tab=tk.Frame(self.card.nb)
        self.contacts=self.getContent()
        self.card.nb.add(self.tab, text=self.card.root.msg[293]+" (%d)" % len(self.contacts), image=self.card.root.img[66], compound="left") 
        self.tab.grid_columnconfigure (1, weight=1) 
        self.tab.grid_rowconfigure (1, weight=1) 
        self.info=tk.Label(self.tab, image=None, compound="right") 
        self.info.grid(column=0, columnspan=2, row=0, sticky="e") 
        
        self.headers=["", "",""]#self.card.root.msg[273], self.card.root.msg[295]]
        self.list=ttk.Treeview(self.tab, padding=(0,0,20,0), columns=self.headers, selectmode="browse", show="headings", style="Treeview")
        self.list.grid(column=0, row=0, columnspan=3, rowspan=2, padx=self.card.root.padx, sticky="nesw") 
        self.list.column(0, width=30)
        self.list.column(1, width=70)
        self.rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview) 
        self.list.configure(yscrollcommand=self.rightScrollbar.set) 
        self.rightScrollbar.pack(side="right", fill="y")     
        self.list.delete(*self.list.get_children())
        self.values=tuple(self.contacts)
        if self.Mod==False:
            for col in self.headers: self.list.heading(col, text=col.title())
            for item in self.values: self.list.insert('', 'end', values=item)
         
    def getContent(self): 
        if len(self.card.ter.extra)==0: return [] 
        else:             
            self.card.ter.extra[0].sort(key=lambda x: x[0])  
            output=[] 
            for i in range(len(self.card.ter.extra[0])): 
                if self.card.ter.extra[0][i][2]!="": note=" (%s)" % self.card.ter.extra[0][i][2].strip()
                else: note="" 
                output.append([i+1, self.card.ter.extra[0][i][0], self.card.ter.extra[0][i][1]+note]) 
            return output
