﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
from tkinter import filedialog
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox as mb
import webbrowser
import time
import data as d
import xlwt
import xlrd
from xldisplay import cell_display
from classes import CreateToolTip, Progress
import urllib.request
import zipfile
import _thread

def massCreate(root, form=None):
    """ Interface to create multiple ters """    
    dialog = tk.Toplevel()
    dialog.title(root.msg[223])
    dialog.tk.call('wm', 'iconphoto', dialog._w, root.img[37])
    dialog.grab_set()
    dialog.focus_force()
    w = 330
    h = 170
    x = (dialog.winfo_screenwidth()/2) - (w/2)
    y = (dialog.winfo_screenheight()/2.5) - (h/2.5)
    dialog.geometry('%dx%d+%d+%d' % (w, h, x, y))
    dialog.grid_columnconfigure (1, weight=1)
    dialog.grid_rowconfigure (3, weight=1)
    dialog.minsize(w,h)
    dialog.maxsize(w,h)
    padx=pady=5
    tip=tk.Message(dialog, text=root.msg[224], width=300)
    tip.grid(column=0, columnspan=3, row=0, padx=padx, sticky="w")
    tk.Label(dialog, text=root.msg[199]).grid(column=0, row=1, padx=padx*3, sticky="w")
    tk.Label(dialog, text=root.msg[200]).grid(column=1, row=1, padx=padx*3, sticky="w")
    tk.Label(dialog, text=root.msg[201]+":").grid(column=2, row=1, padx=padx*3, sticky="w")
    value1=ttk.Entry(dialog, width=8)
    value1.grid(column=0, row=2, padx=padx*3, sticky="wn")
    value1.focus_force()
    value2=ttk.Entry(dialog, width=8)
    value2.grid(column=1, row=2, padx=padx*3, sticky="wn")
    value3=ttk.Entry(dialog, width=8)
    value3.grid(column=2, row=2, padx=padx*3, sticky="wn") 
    error=tk.Label(dialog, fg="red")
    error.grid(column=0, row=3, columnspan=3, padx=padx*3, sticky="we")
    def generate():
        dialog["cursor"]="watch"
        dialog.update()                
        try:
            if root.chosenDate.get()=="": root.insertDate()
            for i in range(int(value1.get().strip()), int(value2.get().strip())+1): root.newTer(root, number=str(i), type=value3.get().strip(), silent=True)
        except: error.configure(fg="red", text=root.msg[202])
        else:
            root.save()
            error.configure(fg="darkgreen", text=root.msg[179]+"!")
            root.log(root.msg[203] % (int(value1.get().strip()), int(value2.get().strip())))
            root.updateLog()
        dialog["cursor"]="arrow"
    ttk.Button(dialog, text=root.msg[204], style="big.TButton", image=root.img[37], compound="left", command=generate).grid(column=0, row=4, columnspan=3, ipadx=5, ipady=5, padx=padx, pady=pady, sticky="s")
    def quit(event): dialog.destroy()
    dialog.bind("<Escape>", quit)
    if form!=None: form.destroy()

def massEdit(root):
    selection=root.list.curselection()
    dialog=tk.Toplevel()
    dialog.title(root.msg[205] % len(selection))
    dialog.tk.call('wm', 'iconphoto', dialog._w, root.img[12])
    dialog.grab_set()
    dialog.focus_force()
    w = 455
    h = 570
    x = (dialog.winfo_screenwidth()/2) - (w/2)
    y = (dialog.winfo_screenheight()/2) - (h/2)-40
    dialog.geometry('%dx%d+%d+%d' % (w, h, x, y))
    dialog.minsize(w,h)
    dialog.maxsize(w,h)
    padx=pady=5
    def quit(event): dialog.destroy()
    dialog.bind("<Escape>", quit) 
    labelFields=ttk.LabelFrame(dialog, text=root.msg[265])
    labelFields.pack(side="top", fill="x", padx=padx, pady=pady)
    tk.Message(labelFields, text=root.msg[206], width=420).grid(column=0, columnspan=3, row=0, padx=padx, pady=pady, sticky="w")    
    newAddress=ttk.Entry(labelFields, state="disabled")
    newAddress.grid(column=2, row=1, padx=padx, pady=pady, sticky="we")
    newType=ttk.Entry(labelFields, state="disabled")
    newType.grid(column=2, row=2, padx=padx, pady=pady, sticky="we")
    newNote=ttk.Entry(labelFields, state="disabled")
    newNote.grid(column=2, row=3, padx=padx, pady=pady, sticky="we")
    varNewAddress=tk.IntVar()
    varNewAddress.set(0)
    def addressEnable():
        if varNewAddress.get()==1: newAddress["state"]="normal"
        else: newAddress["state"]="disabled"
    ttk.Checkbutton(labelFields, text=root.msg[207], onvalue=1, offvalue=0, variable=varNewAddress, command=addressEnable).grid(column=1, row=1, padx=padx*2, pady=pady, sticky="w")    
    varNewType=tk.IntVar()
    varNewType.set(0)
    def typeEnable():
        if varNewType.get()==1: newType["state"]="normal"
        else: newType["state"]="disabled"
    ttk.Checkbutton(labelFields, text=root.msg[201], onvalue=1, offvalue=0, variable=varNewType, command=typeEnable).grid(column=1, row=2, padx=padx*2, pady=pady, sticky="w")    
    varNewNote=tk.IntVar()
    varNewNote.set(0)
    def noteEnable():
        if varNewNote.get()==1: newNote["state"]="normal"
        else: newNote["state"]="disabled"
    ttk.Checkbutton(labelFields, text=root.msg[208], onvalue=1, offvalue=0, variable=varNewNote, command=noteEnable).grid(column=1, row=3, padx=padx*2, pady=pady, sticky="w")
    labelFields.grid_columnconfigure (2, weight=1)    
    labelButtons=ttk.LabelFrame(dialog, text=root.msg[209])
    labelButtons.pack(side="top", fill="x", padx=padx, pady=pady)
    tk.Message(labelButtons, text=root.msg[210], width=420).grid(column=0, columnspan=3, row=0, padx=padx, pady=pady, sticky="w") 
    varMap=tk.IntVar()
    varMap.set(0)
    def blank():
        if varMap.get()==1 or varImg.get()==1: pass
    ttk.Checkbutton(labelButtons, text=root.msg[211], onvalue=1, offvalue=0, variable=varMap, command=blank).grid(column=0, columnspan=1, row=1, padx=padx*2, pady=pady, sticky="w")
    varImg=tk.IntVar()
    varImg.set(0)
    ttk.Checkbutton(labelButtons, text=root.msg[212], variable=varImg, command=blank).grid(column=1, columnspan=1, row=1, padx=padx, pady=pady, sticky="w")
    labelButtons.grid_columnconfigure(1, weight=1)
    labelWork=ttk.LabelFrame(dialog, text=root.msg[213])
    labelWork.pack(side="top", fill="x", padx=padx, pady=pady)
    tk.Message(labelWork, text=root.msg[214], width=420).grid(column=0, columnspan=4, row=0, padx=padx, pady=pady, sticky="w")
    varWork=tk.IntVar()
    varWork.set(0)
    def workEnable():
        if varWork.get()==1:
            newPublisher["state"]="normal"
            newDate1["state"]="normal"
            newDate2["state"]="normal"
        else:
            newPublisher["state"]="disabled"
            newDate1["state"]="disabled"
            newDate2["state"]="disabled"
    ttk.Checkbutton(labelWork, text=root.msg[215], onvalue=1, offvalue=0, variable=varWork, command=workEnable).grid(column=0, row=2, padx=padx*2, pady=pady, sticky="w")
    ttk.Label(labelWork, text=root.msg[96]).grid(column=1, row=1, padx=padx, pady=pady, sticky="w")
    ttk.Label(labelWork, text=root.msg[216]).grid(column=1, row=2, padx=padx, pady=pady, sticky="w")
    ttk.Label(labelWork, text=root.msg[217]).grid(column=1, row=3, padx=padx, pady=pady, sticky="w")
    newPublisher=ttk.Combobox(labelWork, height=30, state="disabled", textvariable=root.pubInBox) # publisher combobox
    newPublisher["values"]=root.allPublishers    
    newPublisher.grid(column=2, row=1, padx=padx, pady=pady, sticky="we")
    newDate1=ttk.Entry(labelWork, state="disabled")
    newDate1.grid(column=2, row=2, padx=padx, pady=pady, sticky="we")
    newDate2=ttk.Entry(labelWork, state="disabled")
    newDate2.grid(column=2, row=3, padx=padx, pady=pady, sticky="we")
    result=tk.Label(dialog, text="", fg="red")
    result.pack(side="top", padx=padx, pady=pady)
    def insertDate1():
        newDate1.delete(0, "end")
        newDate1.insert(0, d.dateFilter(root, time.strftime("%d.%m", time.localtime()) + "." + str(int(time.strftime("%Y", time.localtime()))-2000)))
    ttk.Button(labelWork, text=root.msg[100], style="small.TButton", command=insertDate1).grid(column=3, row=2, pady=pady, sticky="w")
    def insertDate2():
        newDate2.delete(0, "end")
        newDate2.insert(0, d.dateFilter(root, time.strftime("%d.%m", time.localtime()) + "." + str(int(time.strftime("%Y", time.localtime()))-2000)))
    ttk.Button(labelWork, text=root.msg[100], style="small.TButton", command=insertDate2).grid(column=3, row=3, pady=pady, sticky="w")       
    labelWork.grid_columnconfigure (2, weight=1)    
    def run():
        dialog["cursor"]="watch"
        dialog.update()
        if varNewAddress.get()==0 and varNewType.get()==0 and varNewNote.get()==0 and varMap.get()==0 and varImg.get()==0 and varWork.get()==0:
            result.configure(fg="red", text=root.msg[218])
        elif varWork.get()==1 and (d.verifyDate(root, newDate1.get().strip(), silent=True)==False or d.verifyDate(root, newDate2.get().strip(), silent=True)==False):
            result.configure(fg="red", text=root.msg[219])
        elif varWork.get()==1 and newPublisher.get().strip()=="":
            result.configure(fg="red", text=root.msg[220])
        else:
            for i in selection:
                if varNewAddress.get()==1:  root.db[i].address=   newAddress.get().strip()
                if varNewType.get()==1:     root.db[i].type=      newType.get().strip()
                if varNewNote.get()==1:     root.db[i].note=      newNote.get().strip()
                if varMap.get()==1:         root.db[i].map=       "https://yandex.ru/maps/?text=%s" % root.db[i].address.strip()
                if varImg.get()==1:         root.db[i].image=     root.db[i].number.strip()
                if varWork.get()==1:        root.db[i].works.insert(0, [newPublisher.get().strip(), newDate1.get().strip(), newDate2.get().strip()])
            root.save()
            root.log(root.msg[221] % len(selection)) 
            result.configure(fg="darkgreen", text=root.msg[179]+"!")
        dialog["cursor"]="arrow"
            
    ttk.Button(dialog, text=root.msg[222], style="big.TButton", image=root.img[12], compound="left", command=run).pack(side="bottom", padx=5, pady=5, ipadx=5, ipady=5)

def exportXLS(root, onlyS13=False):
    status=True
    root.master["cursor"]="watch"
    root.logWindow["cursor"]="watch"
    root.master.update()
    try: root.db.sort(key=lambda x: float(x.number)) 
    except:
        root.db.sort(key=lambda x: x.number)
        root.db.sort(key=lambda x: x.getNumerical())
    terPerPage=100
    totalPages = len(root.db) // terPerPage
    fontsize=180
    small = xlwt.easyxf('font: height 130;')           # sheet styles
    bold = xlwt.easyxf('font: bold True;' 'alignment: shrink True;' 'alignment: horizontal right')
    smallR = xlwt.easyxf('font: height 130;' 'alignment: horizontal right')
    big = xlwt.easyxf('font: height 250;' 'font: bold True')
    borderU = xlwt.easyxf('font: underline True;' 'font: height %d' % fontsize)    
    borderB = xlwt.easyxf('border: bottom thin;' 'font: height %d' % fontsize)
    #borderAll = xlwt.easyxf('borders: right thin, bottom thin, left thin, top thin;' 'font: height %d' % fontsize)
    borderTL = xlwt.easyxf('borders: top medium, left medium;' 'font: height %d' % fontsize)
    borderTR = xlwt.easyxf('borders: top medium, right medium;' 'font: height %d' % fontsize)    
    borderBL = xlwt.easyxf('borders: bottom medium, left medium, top thin, right thin;' 'font: height %d' % fontsize)
    borderBR = xlwt.easyxf('borders: bottom medium, right medium, top thin, left thin;' 'font: height %d' % fontsize)    
    root.master["cursor"]="arrow"
    root.logWindow["cursor"]="arrow"
    try: wb = xlwt.Workbook()                                                   # create sheet
    except:
        print("file creation error")
        mb.showerror(root.msg[1], root.msg[225])
    else:
        
        # Stats
        if onlyS13==False:
            ws1=wb.add_sheet(root.msg[116])
            allStats=root.getStats()
            worked,nonWorked,year,given,timedout,averagesSum=allStats    
            try: a=(len(root.db)-given)/len(root.db)*100
            except: a=0        
            try: b=(given/len(root.db))*100
            except: b=0    
            try: c=(timedout/len(root.db))*100
            except: c=0    
            try: e=(year/len(root.db))*100
            except: e=0
            f1=len(root.db)-year
            try: f2=(100-(year/len(root.db))*100)
            except: f2=0    
            try: g=(nonWorked/len(root.db))*100
            except: g=0  
            x = allStats[5]/30.5     
            content =  (    (root.msg[148], "%d\u00A0"  % len(root.db),               "",             ),
                            (root.msg[149], "%d\u00A0"  % int(len(root.db)-(given)),  "%.1f%%*" % a,  ),
                            (root.msg[150], "%d**"      % given,                      "%.1f%%"  % b,  ),
                            (root.msg[151], "%d\u00A0"  % timedout,                   "%.1f%%"  % c,  ),
                            (root.msg[226], "%d\u00A0"  % year,                       "%.1f%%"  % e,  ),
                            (root.msg[153], "%d\u00A0"  % f1,                         "%.1f%%"  % f2, ),
                            (root.msg[154], "%d\u00A0"  % nonWorked,                  "%.1f%%"  % g,  ),
                            (root.msg[155], "%.1f %s" % (x, root.msg[359]),           "",             ),
                            ("",""),
                            (root.msg[227], "","",),
                            ("","","",),
                            (root.msg[228], "","",),
                            (root.msg[229], "","",),
                            ("","","",),
                            (root.msg[230], "","",),
                            (root.msg[231], "","",),
                            ("","","",)
            )
            for i, row in enumerate(content):
                for j, col in enumerate(row):
                    if i==7: ws1.write(i, j, col, style=borderB)
                    else: ws1.write(i, j, col)
            ws1.col(0).width = 256 * max([len(row[0]) for row in content])
            
            # Ter list
            ws2 = wb.add_sheet(root.msg[232])
            content = [root.db[i].exportXLS_List(root) for i in range(len(root.db))]
            for i, row in enumerate(content):
                for j, col in enumerate(row):
                    ws2.write(i, j, col)
            ws2.col(0).width = 2000     # number
            ws2.col(1).width = 2000     # type
            ws2.col(2).width = 12000    # address
            ws2.col(3).width = 8000     # note
            ws2.col(4).width = 10000    # map
            ws2.col(5).width = 3000     # image
            ws2.col(6).width = 3500     # publisher
            ws2.col(7).width = 2500     # date1
            ws2.col(8).width = 2500     # date2
        
            if root.contactsEnabled.get()==1:
                wsCon=wb.add_sheet(root.msg[293]) 
                root.tabContacts.getContent()
                content=root.tabContacts.content        
                row=0
                shrink=xlwt.easyxf('alignment: shrink True')
                for i in range(len(content)): 
                    wsCon.write(row, 0, "№%s-%s" % (content[i][0], content[i][4].address), style=shrink) 
                    wsCon.write(row, 1, content[i][1]+"\u00A0", style=shrink) 
                    wsCon.write(row, 2, content[i][2]+"\u00A0", style=shrink)
                    wsCon.write(row, 3, content[i][3]+"\u00A0", style=shrink)
                    row+=1
                for i in range(4): wsCon.col(i).width = 7000
        
        # S-13    
        ws3=[]
        terCount=index=0
        for subpage in range(totalPages+1):
            x=subpage+1
            if terCount>=len(root.db): break                                    # ters ended, don't create new subpage
            elif onlyS13==False: ws3.append(wb.add_sheet("S-13 (%d)" % x))
            else: ws3.append(wb.add_sheet("%d" % x))
            start=subpage*terPerPage
            end=start+terPerPage
            column=0
            s13Count=5
            for index in range(start, end):
                if index==len(root.db): break
                elif root.db[index].getDelta2()<365 and onlyS13==False: asterisk="*"
                else: asterisk="\u00A0"
                row=0
                if onlyS13==True:
                    if s13Count%5==0:
                        ws3[subpage].write(0,column, root.msg[233], style=big)                    
                        row+=1            
                        ws3[subpage].write(row,  column+4, root.msg[234], style=bold)
                        ws3[subpage].write(row,  column+6, root.msg[235], style=smallR)                     
                        ws3[subpage].write(row,  column+7, root.msg[236], style=borderTL)
                        ws3[subpage].write(row,  column+8, "", style=borderTR)
                        ws3[subpage].write(row+1,column+7, "07.11.96\u00A0", style=borderBL)
                        ws3[subpage].write(row+1,column+8, "08.03.97\u00A0", style=borderBR)                    
                        ws3[subpage].write(row+1,column+6, root.msg[237], style=smallR)                    
                        ws3[subpage].write(row+1,column+9, root.msg[238], style=small)              
                        row+=2                    
                    else:
                        ws3[subpage].write(0,column, "")
                        row+=3                
                ws3[subpage].write(row,column, root.msg[239], style=small)
                ws3[subpage].row(row).height=350
                ws3[subpage].write(row+1,column, "№ %-30s%s" % (root.db[index].number, asterisk), style=borderU)
                ws3[subpage].row(row+2).height=70
                terCount+=1
                ws3[subpage].write(row+2,column, "", style=borderB)
                ws3[subpage].write(row+2,column+1, "", style=borderB)           
                row+=3
                ws3[subpage].col(column).width = 2500
                ws3[subpage].col(column+1).width = 2500
                for work in range(len(root.db[index].works)):                   # single work            
                    ws3[subpage].write(row,column, "%d) %s" % (work+1, root.db[index].works[work][0]), style=borderTL) 
                    ws3[subpage].write(row,column+1, "", style=borderTR)
                    ws3[subpage].write(row+1,column, root.db[index].works[work][1]+"\u00A0", style=borderBL)                 
                    ws3[subpage].write(row+1,column+1, "%s\u00A0" % root.db[index].works[work][2], style=borderBR)
                    row+=2
                    
                while onlyS13==True and row < 57:                               # filling up empty fields for S-13
                    ws3[subpage].write(row,column,    "", style=borderTL) 
                    ws3[subpage].write(row,column+1,  "", style=borderTR)
                    ws3[subpage].write(row+1,column,  "", style=borderBL) 
                    ws3[subpage].write(row+1,column+1,"", style=borderBR)                
                    row+=2                
                
                if   root.msg[0]=="ru": s13Code="S-13-U"
                elif root.msg[0]=="de": s13Code="S-13-X"
                elif root.msg[0]=="en": s13Code="S-13-E"
                else: s13Code="S-13"
                if onlyS13==True and s13Count%5==0: ws3[subpage].write(row,column, s13Code, style=small) 
                column+=2
                s13Count+=1
        
        if onlyS13==False:
            ftypes = [(root.msg[240], ".xls")]
            filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile=root.msg[169]+".xls", defaultextension='.xls')
        else:
            filename="S-13.xls"
            emptyWorks = 5-(len(root.db) % 5)                                   # draw empty works to fill page (by 5)                
            for c in range(emptyWorks):                
                if emptyWorks==5: break
                row=6
                for w in range(26):                                      
                    ws3[subpage].write(row,column, "", style=borderTL) 
                    ws3[subpage].write(row,column+1, "", style=borderTR)
                    ws3[subpage].write(row+1,column, "", style=borderBL)                 
                    ws3[subpage].write(row+1,column+1, "", style=borderBR)
                    row+=2
                column+=2
            
        if filename!="":
            try: wb.save(filename)
            except:
                status=False
                mb.showerror(root.msg[1], root.msg[241] % filename)
                print("export error")
                root.log(root.msg[242] % filename)
                root.updateLog()
            else:
                print("export successful")
                if onlyS13==False:
                    root.log(root.msg[243] % filename)
                    if mb.askyesno(root.msg[244], root.msg[245])==True: webbrowser.open(filename)
                else: root.log(root.msg[246] % filename)
                root.updateLog()
        return filename, status
    
def importXLS(root, form=None):
    dialog=tk.Toplevel()
    dialog.title(root.msg[247])
    dialog.tk.call('wm', 'iconphoto', dialog._w, root.img[75])
    dialog.grab_set()
    dialog.focus_force()
    frame=ttk.Frame(dialog)
    frame.pack(side="top")
    tk.Message(frame, text=root.msg[248], justify="left", width=400).grid(column=0,row=0,padx=5, pady=5, sticky="wn")
    tk.Message(frame, text=root.msg[249], justify="left", width=400).grid(column=1,row=0,padx=5, pady=5, sticky="en")
    if   root.msg[0]=="ru": sampleImage=root.img[1]
    elif root.msg[0]=="de": sampleImage=root.img[81]
    #elif root.msg[0]=="en": sampleImage=root.img[83]
    else: sampleImage=root.img[83]                                              
    sample=ttk.Label(dialog, image=sampleImage, cursor="hand2")
    sample.pack(side="top", padx=5, pady=5)    
    sample.bind("<1>", lambda x: webbrowser.open("sample_%s.xls" % root.msg[0]))
    CreateToolTip(sample, "sample_%s.xls" % root.msg[0])
    x = (dialog.winfo_screenwidth()/2)-420
    y = (dialog.winfo_screenheight()/4)
    dialog.geometry('+%d+%d' % (x, y))   
    def format(value):
        value=(str(value)).strip()
        if ".0" in value: value=value[ : value.index(".0")]
        return value    
    def generate():
        ftypes = [(root.msg[240], ".xls")]
        filename=filedialog.askopenfilename(filetypes=ftypes, defaultextension='.xls')
        if filename!="":
            try: book = xlrd.open_workbook(filename, formatting_info=True)
            except:
                mb.showerror(root.msg[1], root.msg[250] % filename)
                print("import error")
                root.log(root.msg[251] % filename)
                root.updateLog()
            else:
                dialog["cursor"]="watch"
                dialog.update()
                sheet = book.sheet_by_index(0)    
                for row in range(sheet.nrows):
                    if sheet.ncols>=1: number=format(sheet.cell(row,0).value)
                    else: number=""
                    if sheet.ncols>=2: type=format(sheet.cell(row,1).value)
                    else: type=""
                    if sheet.ncols>=3: address=format(sheet.cell(row,2).value)
                    else: address=""
                    if sheet.ncols>=4: note=format(sheet.cell(row,3).value)
                    else: note=""
                    if sheet.ncols>=5: map=format(sheet.cell(row,4).value)
                    else: image=""
                    if sheet.ncols>=6: image=format(sheet.cell(row,5).value)
                    else: map=""
                    work=[]
                    if sheet.ncols>=7:
                        if str(sheet.cell(row,6).value).strip()=="" and str(sheet.cell(row,7).value).strip()=="" and str(sheet.cell(row,8).value).strip()=="": pass
                        else:                                                   # publisher exists
                            if root.msg[0]=="en":                               
                                work.append([sheet.cell(row,6).value, "01/01/01", ""])
                            else:
                                work.append([sheet.cell(row,6).value, "01.01.01", ""])
                            if work[0][0]=="": work[0][0]="?"
                            if sheet.ncols>=8:
                                if d.verifyDate(root, str(sheet.cell(row,7).value).strip(), silent=True)==True:
                                    work[0][1] = str(sheet.cell(row,7).value).strip()                                    
                                else:
                                    work[0][1] = d.convertBack(root, (cell_display(sheet.cell(row,7),book.datemode))[6:16])
                            if sheet.ncols>=9:
                                if str(sheet.cell(row,8).value).strip()=="": pass
                                elif d.verifyDate(root, str(sheet.cell(row,8).value).strip(), silent=True)==True:
                                    work[0][2]= str(sheet.cell(row,8).value).strip()
                                else:
                                    work[0][2] = d.convertBack(root, (cell_display(sheet.cell(row,8),book.datemode))[6:16])
                    root.newTer(number=number, type=type, address=address, note=note, image=image, map=map, work=work, silent=True)
                    root.log(root.msg[252] % (number, address, filename))
                    print("import successful")
                dialog["cursor"]="arrow"
                dialog.destroy()
                root.save()
                root.updateLog()
    ttk.Button(dialog, text=root.msg[253], style="big.TButton", image=root.img[2], compound="left", command=generate).pack(side="bottom", padx=5, pady=5, ipadx=5, ipady=5)
    def quit(event): dialog.destroy()
    dialog.bind("<Escape>", quit)
    if form!=None: form.destroy()
    
def getFonts(root):
    """Download fonts from GitHub"""
    def _runLoad(threadName, delay):
        progress=Progress(root.msg[254])
        try: urllib.request.urlretrieve("http://github.com/antorix/Halieus/raw/master/fonts.zip", "fonts.zip")
        except: print("download failed")
        else: print("download complete")                    
        try:
            zip=zipfile.ZipFile("fonts.zip", "r")
            zip.extractall("fonts")
            zip.close()
            os.remove("fonts.zip")
        except:
            progress.form.destroy()
            print("unpacking failed")
            mb.showerror(root.msg[1], root.msg[255])
        else:
            progress.form.destroy()
            print("unpacking complete")
            mb.showinfo(root.msg[256], root.msg[257])    
            webbrowser.open("fonts")
    try: _thread.start_new_thread(_runLoad,("Thread-LoadFonts", 1,))
    except: print("can't run thread")

def exportPDF(root):
    if len(root.db)==0:
        mb.showinfo(root.msg[244], root.msg[258])
        return
    dialog = tk.Toplevel()
    dialog.title(root.msg[30])
    dialog.tk.call('wm', 'iconphoto', dialog._w, root.img[74])
    dialog.grab_set()
    dialog.focus_force()
    x = (dialog.winfo_screenwidth()/2)-265
    y = (dialog.winfo_screenheight()/3)
    dialog.geometry('+%d+%d' % (x, y))
    dialog.grid_columnconfigure (0, weight=1)
    dialog.grid_rowconfigure (9, weight=1)
    padx=pady=root.padx
    tk.Message(dialog, text=root.msg[259], width=500).grid(column=0, columnspan=2, row=0, padx=padx, pady=pady, sticky="wen")
    tk.Message(dialog, width=300, text=root.msg[260]).grid(column=0, row=1, padx=padx, pady=pady, sticky="w")
    if root.msg[0]=="en": link = "https://www.libreoffice.org/download/libreoffice-still/"
    else: link = "https://%s.libreoffice.org/download/" % root.msg[0]
    ttk.Button(dialog, text=root.msg[261], command=lambda: webbrowser.open(link)).grid(column=1, row=1, padx=padx*2, pady=pady, sticky="we")
    tk.Message(dialog, width=300, text=root.msg[262]).grid(column=0, row=2, padx=padx, pady=pady, sticky="w")
    def _generate(event=None):
        filename, status = exportXLS(root, onlyS13=True)
        if status==True: webbrowser.open(filename)
    ttk.Button(dialog, text=root.msg[263], command=_generate).grid(column=1, row=2, padx=padx*2, pady=pady, sticky="we")
    tk.Message(dialog, width=300, text=root.msg[264]).grid(column=0, columnspan=1, row=3, padx=padx, pady=pady*2, sticky="w")
    open=tk.Label(dialog, image=root.img[70])
    open.grid(column=1, row=3, padx=padx*3, pady=pady*2, sticky="we")
    def _open(event=None):
        if os.path.exists("S-13.xls"): webbrowser.open("S-13.xls")
    open.bind("<1>", _open)
    dialog.bind("<Escape>", lambda x: dialog.destroy())
