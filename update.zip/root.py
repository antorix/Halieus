7#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
import pickle
import os
import datetime
from data import Ter
import data as d
import time
import webbrowser
import tkinter.messagebox as mb
import tools
import images
from time import strftime, localtime
from classes import CreateToolTip, Splash
import tkinter.scrolledtext as ScrolledText
import _thread
#import junk

class Root(tk.Frame):
    """Main interface class"""  
    
    def __init__(self):
        tk.Frame.__init__(self)
        
        # Run splash
        self.settings=d.load(self, onlySettings=True)[2]        
        self.showSplash=tk.IntVar()
        self.showSplash.set(self.settings[14])        
        if self.showSplash.get()==1: self.master.withdraw()
        self.splash=Splash(self.showSplash.get())          

        # Load database and rest of settings
        self.splash.update("Загрузка базы данных…")
        self.db=d.load(self)[1]        
        self.splash.update("Загрузка картинок…")
        self.images()
        
        # Settings
        self.splash.update("Выставление настроек…")                             
        self.prevDate=""
        self.tips="\
● Есть два способа быстро добавить много участков: массовое создание и импорт из Excel. Оба находятся в Меню → Инструменты.\n\n\
● Задерживайте мышку над кнопками и другими элементами – будут появляться полезные подсказки.\n\n\
● Сохранять и загружать данные не нужно, они автоматически загружаются при запуске программы и сохраняются при каждом изменении. Однако можно экспортировать и импортировать базу данных для переноса на другие устройства или резервирования (Меню → Файл).\n\n\
● При каждом сохранении создается резервная копия (до 3). Если что-то пошло не так, восстановите наиболее свежую копию через Меню → Файл → Восстановление.\n\n\
● Для копирования-вставки рекомендуется использовать сочетания Ctrl+Insert и Shift+Insert или контекстное меню.\n\n\
● Программа полностью автоматически, в фоновом режиме обновляет саму себя через Интернет. Вам ничего не нужно делать, при этом размер загружаемого файла составляет считанные килобайты. Это можно отключить в настройках, но настоятельно не рекомендуется.\n\n\
● К каждому участку можно прикрепить картинку, положив ее в папке программы в формате .png и прописав имя файла в карточке участка. Эту функцию можно отключить в настройках.\n\n\
● Если что-то не работает или непонятно, не стесняйтесь писать автору программы через Меню → Помощь → Поддержка. Вам обязательно помогут!\n"
        self.sortType=tk.StringVar()                                            # variables
        self.sortType.set(self.settings[0])        
        self.listGrid=tk.IntVar()
        self.autoUpdate=tk.IntVar()
        self.autoUpdate.set(self.settings[1])        
        self.listGrid.set(self.settings[2])        
        self.images=tk.IntVar()
        self.images.set(self.settings[3])       
        self.searchHistory=tk.IntVar()
        self.searchHistory.set(self.settings[4])        
        self.bottomSB=tk.IntVar()
        self.bottomSB.set(self.settings[5])
        self.lines=tk.IntVar()
        self.lines.set(self.settings[6])        
        self.fields=[]
        for i in range(8):
            self.fields.append(tk.IntVar())
            self.fields[i].set(int(self.settings[7][i]))
        self.listFont=tk.StringVar()
        self.listFont.set(self.settings[8])
        self.listFontSize=tk.StringVar()
        self.listFontSize.set(self.settings[9])
        self.doubleAddress=tk.IntVar()
        self.doubleAddress.set(self.settings[10])
        self.workedTerYear=tk.IntVar()
        self.workedTerYear.set(self.settings[11])        
        self.noteAsText=tk.IntVar()
        self.noteAsText.set(self.settings[12])
        self.insertNew=tk.IntVar()
        self.insertNew.set(self.settings[13])
        self.timeoutDays=int(self.settings[15])
        self.exactSearch=tk.IntVar()
        self.exactSearch.set(self.settings[16])
        self.searchFields = tk.StringVar()
        self.searchFields.set(self.settings[17])
        self.logLength=tk.IntVar()
        self.logLength.set(self.settings[18])
    
        # Window set up
        self.splash.update("Создание главного окна…")
        w = self.master.winfo_screenwidth()/1.8
        h = self.master.winfo_screenheight()/1.3
        ws = self.master.winfo_screenwidth()
        hs = self.master.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-50
        self.master.geometry('%dx%d+%d+%d' % (w, h, x, y))
        self.master.minsize(260,285)
        if os.name=="nt": self.master.iconbitmap(self.ico[0])
        self.master.title("Halieus")
        self.master.grid_columnconfigure (0, weight=1)
        self.master.grid_rowconfigure    (2, weight=1)
        self.master.bind("<Alt-End>", self.submitSelected)
        self.master.bind("<Control-f>", lambda x: self.search.focus_force())
        self.master.bind("<Alt-0>", lambda x: self.chosenPublisher.focus_force())
        
        # Styling
        self.padx=self.pady=3
        self.yellow="#ffff84"
        self.stripe="#e8f0ff"
        self.logColor="white"#"#f7fbff"
        self.style = ttk.Style()
        self.style.configure("new.TButton", font=('', 11))
        self.style.map('action.TButton', background=[('disabled', 'gray80')])
        self.style.configure("action.TButton", font=('', 9))
        self.style.configure("manual.TEntry", activeforeground=self.stripe)
        self.style.configure("startup.TButton", relief="raised", font=("{Arial bold}", 12), width=25, justify="center")
        self.style.configure("small.TButton",  width=7, font=('', 7))           
        self.style.configure("gear.TLabel", background="gray94", activebackground="red", highlightthickness=2, borderwidth=2, width=7)    # list settings
        self.style.configure("small2.TButton", width=10, font=('', 7))
        self.style.configure("search.TButton", highlightthickness=0, borderwidth=0, background="white")
        self.style.configure("search.TLabel", background="white")
        self.style.configure("search.TFrame", background="white")
        self.style.configure("search.TCombobox", background="white", highlightthickness=0, borderwidth=0)
        self.style.configure("search.TCheckbutton", background="white") 
        
        # Main menu
        self.menubar = tk.Menu(self.master)
        self.filemenu1 = tk.Menu(self.menubar, tearoff=0)                       # Файл
        self.menubar.add_cascade(label="Файл", menu=self.filemenu1)
        self.filemenu1.add_command(label="Импорт", image=self.img[38], compound="left", command=self.importDB) 
        self.filemenu1.add_command(label="Экспорт", image=self.img[39], compound="left", command=self.exportDB)
        self.filemenu1.add_command(label="Очистка", image=self.img[40], compound="left", command=self.clearDB)
        self.filemenu1.add_command(label="Восстановление", image=self.img[51], compound="left", command=self.restoreDB)
        self.filemenu1.add_separator()
        self.filemenu1.add_command(label="Выход", command=self.master.quit)
        self.filemenu2 = tk.Menu(self.menubar, tearoff=0)                       # Инструменты
        self.menubar.add_cascade(label="Инструменты", menu=self.filemenu2)
        self.filemenu2.add_command(label="Массовое создание участков", image=self.img[11], compound="left", command=lambda: tools.massCreate(self))
        self.filemenu2.add_command(label="Импорт участков из Excel", image=self.img[14], compound="left", command=lambda: tools.importXLS(self))
        self.filemenu2.add_command(label="Экспорт данных в Excel", image=self.img[13], compound="left", command=lambda: tools.exportXLS(self))
        self.filemenu3 = tk.Menu(self.menubar, tearoff=0)                       # Настройки
        self.menubar.add_cascade(label="Настройки", menu=self.filemenu3)
        self.filemenu3.add_checkbutton(label="Автообновление программы", variable=self.autoUpdate, command=lambda: self.saveSettings("autoUpdate"))
        self.filemenu3.add_checkbutton(label="Заставка при запуске", variable=self.showSplash, command=self.saveSettings)
        self.filemenu3.add_checkbutton(label="Картинки в участках", variable=self.images, command=self.saveSettings)
        self.filemenu3.add_checkbutton(label="Увеличенная заметка в участках", variable=self.noteAsText, command=self.saveSettings)
        self.filemenu3.add_checkbutton(label="Новый участок по Insert", variable=self.insertNew, command=self.saveSettings)
        #filemenu3.add_checkbutton(label="Обработанный за год участок должен быть выдан не раньше года назад", variable=self.workedTerYear, command=self.saveSettings)        
        self.filemenu3.add_separator()
        self.filemenu3.add_command(label="Срок обработки участка: %d дн." % self.timeoutDays, image=self.img[15], compound="left", command=lambda: self.setSetting("timeoutDays"))        
        self.filemenu3.add_command(label="Размер журнала: %d стр." % self.logLength.get(), image=self.img[65], compound="left", command=lambda: self.setSetting("logLength"))        
        self.filemenu3.add_separator()
        self.tableMenu=tk.Menu(self.menubar, tearoff=1)                         # Настройки списка участков
        self.filemenu3.add_cascade(label="Настройки списка участков", image=self.img[50], compound="left", menu=self.tableMenu)
        fontMenu=tk.Menu(self.tableMenu, tearoff=1)                             # Шрифт
        self.tableMenu.add_cascade(label="Шрифт", menu=fontMenu)
        fontMenu.add_radiobutton(label="Courier New", variable=self.listFont, value="Courier New", command=lambda: self.saveSettings("listFont"))
        fontMenu.add_radiobutton(label="Liberation Mono", variable=self.listFont, value="Liberation Mono", command=lambda: self.saveSettings("listFont"))
        fontMenu.add_radiobutton(label="Lucida Console", variable=self.listFont, value="Lucida Console", command=lambda: self.saveSettings("listFont"))
        fontSizeMenu=tk.Menu(self.tableMenu, tearoff=1)                         # Размер шрифта
        self.tableMenu.add_cascade(label="Размер шрифта", menu=fontSizeMenu)
        fontSizeMenu.add_radiobutton(label="Очень мелкий", variable=self.listFontSize, value="7", command=lambda: self.saveSettings("listFontSize"))
        fontSizeMenu.add_radiobutton(label="Мелкий", variable=self.listFontSize, value="8", command=lambda: self.saveSettings("listFontSize"))
        fontSizeMenu.add_radiobutton(label="Средний", variable=self.listFontSize, value="9", command=lambda: self.saveSettings("listFontSize"))
        fontSizeMenu.add_radiobutton(label="Крупный", variable=self.listFontSize, value="10", command=lambda: self.saveSettings("listFontSize"))
        fontSizeMenu.add_radiobutton(label="Очень крупный", variable=self.listFontSize, value="11", command=lambda: self.saveSettings("listFontSize"))
        self.tableMenu.add_checkbutton(label="Сетка", variable=self.listGrid, command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Вертикальные линии", variable=self.lines, command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Горизонтальная полоса прокрутки", variable=self.bottomSB, command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Расширенное поле адреса", variable=self.doubleAddress, command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_separator()
        self.tableMenu.add_checkbutton(label="Поле статуса", variable=self.fields[0], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Поле номера", variable=self.fields[1], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Поле типа", variable=self.fields[2], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Поле адреса", variable=self.fields[3], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Поле возвещателя", variable=self.fields[4], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Поле даты сдачи", variable=self.fields[5], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Поле числа обработок", variable=self.fields[6], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label="Поле заметки", variable=self.fields[7], command=lambda: self.saveSettings("_listSet"))
        self.filemenu4 = tk.Menu(self.menubar, tearoff=0)                       # Помощь
        self.menubar.add_cascade(label="Помощь", menu=self.filemenu4)
        self.filemenu4.add_command(label="Важно знать", image=self.img[4], compound="left", command=self.showTips)
        self.filemenu4.add_command(label="Поддержка", image=self.img[31], compound="left", command=lambda: webbrowser.open("http://halieus.blogspot.com/"))
        self.filemenu4.add_command(label="О программе", image=self.img[47], compound="left", command=self.about)
        self.master.config(menu=self.menubar)        
        self.menubar = tk.Menu(self.master)
        self.filemenu1 = tk.Menu(self.menubar, tearoff=0)                       # Файл
        self.menubar.add_cascade(label="Файл", menu=self.filemenu1)
        self.filemenu1.add_command(label="Импорт", image=self.img[38], compound="left", command=self.importDB)
        
        # Standard context menu
        self.splash.update("Компоновка интерфейса…")        
        self.conMenu = tk.Menu(self.master, tearoff=0)
        self.conMenu.add_command(label="Вырезать")
        self.conMenu.add_command(label="Копировать")
        self.conMenu.add_command(label="Вставить")
        self.conMenu.add_command(label="Удалить")
        self.conMenu.add_separator()
        self.conMenu.add_command(label="Выделить все")        
        
        # Main notebook
        self.notebook=ttk.Notebook(self.master, style="main.TNotebook")
        self.notebook.grid(column=0, row=1, columnspan=2, rowspan=4, padx=self.padx, pady=self.pady, sticky="nwes")
        self.tabList=tk.Frame(self.notebook)                                    # tab 1
        self.notebook.add(self.tabList, text="Участки", image=self.img[25], compound="left")
        self.tabList.columnconfigure(0, weight=1)
        self.tabList.rowconfigure(3, weight=1)
        self.tabReports=tk.Frame(self.notebook)                                 # tab 2
        self.notebook.add(self.tabReports, text="Расчеты", image=self.img[43], compound="left")
        self.tabReports.columnconfigure(0, weight=1)
        self.tabReports.rowconfigure(0, weight=1)
        self.tabReports.bind("<Visibility>", self.updateR)
        self.tabLog=tk.Frame(self.notebook, bg=self.logColor)                   # tab 3
        self.notebook.add(self.tabLog, text="Журнал", image=self.img[65], compound="left")
        self.tabLog.columnconfigure(0, weight=1)
        self.tabLog.rowconfigure(0, weight=1)
        self.tabLog.bind("<Visibility>", self.updateLog)
        """self.tabNotes=tk.Frame(self.notebook)                                   # tab 4
        self.notebook.add(self.tabNotes, text="Блокнот", image=self.img[67], compound="left")
        self.tabNotes.columnconfigure(0, weight=1)
        self.tabNotes.rowconfigure(0, weight=1)
        self.tabNotes.bind("<Visibility>", self.updateN)"""
        
        ttk.Separator(self.master, orient='horizontal').grid (column=0, row=5, columnspan=2, sticky='nwe')
        
        # TAB 1 (Ter list) ---------------------------------------------------------------
        
        # Search        
        self.searchBar=ttk.Frame(self.tabList, borderwidth=0, style="search.TFrame")
        self.searchBar.grid(column=0, columnspan=2, row=0, padx=self.padx, pady=0, sticky="e")
        self.searchLabel=ttk.Label(self.searchBar, text="Поиск:", style="search.TLabel")
        self.searchLabel.grid(column=3, row=0, padx=3, sticky="e")                          
        self.searchLabel.bind("<1>", lambda x: self.search.focus_force())
        self.search=tk.Entry(self.searchBar, width=20, relief="flat")#style="search.TEntry")                         
        self.search.grid(column=4, row=0, sticky="e")
        self.search.bind("<Button-3>", self.standardMenu)
        self.search.focus_force()
        self.search.bind("<Return>", self.find)
        self.searchFilter=ttk.Combobox(self.searchBar, state="readonly", style="search.TCombobox", width=19, values=["По всем полям","По номерам","По типам","По адресам","По возвещателям","По датам","По числу обработок","По заметкам"], textvariable=self.searchFields)
        CreateToolTip(self.searchFilter, "Область поиска")
        self.searchFilter.bind("<Return>", self.actSelected)        
        self.searchFilter.grid(column=5, row=0, padx=1, sticky="we")        
        self.strictSearch=ttk.Checkbutton(self.searchBar, text="Строго", variable=self.exactSearch, style="search.TCheckbutton", command=lambda: self.saveSettings("strictSearch"))
        self.strictSearch.grid(column=6,row=0,padx=1,sticky="we")        
        CreateToolTip(self.strictSearch, "Все поле должно точно соответствовать запросу")        
        self.includeHistory=ttk.Checkbutton(self.searchBar, text="Включая историю", variable=self.searchHistory, style="search.TCheckbutton", command=lambda: self.saveSettings("includeHistory"))
        self.includeHistory.grid(column=7,row=0,padx=1,sticky="we")
        CreateToolTip(self.includeHistory, "Поиск включая имена и даты из истории обработки участка")                
        self.searchButton=ttk.Button(self.searchBar, image=self.img[29], style="search.TButton", command=self.find)
        self.searchButton.grid(column=8, row=0, sticky="w")
        CreateToolTip(self.searchButton, "Найти участки")
        
        # Sorting
        self.sortFrame = ttk.Frame(self.tabList)
        self.sortFrame.grid(column=0, row=1, columnspan=2, padx=self.padx, sticky="nwe")
        self.sortFrame.columnconfigure(9, weight=1)
        self.sort=[]                                                            
        for value, image, column, tip in zip(["Статус","Номер (1)","Номер (1а)","Тип","Адрес","Возвещатель","Давность","Обработки","Заметка"], [self.img[3],self.img[22],self.img[23],self.img[26],self.img[21],self.img[17],self.img[18],self.img[5],self.img[20]], [1,2,3,4,5,6,7,8,9], ["Сортировка участков по статусу","Сортировка участков по номеру (числовая)","Сортировка участков по номеру (алфавитная)","Сортировка участков по типу","Сортировка участков по адресу","Сортировка участков по текущему возвещателю","Сортировка участков по давности последней обработки","Сортировка участков по числу обработок","Сортировка участков по заметке"]):
                self.sort.append(ttk.Radiobutton(self.sortFrame, variable=self.sortType, value=value, image=image, compound="left", text=value, command=self.setSort))
                self.sort[column-1].grid(column=column, row=1, padx=self.padx, pady=self.pady, sticky="w")
                CreateToolTip(self.sort[column-1], tip)        
        
        # Mass selection bar 
        self.massFrame=tk.Frame(self.tabList)                                        
        self.massFrame.grid(column=0, row=2, columnspan=2, sticky="wens")                                            
        self.massFrame.grid_columnconfigure(5, weight=1)        
        self.selCount=tk.Label(self.massFrame, fg="MidnightBlue")               # selection count 
        self.selCount.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="ws")
        self.massEditButton=ttk.Button(self.massFrame, text="Правка выборки", image=self.img[10], compound="left",\
            command=lambda: tools.massEdit(self))                               # mass edit
        self.massEditButton.grid(column=1, row=0, padx=3, sticky="ws")
        CreateToolTip(self.massEditButton, "Правка выбранных участков")        
        self.massStatsButton=ttk.Button(self.massFrame, text="Статистика выборки", image=self.img[24], compound="left", command=self.showMassStats) # mass (slice) statistics
        self.massStatsButton.grid(column=2, row=0, padx=3, sticky="ws")                
        CreateToolTip(self.massStatsButton, "Статистика выбранных участков")        
        self.massCopyButton=ttk.Button(self.massFrame, text="Скопировать номера", image=self.img[49], compound="left", command=self.massCopy) # mass copy
        self.massCopyButton.grid(column=3, row=0, padx=3, sticky="ws")
        CreateToolTip(self.massCopyButton, "Скопировать номера выбранных участков в буфер обмена")
        self.cancelSel=ttk.Button(self.massFrame, text="Снять выбор (Escape)", image=self.img[61], compound="left", command=self.cancelSelection) # cancel selection
        self.cancelSel.grid(column=4, row=0, padx=3, sticky="ws")
        CreateToolTip(self.cancelSel, "Снять выделение участков (Escape)")
        self.filterYear = tk.IntVar()                                           # checkbutton
        self.filterYear.set(0)
        self.yearCheckbutton=ttk.Checkbutton(self.massFrame, text="Обработано за год", variable=self.filterYear, command=self.updateL)
        self.yearCheckbutton.grid(column=6, row=0, padx=self.padx, pady=self.pady, sticky="e")                         
        CreateToolTip(self.yearCheckbutton, "Участки, обработанные за последние 365 дней")        
                
        # Manual list
        self.manualTip=tk.Label(self.massFrame, fg="MidnightBlue", text="Ручной список:")
        self.manualTip.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="ws")
        self.manualList=ttk.Entry(self.massFrame, style="manual.TEntry")
        self.manualList.grid(column=1, row=0, padx=self.padx, pady=self.pady, sticky="wse")        
        self.manualList.bind("<KeyRelease>", self.activateButtons)
        self.manualList.bind("<FocusOut>", self.activateButtons)
        self.manualList.bind("<Leave>", self.activateButtons)
        self.manualList.bind("<Return>", self.actSelected)
        self.manualList.bind("<Button-3>", self.standardMenu)
        CreateToolTip(self.manualList, "Введите через запятую номера участков, чтобы выдать или сдать их одним списком, и нажмите Enter или кнопку «Выдать/сдать»")        
        self.cliptoManual=ttk.Button(self.massFrame, style="small2.TButton", text="Из буфера")
        self.cliptoManual.grid(column=2, row=0, pady=2, sticky="ws")
        def _pasteAndActivate(event=None):
            self.manualList.event_generate("<<Paste>>")
            self.activateButtons()        
        self.cliptoManual.bind("<1>", _pasteAndActivate) 
        self.cliptoManual.bind("<Enter>", self.activateButtons)
        CreateToolTip(self.cliptoManual, "Вставить содержимое буфера обмена в строку ручного списка")
        
        # Main list
        self.list = tk.Listbox(self.tabList, activestyle="dotbox", width=50, bd=1, selectmode="extended", relief="flat")
        self.list.grid(column=0, row=3, columnspan=2, padx=self.padx, pady=self.pady, sticky="nwes")  
        self.rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=self.rightScrollbar.set)      
        self.rightScrollbar.pack(side="right", fill="y")
        self.bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
        self.list.configure(xscrollcommand=self.bottomScrollbar.set)
        self.list.bind("<Return>", self.openSelected)
        self.list.bind("<Double-1>", self.openSelected)
        self.list.bind("<<ListboxSelect>>", self.activateButtons)
        self.list.bind("<3>", self.listPopup)
        self.list.bind("<space>", self.actSelected)
        
        # Table settings button        
        self.tableMenuButton=ttk.Label(self.tabList, image=self.img[66], style="gear.TLabel")
        self.tableMenuButton.grid(column=1, row=3, padx=23, pady=5, sticky="en")                  
        self.tableMenuButton.bind("<1>", lambda event: self.tableMenu.post(event.x_root, event.y_root))
        CreateToolTip(self.tableMenuButton, "Настройки списка участков")
        
        # Main list context menu
        listbar = tk.Menu(self.list)
        self.listmenu = tk.Menu(listbar, tearoff=0)
        self.listmenu.add_command(label=" Открыть (Enter)", image=self.img[27], compound="left", command=self.openSingleTer)
        self.listmenu.add_command(label=" Выдать/сдать (Пробел)", image=self.img[64], compound="left", command=self.actSelected)
        self.listmenu.add_command(label=" Правка выборки", image=self.img[10], compound="left", command=lambda: tools.massEdit(self))
        self.listmenu.add_command(label=" Статистика выборки", image=self.img[24], compound="left", command=self.showMassStats)
        self.listmenu.add_command(label=" Скопировать номера", image=self.img[49], compound="left", command=self.massCopy)        
        self.listmenu.add_command(label=" Снять выбор (Escape)", image=self.img[61], compound="left", command=self.cancelSelection)        
        self.listmenu.add_command(label=" Удалить (Delete)", image=self.img[28], compound="left", command=self.deleteSelected)
        listbar.add_cascade(label="Действия", menu=self.listmenu)
        self.list.bind("<Delete>", self.deleteSelected)
        self.list.bind("<BackSpace>", self.deleteSelected)
        
        # Operations
        self.statsMass=ttk.LabelFrame(self.tabList, text="Действия")
        self.statsMass.grid(column=0, row=4, columnspan=4, padx=self.padx, pady=self.pady, sticky="wns")           
        self.buttonAction = ttk.Button(self.statsMass, text="Выдать/сдать", style="action.TButton", image=self.img[63], compound="left", command=self.actSelected) # buttons
        self.buttonAction.grid(column=0, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")
        CreateToolTip(self.buttonAction, "Выдать либо сдать участок (участки) с учетом выбранной даты и возвещателя (Space)")
        self.statsMass.columnconfigure(0, weight=1)
        ttk.Separator(self.statsMass, orient='vertical').grid(column=3, row=0, rowspan=2, padx=self.padx*2, pady=self.pady, sticky='ens')       
        ttk.Label(self.statsMass, image=self.img[17], compound="left", text="Возвещатель")  .grid(column=4, row=0, padx=self.padx, pady=self.pady*0, sticky="ws")
        ttk.Label(self.statsMass, image=self.img[19], compound="left", text="Дата")         .grid(column=5, row=0, padx=self.padx, pady=self.pady*0, columnspan=2, sticky="ws")
        self.pubInBox = tk.StringVar()
        self.chosenPublisher=ttk.Combobox(self.statsMass, height=50, textvariable=self.pubInBox) # publisher combobox
        self.chosenPublisher.bind("<Return>", self.actSelected)        
        self.chosenPublisher.grid(column=4, row=1, padx=self.padx, pady=self.pady, sticky="wn")
        self.chosenPublisher.bind("<3>", self.standardMenu)
        CreateToolTip(self.chosenPublisher, "Имя возвещателя для выдачи участка. Из списка исключаются возвещатели, не имеющие участков более года. При необходимости их можно добавить снова")        
        self.chosenDate=ttk.Entry(self.statsMass, width=8)        
        self.chosenDate.grid(column=5, row=1, padx=self.padx, pady=self.pady, sticky="wn")
        self.chosenDate.bind("<FocusOut>", self.checkDate)        
        self.chosenDate.bind("<Button-3>", self.standardMenu)
        CreateToolTip(self.chosenDate, "Дата для операций выдачи и сдачи участков")
        ttk.Button(self.statsMass, text="Сегодня", style="small.TButton", command=self.insertDate).grid(column=6, row=1, padx=0, pady=self.pady, sticky="wn")
        self.newTerButton=ttk.Button(self.tabList, text="Новый участок", compound="left", style='new.TButton', image=self.img[0], command=self.newTer)
        self.newTerButton.grid(column=1, row=4, padx=self.padx, pady=self.pady, ipadx=10, sticky="ens")
        CreateToolTip(self.newTerButton, "Создать новый участок (Insert)")
        
        # TAB 2 (Reports) -----------------------------------------------------------------
        
        # Frame configuration
        self.frameReports=tk.Frame(self.tabReports)
        self.frameReports.grid(column=0,row=0,padx=self.padx, pady=self.pady, sticky="nesw")
        self.frameReports.columnconfigure(0, weight=5)
        self.frameReports.columnconfigure(1, weight=5)
        self.frameReports.rowconfigure(0, weight=2)
        self.frameReports.rowconfigure(1, weight=3)        
        
        self.subframe1=tk.Frame(self.frameReports, bg="white")                  # statistics [0,0]
        self.subframe1.grid(column=0,columnspan=2,row=0,rowspan=2,sticky="nesw")
        self.subframe1.rowconfigure(0, weight=1)
        self.subframe1.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe1, text=" Статистика", image=self.img[24], font="Tahoma 10 bold", compound="left").pack(fill="both")
        self.statsFrame=tk.Frame(self.subframe1, bg="white")
        self.statsFrame.pack(fill="both",padx=self.padx, pady=self.pady)        
        self.stat=[]
        for i, img in zip([0,1,2,3,4,5,6,7], [45,3,44,15,5,32,46,41]):
            self.stat.append(tk.Label(self.statsFrame, bg="white", cursor="hand2", image=self.img[img], compound="left"))
            self.stat[i].grid(column=0, row=i, sticky="wn")     
        self.stat[7]["cursor"]="arrow"
        self.stat[0]["cursor"]="arrow"
        CreateToolTip(self.stat[0], "Все участки в базе данных")     
        self.stat[1].bind("<1>", lambda x: self.findStat("checked"))
        CreateToolTip(self.stat[1], "Участки в картотеке, т.е. сданные или не выданные (нажмите для поиска)")
        self.stat[2].bind("<1>", lambda x: self.findStat("given"))
        CreateToolTip(self.stat[2], "Участки, выданные возвещателям (нажмите для поиска)")
        self.stat[3].bind("<1>", lambda x: self.findStat("timedout"))
        self.timeoutTip=CreateToolTip(self.stat[3], "Участки, не сданные возвещателями более %d дн. (нажмите для поиска)" % self.timeoutDays)
        self.stat[4].bind("<1>", lambda x: self.findStat("workedYear"))
        CreateToolTip(self.stat[4], "Участки, обработанные (сданные) за последние 365 дней (нажмите для поиска)")
        self.stat[5].bind("<1>", lambda x: self.findStat("workedYearNot"))
        CreateToolTip(self.stat[5], "Участки, не обработанные (не сданные) за последние 365 дней (нажмите для поиска)")
        self.stat[6].bind("<1>", lambda x: self.findStat("notWorked"))  
        CreateToolTip(self.stat[6], "Участки, которые никогда не обрабатывались (нажмите для поиска)")     
        CreateToolTip(self.stat[7], "Среднее время обработки участка в месяцах")     
        self.statFootnote=tk.Label(self.statsFrame, bg="white", justify="left", text="* Все проценты – от общего\n  числа участков")
        self.statFootnote.grid(column=0, row=8, padx=self.padx, pady=self.pady, sticky="wn")
        self.copyStats=ttk.Button(self.frameReports, image=self.img[49], command=lambda: self.pasteToClipboard(form=self.master, content=self.contentFullStats))
        self.copyStats.grid(column=0,row=0,padx=2, pady=2,sticky="se")
        CreateToolTip(self.copyStats, "Скопировать в буфер обмена")
        
        self.subframe2=tk.Frame(self.frameReports, bd=0, bg="white")            # count types [1,0]
        self.subframe2.grid(column=1,row=0,sticky="nesw")
        self.subframe2.rowconfigure(1, weight=1)
        self.subframe2.columnconfigure(0, weight=1)        
        self.labelTypes=ttk.Label(self.subframe2, text=" Типы", image=self.img[48], font="Tahoma 10 bold", compound="left")
        self.labelTypes.pack(fill="x")        
        self.typeList=tk.Listbox(self.subframe2, bd=0, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.typeList, orient="vertical", command=self.typeList.yview) 
        self.typeList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")        
        self.typeList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        listbar = tk.Menu(self.list)
        self.typeMenu=tk.Menu(listbar, tearoff=0)
        self.typeMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=lambda: self.findFromReport(self.typeList, "type"))
        self.typeList.bind("<3>", lambda event: self.typeMenu.post(event.x_root, event.y_root))
        self.typeList.bind("<Return>", lambda x: self.findFromReport(self.typeList, "type"))
        self.typeList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.typeList, "type"))        
        self.copyTypes=ttk.Button(self.subframe2, image=self.img[49], command=lambda: self.pasteToClipboard(form=self.master, content=self.contentTypes))
        self.copyTypes.pack(side="right",padx=2,pady=2)
        CreateToolTip(self.copyTypes, "Скопировать в буфер обмена")
        
        self.subframe3=tk.Frame(self.frameReports, bg="white")                  # count publishers [0,1]
        self.subframe3.grid(column=0, row=1, sticky="nesw")
        self.subframe3.rowconfigure(1, weight=1)
        self.subframe3.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe3, text=" Возвещатели", image=self.img[17], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.pubList=tk.Listbox(self.subframe3, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.pubList, orient="vertical", command=self.pubList.yview) 
        self.pubList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")
        self.pubList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")    
        listbar = tk.Menu(self.list)
        self.pubMenu=tk.Menu(listbar, tearoff=0)
        self.pubMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=lambda: self.findFromReport(self.pubList, "publisher"))
        self.pubList.bind("<3>", lambda event: self.pubMenu.post(event.x_root, event.y_root))
        self.pubList.bind("<Return>", lambda x: self.findFromReport(self.pubList, "publisher"))
        self.pubList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.pubList, "publisher"))
        self.copyPubs=ttk.Button(self.subframe3, image=self.img[49], command=lambda: self.pasteToClipboard(form=self.master, content=self.contentPubs))
        self.copyPubs.pack(side="right",padx=2, pady=2,)
        CreateToolTip(self.copyPubs, "Скопировать в буфер обмена") 
        
        self.subframe4=tk.Frame(self.frameReports, bg="white")                  # count notes [1,1]
        self.subframe4.grid(column=1, row=1, sticky="nesw")
        self.subframe4.rowconfigure(1, weight=1)
        self.subframe4.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe4, text=" Заметки", image=self.img[20], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.noteList=tk.Listbox(self.subframe4, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.noteList, orient="vertical", command=self.noteList.yview) 
        self.noteList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")
        self.noteList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        listbar = tk.Menu(self.list)
        self.noteMenu=tk.Menu(listbar, tearoff=0)
        self.noteMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=lambda: self.findFromReport(self.noteList, "note"))
        self.noteList.bind("<3>", lambda event: self.noteMenu.post(event.x_root, event.y_root))
        self.noteList.bind("<Return>", lambda x: self.findFromReport(self.noteList, "note"))
        self.noteList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.noteList, "note"))
        self.copyNotes=ttk.Button(self.subframe4, image=self.img[49], command=lambda: self.pasteToClipboard(form=self.master, content=self.contentNotes))
        self.copyNotes.pack(side="right",padx=2, pady=2,)
        CreateToolTip(self.copyNotes, "Скопировать в буфер обмена")        
        #ttk.Button(self.frameReports, text="Отчет", compound="left", style='big.TButton', image=self.img[42]).grid()        
        
        # TAB 3 (Log) --------------------------------------------------------------------
        self.logWindow=ScrolledText.ScrolledText(self.tabLog, wrap="word", state="normal", bg=self.logColor, relief="flat")
        self.logWindow.grid(padx=self.padx, pady=self.pady, sticky="nesw")
        self.logWindow.bind("<Button-3>", self.standardMenu)
        
        """# TAB 4 (Notes)-------------------------------------------------------------------        
        try:
            with open("notes.txt", "r", encoding="utf=8") as notes: content=notes.read()
        except:
            print("notes not found, create blank")
            with open("notes.txt", "w", encoding="utf=8") as notes: pass
            with open("notes.txt", "r", encoding="utf=8") as notes: content=notes.read()        
        self.logNotes=ScrolledText.ScrolledText(self.tabNotes, wrap="word", relief="flat", font="{%s} 9" % self.listFont.get())
        self.logNotes.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="nesw")
        self.logNotes.insert(0.0, content)
        self.logNotes.bind("<Control-Return>", self.saveNotes)
        self.logNotes.bind("<3>", self.standardMenu)
        ttk.Button(self.tabNotes, text="Сохранить (Ctrl-Enter)", compound="left", image=self.img[42], command=self.saveNotes).grid(column=0, row=1, padx=self.padx, pady=self.pady, sticky="s")"""
        
        # --------------------------------------------------------------------------------        
        
        # Footer
        self.statusFrame=tk.Frame(self.master)
        self.statusFrame.grid(column=0, row=6, padx=3, sticky="wn")      
        self.statusFrame.rowconfigure(0, weight=1)
        self.timedoutCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[15], compound="left")
        self.timedoutCount.pack(side="left", fill="y")
        self.timedoutCount.bind("<1>", lambda x: self.findStat("timedout"))
        self.timeoutTip2=CreateToolTip(self.timedoutCount, "Участки, не сданные возвещателями более %d дн. (нажмите для поиска)" % self.timeoutDays)
        self.nonWorkedYearCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[32], compound="left")
        self.nonWorkedYearCount.pack(side="left", fill="y")
        self.nonWorkedYearCount.bind("<1>", lambda x: self.findStat("workedYearNot"))
        CreateToolTip(self.nonWorkedYearCount, "Участки, не обработанные за последние 365 дней (нажмите для поиска)")
        self.nonWorkedCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[46], compound="left")
        self.nonWorkedCount.pack(side="left", fill="y")
        self.nonWorkedCount.bind("<1>", lambda x: self.findStat("notWorked"))
        CreateToolTip(self.nonWorkedCount, "Участки, которые никогда не обрабатывались (нажмите для поиска)")
        self.medal=tk.Label(self.statusFrame, fg="gray20", image=self.img[60], compound="left")
        self.medal.pack(side="left", fill="y")
        CreateToolTip(self.medal, "Поздравляем, вы отлично справляетесь! :)")      
        self.terCount=tk.Label(self.master, fg="gray20", image=self.img[45], compound="left")
        self.terCount.grid(column=0, row=6, padx=20, sticky="e")
        CreateToolTip(self.terCount, "Всего участков в базе данных")   
        self.statusBar=tk.Label(self.master, fg="gray20")
        self.statusBar.grid(column=1, columnspan=1, row=6, sticky="e")             
        CreateToolTip(self.statusBar, "Дата и время последней модификации встроенной базы данных")
        ttk.Sizegrip(self.master).grid(column=1, row=0, rowspan=7, sticky="se")                
        
        # Prepare to launch
        self.splash.update("Отрисовка данных…")
        self.activateButtons()
        self.insertDate()        
        self.updateL()
        self.updateS()
        self.updateR()
        self.updateP()
        self.checkFirstLaunch() 
        self.splash.update("Сохранение настроек…")
        self.saveSettings()
        
        self.splash.update("Оптимизация журнала…")
        self.cutLog()
        
        if self.autoUpdate.get()==1:
            self.splash.update("Проверка новой версии…")
            d.updateApp(self)
        self.splash.update("Поехали!")
        self.master.deiconify()
        self.splash.end()
            
    # FUNCTIONS ---------------------------------------------------------------------------
    
    def drawList(self):
        value = tuple(["%4s) %s" % (str(i+1), self.db[i].retrieve(self)) for i in range(len(self.db))])
        font  = "{%s} %s" % (self.listFont.get(), self.listFontSize.get())
        self.list.configure(listvariable=tk.StringVar(value=value), font=font)
        if self.bottomSB.get()==1: self.bottomScrollbar.pack(side="bottom", fill="x")
        else: self.bottomScrollbar.pack_forget()        
        for i in range(len(self.db)):
            if i % 2 == 0: self.list.itemconfig(i,                  bg="white") # 2 bg colors for stripes
            else:
                if self.listGrid.get()==1: self.list.itemconfig(i,  bg=self.stripe)
                else: self.list.itemconfig(i,                       bg="white") 
        
    def updateL(self):
        """Redraw ter list and footer"""
        try:                                                  
            self.drawList()
            worked,nonWorked,year,given,timedout,averagesSum=self.getStats()
            if timedout!=0:
                self.timedoutCount.pack(side="left", fill="y")
                self.timedoutCount["text"]=str(timedout)+" "
            else: self.timedoutCount.pack_forget()        
            if (len(self.db)-year)!=0:
                self.nonWorkedYearCount.pack(side="left", fill="y")            
                self.nonWorkedYearCount["text"]=str(len(self.db)-year)+" "
            else: self.nonWorkedYearCount.pack_forget()        
            if nonWorked!=0:
                self.nonWorkedCount.pack(side="left", fill="y")
                self.nonWorkedCount["text"]=str(nonWorked)+" "
            else: self.nonWorkedCount.pack_forget()        
            if timedout!=0 or (len(self.db)-year)!=0 or nonWorked!=0:
                self.medal.pack_forget()        
            else: self.medal.pack()        
            self.terCount["text"]=str(len(self.db))+" "
            try: self.statusBar["text"] = "База изменена %s      " % datetime.datetime.fromtimestamp(os.path.getmtime("core.hal")) # last core save            
            except: pass
        except:
            del self.db[:]
            self.updateL()        
            mb.showerror("Ошибка", "Неизвестная ошибка базы данных. Попробуйте восстановить резервную копию или импортировать другую базу.")
    
    def updateS(self, sort="unchanged"):
        """Update sorting"""        
        if sort=="unchanged": sort = str(self.sortType.get())               
        if sort=="Давность": self.db.sort(key=lambda x: d.convert(x.getDateLastSubmit()), reverse=False) 
        elif sort=="Номер (1)":
            try: self.db.sort(key=lambda x: float(x.number), reverse=False) 
            except:
                mb.showwarning("Ошибка сортировки", "В номерах участков используются нецифровые символы либо пустые номера, поэтому числовая сортировка невозможна. Переключаюсь на алфавитную.")
                sort="Номер (1а)"
                self.sortType.set("Номер (1а)")
                self.settings[0]=str(self.sortType.get())
                self.saveSettings()
                self.db.sort(key=lambda x: x.number, reverse=False)                
        elif sort=="Номер (1а)": self.db.sort(key=lambda x: x.number, reverse=False) 
        elif sort=="Статус": self.db.sort(key=lambda x: x.getStatus(self), reverse=True) 
        elif sort=="Тип": self.db.sort(key=lambda x: x.type, reverse=False) 
        elif sort=="Адрес": self.db.sort(key=lambda x: x.address, reverse=False) 
        elif sort=="Возвещатель": self.db.sort(key=lambda x: x.getCurrentPublisher(), reverse=False) 
        elif sort=="Обработки": self.db.sort(key=lambda x: x.getWorks(), reverse=False) 
        elif sort=="Заметка": self.db.sort(key=lambda x: x.note, reverse=False)         
        else: self.sortType.set(None)     
        self.drawList()
        
    def updateR(self,  event=None):
        """Redraw report tab"""   
        self.fontReport="{%s} %s" % (self.listFont.get(), self.listFontSize.get())
        allStats=self.getStats()
        worked,nonWorked,year,given,timedout,averagesSum=allStats
        for i in range(8): self.stat[i]["font"]=self.fontReport
        self.stat[0]["text"] =          "%-36s %4d"   % (" Всего участков:", len(self.db))                                       
        try: self.stat[1]["text"] =     "%-36s %4d (%.1f%%)*"   % (" В картотеке:", (len(self.db)-given), (len(self.db)-given)/len(self.db)*100)       
        except: self.stat[1]["text"] =  "%-36s    0   (0.0%%)"  %  " В картотеке:"         
        try: self.stat[2]["text"] =     "%-36s %4d (%.1f%%)"    % (" На руках:", given, (given/len(self.db))*100)
        except: self.stat[2]["text"] =  "%-36s    0   (0.0%%)"  %  " На руках:"        
        try: self.stat[3]["text"] =     "%-36s %4d (%.1f%%)"    % (" Просрочено:", timedout, (timedout/len(self.db))*100)      
        except: self.stat[3]["text"] =  "%-36s    0   (0.0%%)"  %  " Просрочено:"         
        try: self.stat[4]["text"] =     "%-36s %4d (%.1f%%)"    % (" Обработано за год:", year, (year/len(self.db))*100)
        except: self.stat[4]["text"] =  "%-36s    0   (0.0%%)"  %  " Обработано за год:"        
        try: self.stat[5]["text"] =     "%-36s %4d (%.1f%%)"    % (" Не обработано за год:", len(self.db)-year, (100-(year/len(self.db))*100))      
        except: self.stat[5]["text"] =  "%-36s    0   (0.0%%)"  %  " Не обработано за год:"         
        try: self.stat[6]["text"] =     "%-36s %4d (%.1f%%)"    % (" Никогда не обрабатывалось:", nonWorked, (nonWorked/len(self.db))*100)
        except: self.stat[6]["text"] =  "%-36s    0   (0.0%%)"  %  " Никогда не обрабатывалось:"
        self.stat[7]["text"]=           "%-37s %.1f мес."    %    (" Среднее время обработки:", allStats[5]/30.5)
        self.statFootnote["font"]="{%s} %d" % (self.listFont.get(), int(self.listFontSize.get())-1)
        self.contentFullStats=self.stat[0]["text"]+"\n"+self.stat[1]["text"]+"\n"+self.stat[2]["text"]+"\n"+self.stat[3]["text"]+"\n"+self.stat[4]["text"]+"\n"+self.stat[5]["text"]+"\n"+self.stat[6]["text"]+"\n"+self.stat[7]["text"]
        
        self.types=[]                                                           # calculate other reports / types
        numbers=[]
        content=[]
        for ter in self.db: self.types.append(ter.type)
        self.types = list(set(self.types))
        self.types.sort()        
        for i in range(len(self.types)):
            numbers.append([self.types[i], 0])
            for ter in self.db: 
                if ter.type==self.types[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без типа"
            content.append("%3s) %-34s %3s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))            
        listContent=tk.StringVar(value=tuple(content))
        self.typeList.configure(font=self.fontReport, listvariable=listContent)
        self.contentTypes=""
        for i in content: self.contentTypes+=i+"\n"
        
        self.publishers=[]                                                      # publishers
        numbers=[]
        content=[]
        for ter in self.db: self.publishers.append(ter.getCurrentPublisher())
        self.publishers = list(set(self.publishers))
        self.publishers.sort()        
        for i in range(len(self.publishers)):
            numbers.append([self.publishers[i], 0])
            for ter in self.db: 
                if ter.getCurrentPublisher()==self.publishers[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без возвещателя"
            content.append("%3s) %-34s %3s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))
        listContent=tk.StringVar(value=tuple(content))
        self.pubList.configure(listvariable=listContent, font=self.fontReport)
        self.contentPubs=""
        for i in content: self.contentPubs+=i+"\n"    
        
        self.notes=[]                                                           # notes
        numbers=[]
        content=[]
        for ter in self.db: self.notes.append(ter.note)
        self.notes = list(set(self.notes))
        self.notes.sort()        
        for i in range(len(self.notes)):
            numbers.append([self.notes[i], 0])
            for ter in self.db: 
                if ter.note==self.notes[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без заметки"
            content.append("%3s) %-34s %3s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))
        listContent=tk.StringVar(value=tuple(content))
        self.noteList.configure(listvariable=listContent, font=self.fontReport)
        self.contentNotes=""
        for i in content: self.contentNotes+=i+"\n"
    
    def updateP(self):
        """Update publishers combobox"""
        self.allPublishers=[]                                                       
        for ter in self.db:
            self.allPublishers.append(ter.getCurrentPublisher())     
            for w in ter.works:
                if d.getDelta(w[2])<365: self.allPublishers.append(w[0])                       
        self.allPublishers = list(set(self.allPublishers))
        self.allPublishers.sort()
        if len(self.allPublishers)>0 and self.allPublishers[0]=="": del self.allPublishers[0]                
        self.chosenPublisher["values"]=self.allPublishers
        
    def updateLog(self, event=None):
        self.cutLog()
        try:
            with open("log.txt", "r", encoding="utf=8") as log: content=log.read()
        except:
            print("log not found, create blank")
            with open("log.txt", "a", encoding="utf=8") as log: pass
            with open("log.txt", "r", encoding="utf=8") as log: content=log.read()        
        self.logWindow.configure(state="normal")
        self.logWindow.delete(0.0, "end")
        if len(content)>0: self.logWindow.insert(0.0, content)
        else: self.logWindow.insert(0.0, "Журнал пока пуст…")
        self.logWindow.configure(state="disabled")
        self.logWindow["font"]="{%s} 9" % self.listFont.get()
        self.logWindow.see("end")        
        
    def cutLog(self):
        try:
            with open("log.txt", "r", encoding="utf=8") as log: content=log.readlines()
        except: return
        if self.logLength.get()<len(content):
            print("cutting log")
            with open("log.txt", "w", encoding="utf=8") as log:
                for line in range(self.logLength.get(), 0, -1):
                    if line<len(content): log.write( content[ len(content)-line ] )
                    else: break                    
    
    def popupForCopy(self, content, event=None):
        if content=="email": self.menuEmail.post(event.x_root, event.y_root)
        else: self.menuWeb.post(event.x_root, event.y_root)
            
    def about(self):
        about=tk.Toplevel(bg="white")
        about.wm_overrideredirect(True)
        about.focus_force()
        about.grab_set()
        w = 700
        h = 300
        x = (about.winfo_screenwidth()/2) - (w/2)
        y = (about.winfo_screenheight()/2) - (h/2)-40
        about.geometry('%dx%d+%d+%d' % (w, h, x, y))
        about.minsize(w,h)        
        frame=tk.Frame(about, bg="white")
        frame.pack(expand=True, fill="both")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(2, weight=1)
        tk.Label(frame, bd=0,image=self.img[56]).place(x=0,y=0)
        with open("Halieus.pyw", "r", encoding="utf-8") as file: content = [line.rstrip() for line in file]
        ttk.Label(frame, text="Halieus %s" % content[0][10:], font="Arial 12 bold italic").grid(column=0,row=0,padx=5,pady=5,sticky="nw")        
        menubar=tk.Menu(about)
        self.menuEmail=tk.Menu(menubar, tearoff=0)                                 
        menubar.add_cascade(label="Файл", menu=self.menuEmail)        
        self.menuEmail.add_command(label="Копировать", compound="left", command=lambda: self.pasteToClipboard(about, "antorix@gmail.com"))        
        self.menuWeb=tk.Menu(menubar, tearoff=0)                                 
        self.menubar.add_cascade(label="Файл", menu=self.menuWeb)
        self.menuWeb.add_command(label="Копировать", compound="left", command=lambda: self.pasteToClipboard(about, "http://halieus.blogspot.com/"))            
        email=tk.Label(frame, bg="white", font="Arial 9 underline", text="antorix@gmail.com", cursor="hand2", image=self.img[57], compound="left")
        email.grid(column=1, row=0, padx=self.padx*8, pady=self.pady*8, sticky="w")
        email.bind("<Button-1>", lambda x: webbrowser.open("mailto:antorix@gmail.com"))
        email.bind("<Button-3>", lambda event: self.popupForCopy("email", event))                        
        web=tk.Label(frame, bg="white", font="Arial 9 underline", text="halieus.blogspot.com", cursor="hand2", image=self.img[58], compound="left")
        web.grid(column=1, row=1, padx=self.padx*8, sticky="w")              
        web.bind("<Button-1>", lambda x: webbrowser.open("http://halieus.blogspot.com/"))
        web.bind("<Button-3>", lambda event: self.popupForCopy("web", event))              
        tk.Label(frame, fg="gray20", bg="white", font="Arial 9 italic", justify="left", text=\
"Иисус сказал им: «Идите за мной,\n\
и я сделаю вас ловцами (греч. halieus)\n\
людей» (Мк 1:17)").grid(column=1, row=2, padx=self.padx*4, pady=self.pady*2, sticky="es")
        frame2=tk.Frame(frame, bg="Teal",bd=5)
        frame2.grid(column=0,row=5,columnspan=2,sticky="wes")
        tk.Label(frame, fg="white", bg="Teal", font="Arial 7", text="Лицензия GNU GPL").grid(column=1,row=4,sticky="se")
        about.bind("<Escape>", lambda x: about.destroy())
        close=tk.Label(frame, bg="white", image=self.img[59])
        close.grid(column=1,row=0,sticky="ne")
        close.bind("<1>", lambda x: about.destroy())
        
    def showTips(self, text=None):
        if text==None: text=self.tips
        tip=tk.Toplevel(bg="white")
        tip.wm_overrideredirect(True)        
        tip.focus_force()
        tip.grab_set()
        frame=tk.Frame(tip, bg="white", relief='solid', borderwidth=1)
        frame.pack(expand=True, padx=self.padx, pady=self.pady*3, fill="both")
        frame.columnconfigure(0, weight=2)
        frame.columnconfigure(0, weight=5)
        tk.Label(frame, background="white", image=self.img[52]).grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="wens")
        tk.Label(frame, text="Важно знать", background="white", font="Arial 11 bold").grid(column=1, row=0, padx=self.padx, pady=self.pady, sticky="wns")
        tk.Message(frame, width=500, background="white", text=text).grid(column=1, row=1, padx=self.padx, pady=self.pady, sticky="e")
        x = (tip.winfo_screenwidth()/2)-300
        y = (tip.winfo_screenheight()/4.2)
        tip.geometry('+%d+%d' % (x, y))
        tip.bind("<Escape>", lambda x: tip.destroy())
        tip.bind("<3>", lambda x: tip.destroy())
        close=tk.Label(frame, bg="white", image=self.img[59])
        close.grid(column=1,row=0,sticky="ne")
        close.bind("<1>", lambda x: tip.destroy())        
        tip.wait_window()
        
    def listPopup(self, event=None):
        if len(self.list.curselection())==0:
            self.listmenu.entryconfig(" Открыть (Enter)", state="disabled")
            self.listmenu.entryconfig(" Выдать/сдать (Пробел)", state="disabled")
            self.listmenu.entryconfig(" Правка выборки", state="disabled")
            self.listmenu.entryconfig(" Статистика выборки", state="disabled")
            self.listmenu.entryconfig(" Скопировать номера", state="disabled")
            self.listmenu.entryconfig(" Снять выбор (Escape)", state="disabled")
            self.listmenu.entryconfig(" Удалить (Delete)", state="disabled")
        elif len(self.list.curselection())==1:
            self.listmenu.entryconfig(" Открыть (Enter)", state="normal")
            self.listmenu.entryconfig(" Выдать/сдать (Пробел)", state="normal")
            self.listmenu.entryconfig(" Правка выборки", state="normal")
            self.listmenu.entryconfig(" Статистика выборки", state="normal")
            self.listmenu.entryconfig(" Скопировать номера", state="normal")
            self.listmenu.entryconfig(" Снять выбор (Escape)", state="normal")
            self.listmenu.entryconfig(" Удалить (Delete)", state="normal")
        else:
            self.listmenu.entryconfig(" Открыть (Enter)", state="disabled")
            self.listmenu.entryconfig(" Выдать/сдать (Пробел)", state="normal")
            self.listmenu.entryconfig(" Удалить (Delete)", state="normal")
        self.listmenu.post(event.x_root, event.y_root)
    
    def saveSettings(self, variable=None):
        fields=""
        for i in range(8): fields+=str(self.fields[i].get())        
        with open("settings.ini", "w", encoding="utf-8") as file:
            file.write( "Sort type="    + str(self.sortType.get())  +"\n"+\
                        "Auto update="  + str(self.autoUpdate.get())+"\n"+\
                        "List grid="    + str(self.listGrid.get())  +"\n"+\
                        "Images in cards="+ str(self.images.get())  +"\n"+\
                        "Search in history="   + str(self.searchHistory.get()) +"\n"+\
                        "Bottom scrollbar="+ str(self.bottomSB.get())+"\n"+\
                        "Lines in grid="+ str(self.lines.get())     +"\n"+\
                        "Table fields=" + fields                    +"\n"+\
                        "List font="    + self.listFont.get()       +"\n"+\
                        "List font size="+ self.listFontSize.get()  +"\n"+\
                        "Double address="+ str(self.doubleAddress.get())+"\n"+\
                        "Worked ter given within year="+ str(self.workedTerYear.get())+"\n"+\
                        "Note as text="+ str(self.noteAsText.get()) +"\n"+\
                        "Create new on Insert="+ str(self.insertNew.get())+"\n"+\
                        "Show splash="+ str(self.showSplash.get())  +"\n"+\
                        "Timeout days="+ str(self.timeoutDays)      +"\n"+\
                        "Exact search="+ str(self.exactSearch.get())+"\n"+\
                        "Search range="+ str(self.searchFields.get())+"\n"+\
                        "Log length="+str(self.logLength.get())
            )
        if self.insertNew.get()==1: self.master.bind("<Insert>", self.newTer)
        else: self.master.unbind("<Insert>")        
        
        if variable=="listFontSize" or variable=="listFont":
            self.list.destroy()
            self.list = tk.Listbox(self.tabList, activestyle="dotbox", width=50, bd=1, selectmode="extended", relief="sunken")
            self.list.grid(column=0, row=3, columnspan=2, padx=self.padx, pady=self.pady, sticky="nwes")  
            self.rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
            self.list.configure(yscrollcommand=self.rightScrollbar.set)      
            self.rightScrollbar.pack(side="right", fill="y")
            self.bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
            self.list.configure(xscrollcommand=self.bottomScrollbar.set)
            self.list.bind("<Return>", self.openSelected)        
            self.list.bind("<Double-1>", self.openSelected)
            self.list.bind("<<ListboxSelect>>", self.activateButtons)
            self.list.bind("<3>", self.listPopup)
            self.list.bind("<space>", self.listPopup)
            self.drawList()
            self.logWindow["font"]="{%s} 9" % self.listFont.get()
        elif variable=="_listSet": self.drawList()
        elif variable=="autoUpdate" and self.autoUpdate.get()==1: d.updateApp(self)        

    def save(self, filename=False, export=False):
        self.filename=filename
        self.export=export
        def _runSave(threadName, delay):
            if self.export==False:
                try: os.remove("backup3.hal")
                except: print("can't delete backup3")
                try: os.rename("backup2.hal", "backup3.hal")
                except: print("can't rename backup2 to backup3")
                try: os.rename("backup1.hal", "backup2.hal")
                except: print("can't rename backup1 to backup2")
                try: os.rename("core.hal", "backup1.hal")
                except: print("can't rename core to backup1")
            if self.filename==False: self.filename="core.hal"                                 
            with open(self.filename, "wb") as file:
                try: pickle.dump(self.db, file) 
                except:
                    print("can't save core!")
                    mb.showerror("Ошибка", "Неизвестная ошибка сохранения. Попробуйте повторить изменение.")
                    self.log("Ошибка сохранения.")
        try: _thread.start_new_thread(_runSave,("Thread-Save", 1,))
        except: print("can't run thread")            
        else: self.updateL()
        
    def saveNotes(self, event=None):
        with open("notes.txt", "w", encoding="utf=8") as file: file.write(self.logNotes.get(1.0, "end"))

    def importDB(self, filename=None, backup=False):
        ftypes = [('База данных Halieus (*.hal)', '.hal')]
        if filename==None: filename = filedialog.askopenfilename(filetypes=ftypes, defaultextension='.hal')
        if filename!="":
            print("import attempt…")          
            load=d.load(self, filename)
            if load[0]==True:
                self.db=load[1]
                self.save()
                self.updateR()
                self.updateP()
                self.updateS()
                print("import of %s successful, set acquired array as core" % filename)
                self.log("База данных импортирована из файла %s." % filename)
                self.cancelSelection()
            elif backup==False:
                self.log("Ошибка импорта файла %s." % filename)
                mb.showerror("Ошибка", "Импорт файла %s не удался! Файл испорчен или имеет неправильный формат." % filename)                
            else:
                print("restore error")
                return False                                                    # backup restore attempt failed                
            self.updateLog()
        
    def exportDB(self):
        ftypes = [('База данных Halieus (*.hal)', '.hal')]
        filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile='Территория собрания.hal', defaultextension='.hal')
        if filename!="":
            try: self.save(filename=filename, export=True)                
            except: mb.showerror("Ошибка", "Экспорт не удался!")
            else:
                mb.showinfo("Экспорт", "Экспорт базы данных в файл %s выполнен успешно." % filename)
                self.log("База данных экспортирована в файл %s." % filename)
                self.updateLog()
        
    def clearDB(self):
        if mb.askyesno("Очистка", "Вы уверены, что хотите безвозвратно удалить все участки?")==True:
            self.deleteSelected(all=True)                              
            self.cancelSelection()
        
    def restoreDB(self):
        if mb.askyesno("Восстановление", "Восстановить базу данных из наиболее свежей имеющейся резервной копии?")==True:
            if self.importDB(filename="backup1.hal", backup=True)==False:
                print("backup1 not found")
                if self.importDB(filename="backup2.hal", backup=True)==False:
                    print("backup2 not found")
                    if self.importDB(filename="backup3.hal", backup=True)==False:
                        print("backup3 not found")
                        mb.showwarning("Восстановление", "К сожалению, резервные копии не найдены.")
                        
    def log(self, text):
        date = strftime("%d.%m", localtime()) + "." + str(int(strftime("%Y", localtime()))-2000)
        time = strftime("%H:%M:%S", localtime())
        with open("log.txt", "a", encoding="utf-8") as log: log.write("%s %s: %s\n" % (date, time, text))
    
    def newTer(self, event=None, number="", type="", address="", note="", map="", image="", work=[], silent=False): 
        self.db.append(Ter(number=number, type=type, address=address, note=note, map=map, image=image, work=work))      
        if silent==False: self.db[len(self.db)-1].show(self, new=True)          # if true, it is mass generation
            
    def checkDate(self, event):
        if d.verifyDate(self.chosenDate.get())==False:
            self.chosenDate.delete(0, "end")
            self.chosenDate.insert(0, self.prevDate)
        else:
            self.prevDate=self.chosenDate.get()            

    def find(self, event=None, query=None):
        if query==None: query=self.search.get().strip()
        if query=="": return
        count=0
        for i in range(len(self.db)):
            if self.searchFields.get()=="По всем полям":
                if self.exactSearch.get()==0:
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query in w[0]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                            elif query in w[1]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                            elif query in w[2]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                    if query in self.db[i].number\
                    or query in self.db[i].type\
                    or query in self.db[i].address\
                    or query in self.db[i].getDate1()\
                    or query in self.db[i].getCurrentPublisher()\
                    or query in self.db[i].getDate2()\
                    or query in str(self.db[i].getWorks())\
                    or query in self.db[i].note\
                    or query in self.db[i].image\
                    or query in self.db[i].map:
                        self.db.insert(0, self.db.pop(i))
                        count+=1
                else:
                    if self.searchHistory.get()==1:                    
                        for w in self.db[i].works:
                            if query==w[0]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                            elif query==w[1]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                            elif query==w[2]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                    if query==self.db[i].number\
                    or query==self.db[i].type\
                    or query==self.db[i].address\
                    or query==self.db[i].getDate1()\
                    or query==self.db[i].getCurrentPublisher()\
                    or query==self.db[i].getDate2()\
                    or query==str(self.db[i].getWorks())\
                    or query==self.db[i].note\
                    or query==self.db[i].image\
                    or query==self.db[i].map:
                        self.db.insert(0, self.db.pop(i))
                        count+=1 
            elif self.searchFields.get()=="По номерам":
                if self.exactSearch.get()==0 and query in self.db[i].number: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].number: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
            elif self.searchFields.get()=="По типам":
                if self.exactSearch.get()==0 and query in self.db[i].type: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].type: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
            elif self.searchFields.get()=="По адресам":
                if self.exactSearch.get()==0 and query in self.db[i].address: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].address: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1           
            elif self.searchFields.get()=="По возвещателям":                
                if self.exactSearch.get()==0:
                    if query in self.db[i].getCurrentPublisher(): 
                        self.db.insert(0, self.db.pop(i))
                        count+=1
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query in w[0]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                elif self.exactSearch.get()==1:
                    if query==self.db[i].getCurrentPublisher(): 
                        self.db.insert(0, self.db.pop(i))
                        count+=1                
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query==w[0]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1             
            elif self.searchFields.get()=="По датам":                
                if self.exactSearch.get()==0:
                    if query in self.db[i].getDate1() or query in self.db[i].getDate2(): 
                        self.db.insert(0, self.db.pop(i))
                        count+=1
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query in w[1] or query in w[2]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                elif self.exactSearch.get()==1:
                    if query==self.db[i].getDate1() or query==self.db[i].getDate2(): 
                        self.db.insert(0, self.db.pop(i))
                        count+=1                
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query==w[1] or query==w[2]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1                              
            elif self.searchFields.get()=="По адресам":
                if self.exactSearch.get()==0 and query in self.db[i].address: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].address: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
            elif self.searchFields.get()=="По заметкам":
                if self.exactSearch.get()==0 and query in self.db[i].note: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].note: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
            elif self.searchFields.get()=="По числу обработок":
                if self.exactSearch.get()==0 and query in str(self.db[i].getWorks()): 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==str(self.db[i].getWorks()): 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        self.updateL()
        self.updateS(sort=None)
        self.notebook.select(self.tabList)
        self.list.yview(0)        
        if count==0: self.quickTip("Ничего не найдено")
        else: 
            self.updateS(sort=None)
            for i in range(count): self.list.itemconfig(i, bg=self.yellow)
            
    def openSingleTer(self, event=None):
        self.list.focus_force()
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
    
    def openSelected(self, event=None):
        self.list.focus_force()
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
        else: self.listPopup(event)
        
    def actSelected(self, event=None):
        """Give or submit ter(s)"""
        self.list.focus_force()
        if len(self.list.curselection())!=0:
            for i in range(len(self.list.curselection())):
                if self.db[self.list.curselection()[i]].getCurrentPublisher()=="": self.db[self.list.curselection()[i]].give(self)    
                else: self.db[self.list.curselection()[i]].submit(self)
        elif self.manualList.get().strip()!="":
            selection=self.manualList.get().strip()+","            
            start=end=0
            list=[]
            for i in range(len(selection)):
                if selection[i]==",":
                    end=i
                    list.append(selection[start:end].strip())
                    start=i+1
            else:
                count=0
                for i in range(len(list)):
                    for t in self.db:
                        if t.number==list[i]:
                            if t.getCurrentPublisher()=="": t.give(self)
                            else: t.submit(self)
                            count+=1
                if count==0: mb.showwarning("Ошибка", "Не удалось распознать номер(а).")
    
    def submitSelected(self, event=None):
        self.list.focus_force()
        if len(self.list.curselection())!=0:
            if self.chosenDate.get().strip()=="": self.chosenDate.focus_force()
            else:
                for i in range(len(self.list.curselection())): self.db[self.list.curselection()[i]].submit(self)
                
        elif self.manualList.get().strip()!="":
            selection=self.manualList.get().strip()+","            
            start=end=0
            list=[]
            for i in range(len(selection)):
                if selection[i]==",":
                    end=i
                    list.append(selection[start:end].strip())
                    start=i+1
            for i in range(len(list)):
                for t in self.db:
                    if t.number==list[i]: t.submit(self)
            
    def deleteSelected(self, event=None, all=False):
        if all==True:
            del self.db[:]
            self.save()
            self.log("База данных очищена.")
            self.updateLog()
        elif len(self.list.curselection())==0: return                
        elif len(self.list.curselection())==1:
            if mb.askyesno("Удаление", "Удалить участок %s?" % self.db[self.list.curselection()[0]].number)==True:
                self.log("Удален участок %s (%s)." % (self.db[self.list.curselection()[0]].number, self.db[self.list.curselection()[0]].address))
                del self.db[self.list.curselection()[0]]
                self.save()
                self.cancelSelection()
        else:
            if mb.askyesno("Удаление", "Удалить эти участки (%d)?" % len(self.list.curselection()))==True:
                count=0
                for i in self.list.curselection():
                    self.log("Удален участок %s (%s)." % (self.db[i-count].number, self.db[i-count].address))
                    del self.db[i-count]                    
                    count+=1
                self.save()
                self.cancelSelection()
    
    def activateButtons(self, event=None):
        #print(len(self.list.curselection()))
        if len(self.list.curselection())!=0:
            self.selCount["text"]="Выбрано %d" % len(self.list.curselection())
            self.massEditButton.grid()
            self.massStatsButton.grid()
            self.massCopyButton.grid()
            self.cancelSel.grid()
            self.manualList.grid_remove()
            self.manualTip.grid_remove()
            self.cliptoManual.grid_remove()
        else:
            self.selCount["text"]=""
            self.massEditButton.grid_remove()        
            self.massCopyButton.grid_remove()
            self.massStatsButton.grid_remove()
            self.cancelSel.grid_remove()
            self.manualList.grid()
            self.manualTip.grid()
            self.cliptoManual.grid()
        self.buttonAction.state(["!disabled"])
        if len(self.list.curselection())==0 and self.manualList.get().strip()=="":
            self.buttonAction.state(["disabled"])
            
    def cancelSelection(self, event=None):
        self.list.selection_clear(0, "end")
        self.activateButtons()
    
    def setPublisher(self):
        if len(self.allPublishers)>0: self.chosenPublisher.set(self.allPublishers[0])
        else: self.chosenPublisher.set("Иванов")
            
    def massCopy(self):
        self.master.clipboard_clear()
        for i in range(len(self.list.curselection())): self.master.clipboard_append("%s, " % self.db[self.list.curselection()[i]].number)               
        self.quickTip("Номера участков в буфере")
    
    def setSort(self):
        self.updateS(sort=str(self.sortType.get()))
        self.saveSettings()
        
    def insertDate(self):
        self.chosenDate.delete(0, "end")
        self.chosenDate.insert(0, time.strftime("%d.%m", time.localtime()) + "." + str(int(time.strftime("%Y", time.localtime()))-2000))
        self.prevDate=self.chosenDate.get()
        
    def findFromReport(self, list, object, event=None):
        count=0
        if object=="type":
            query=self.types[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].type:
                    self.db.insert(0, self.db.pop(i))
                    count+=1   
        elif object=="publisher":
            query=self.publishers[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].getCurrentPublisher():
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        else:
            query=self.notes[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].note:
                    self.db.insert(0, self.db.pop(i))
                    count+=1      
        self.updateL()
        self.updateS(sort=None)
        for i in range(count): self.list.itemconfig(i, bg=self.yellow)
        self.notebook.select(self.tabList)
        self.list.yview(0)

    def findStat(self, type, event=None):
        """ Functions to find stats from the stat list """
        count=0
        if type=="checked":
            for i in range(len(self.db)):
                if self.db[i].getStatus(self)==0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="given":
            for i in range(len(self.db)):
                if self.db[i].getStatus(self)!=0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="timedout":
            for i in range(len(self.db)):
                if self.db[i].getStatus(self)==2:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="workedYear":
            for i in range(len(self.db)):
                if self.db[i].getDelta2()<365:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="workedYearNot":
            for i in range(len(self.db)):
                if self.db[i].getDelta2()>=365:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="notWorked":
            for i in range(len(self.db)):
                if self.db[i].getWorks()==0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        else: return
        self.updateL()
        self.updateS(sort=None)
        self.notebook.select(self.tabList)
        for i in range(count): self.list.itemconfig(i, bg=self.yellow)
        self.list.yview(0)    

    def getStats(self, selection=None):
        """ Return statistics of selection of ters or all database is none"""
        if selection==None: selection=list(range(0, len(self.db)))
        worked=year=given=timedout=nonWorked=0
        averages=[]          
        for i in range(len(selection)):                                         # coloring
            if self.db[selection[i]].getPublisher()!="" and self.db[selection[i]].getStatus(self)!=0: given+=1
            if self.db[selection[i]].getWorks()==0: nonWorked+=1
            if self.db[selection[i]].getStatus(self)==2: timedout+=1            # color for non-worked ters
            else: self.list.itemconfig(i,               fg="gray15")            # color for regular ters
            delta2=self.db[selection[i]].getDelta2()
            thisTerisNonWorked=0
            if delta2<365:
                if self.workedTerYear.get()==0:
                    year+=1
                    thisTerisNonWorked=1
                elif self.db[selection[i]].getDelta1()<365:
                    year+=1
                    thisTerisNonWorked=1
            if self.filterYear.get()==1 and thisTerisNonWorked==1:  self.list.itemconfig(i, bg='PaleGreen')
            averages+=self.db[selection[i]].getAverageWork()
        worked=len(selection)-nonWorked
        try: averagesSum=sum(averages)/float(len(averages))
        except: averagesSum=0.0        
        return worked,nonWorked,year,given,timedout,averagesSum

    def showMassStats(self):        
        form=tk.Toplevel(bg="white")
        form.title("Статистика выборки (%d)" % len(self.list.curselection()))
        form.minsize(300,0)
        if os.name=="nt": form.iconbitmap(self.ico[5])
        form.focus_force()
        form.grid_columnconfigure (1, weight=1)
        form.bind("<Escape>", lambda x: form.destroy())
        padx=pady=1
        frame=tk.Frame(form, bg="white")                
        frame.pack(expand=True)
        frame.columnconfigure(0, weight=1)        
        form.columnconfigure(0, weight=1)        
        form.rowconfigure(0, weight=1)        
        stat=[]        
        for i, img in zip([0,1,2,3,4,5,6,7], [45,3,44,15,5,32,46,41]):
            stat.append(tk.Label(frame, bg="white", text="", image=self.img[img], compound="left"))
            stat[i].grid(column=0, row=i, padx=padx, pady=pady, sticky="w")        
        allStats=self.getStats(self.list.curselection())
        worked,nonWorked,year,given,timedout,averagesSum=allStats        
        for i in range(8): stat[i]["font"]=self.fontReport
        stat[0]["text"] =          "%-27s %4d, из них:"   % (" Участков в выборке:", len(self.list.curselection()))                                       
        try: stat[1]["text"] =     "%-27s %4d (%.1f%%)"   % (" В картотеке:", (len(self.list.curselection())-given), (len(self.list.curselection())-given)/len(self.list.curselection())*100)       
        except: stat[1]["text"] =  "%-27s    0   (0.0%%)" %  " В картотеке:"         
        try: stat[2]["text"] =     "%-27s %4d (%.1f%%)"   % (" На руках:", given, (given/len(self.list.curselection()))*100)
        except: stat[2]["text"] =  "%-27s    0   (0.0%%)" %  " На руках:"        
        try: stat[3]["text"] =     "%-27s %4d (%.1f%%)"   % (" Просрочено:", timedout, (timedout/len(self.list.curselection()))*100)      
        except: stat[3]["text"] =  "%-27s    0   (0.0%%)" %  " Просрочено:"         
        try: stat[4]["text"] =     "%-27s %4d (%.1f%%)"   % (" Обработано за год:", year, (year/len(self.list.curselection()))*100)
        except: stat[4]["text"] =  "%-27s    0   (0.0%%)" %  " Обработано за год:"        
        try: stat[5]["text"] =     "%-27s %4d (%.1f%%)"   % (" Не обработано за год:", len(self.list.curselection())-year, (100-(year/len(self.list.curselection()))*100))      
        except: stat[5]["text"] =  "%-27s    0   (0.0%%)" %  " Не обработано за год:"         
        try: stat[6]["text"] =     "%-27s %4d (%.1f%%)"   % (" Никогда не обрабатывалось:", nonWorked, (nonWorked/len(self.list.curselection()))*100)
        except: stat[6]["text"] =  "%-27s    0   (0.0%%)" %  " Никогда не обрабатывалось:"
        stat[7]["text"]=           "%-28s %.1f мес."      % (" Среднее время обработки:", allStats[5]/30.5)        
        content=stat[0]["text"]+"\n"+stat[1]["text"]+"\n"+stat[2]["text"]+"\n"+stat[3]["text"]+"\n"+stat[4]["text"]+"\n"+stat[5]["text"]+"\n"+stat[6]["text"]+"\n"+stat[7]["text"]        
        copyButton=ttk.Button(form, image=self.img[49], command=lambda: self.pasteToClipboard(form, content))
        copyButton.pack(side="right")
        CreateToolTip(copyButton, "Скопировать статистику в буфер обмена")        
        
    def standardMenu(self, e):
        self.conMenu.entryconfigure("Вырезать", command=lambda: e.widget.event_generate("<<Cut>>"))
        self.conMenu.entryconfigure("Копировать", command=lambda: e.widget.event_generate("<<Copy>>"))
        self.conMenu.entryconfigure("Вставить", command=lambda: e.widget.event_generate("<<Paste>>"))
        self.conMenu.entryconfigure("Удалить", command=lambda: e.widget.event_generate("<<Clear>>"))
        self.conMenu.entryconfigure("Выделить все", command=lambda: e.widget.event_generate("<<SelectAll>>"))              
        self.conMenu.tk.call("tk_popup", self.conMenu, e.x_root, e.y_root)
        #self.activateButtons()
        
    def quickTip(self, text, width=100, time=1000):
        """Show self-destructing notification in center of screen"""
        confirm=tk.Toplevel(bg="white")
        confirm.wm_overrideredirect(True)        
        frame=tk.Frame(confirm, bg="white", relief='solid', borderwidth=1)
        frame.pack(expand=True, fill="both")
        tk.Label(frame, text=text, background="white", highlightbackground="gray50").pack(padx=self.padx, pady=self.pady, expand=True, fill="both")
        x = (confirm.winfo_screenwidth()/2) - (width/2)
        y = (confirm.winfo_screenheight()/2.3)
        confirm.geometry('+%d+%d' % (x, y))        
        confirm.after(time, lambda: confirm.destroy())

    def pasteToClipboard(self, form, content):
        form.clipboard_clear()
        form.clipboard_append(content)
        self.quickTip("Статистика в буфере")
        
    def checkFirstLaunch(self):
        if not os.path.exists("settings.ini"):
            self.master.deiconify()
            self.showTips("Добро пожаловать в Halieus! Пожалуйста, уделите всего минуту на следующую важную информацию (вы можете вернуться к ней позже в Меню → Помощь).\n\n" + self.tips)                       
        if not os.path.exists("settings.ini") and len(self.db)==0:
            self.master.deiconify()
            color="white"
            tip=tk.Toplevel(bg=color)
            w = self.master.winfo_screenwidth()/3
            h = self.master.winfo_screenheight()/6
            ws = self.master.winfo_screenwidth()
            hs = self.master.winfo_screenheight()
            x = (ws/2) - (w/2)
            y = (hs/2) - (h/2)-50
            tip.geometry('%dx%d+%d+%d' % (w, h, x, y))            
            tip.wm_overrideredirect(True)        
            tip.focus_force()
            tip.grab_set()
            frame=tk.Frame(tip, bg=color, relief='flat')
            frame.pack(expand=True, padx=self.padx, pady=self.pady, fill="y")
            frame.rowconfigure(0,weight=1)
            frame.columnconfigure(0,weight=1)
            frame.columnconfigure(1,weight=1)            
            frame.columnconfigure(2,weight=1)           
            tk.Button(frame, image=self.img[2], width=200, compound="top", relief="groove", bd=2, justify="center", font="Tahoma 10 bold", text="Импортировать\nучастки из Excel", command=lambda: tools.importXLS(self, tip)).grid(column=0,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw")
            tk.Button(frame, image=self.img[37], width=200, compound="top", relief="groove", bd=2, justify="center", font="Tahoma 10 bold", text="Создать участки\nмассово", command=lambda: tools.massCreate(self, tip)).grid(column=1,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw")
            tk.Button(frame, image=self.img[55], width=200, compound="top", relief="groove", bd=2, justify="center", font="Tahoma 10 bold", text="Не сейчас", command=tip.destroy).grid(column=2,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw") 

    def setSetting(self, setting):
        """Interface to get various numeral settings"""
        bgColor="gray94"
        width=180
        padx=pady=5
        form=tk.Toplevel(bg=bgColor, bd=1, relief='solid', borderwidth=1)
        w=200
        h=100
        ws = form.winfo_screenwidth()
        hs = form.winfo_screenheight()
        x = (ws/2)-(w/2)
        y = (hs/2)-(h/2)-50
        form.geometry('+%d+%d' % (x, y))
        form.wm_overrideredirect(True) 
        form.grab_set()
        entry=tk.Entry(form, relief="flat")
        entry.pack(side="bottom", padx=5,pady=5, fill="x")
        entry.focus_force()
        
        if setting=="timeoutDays":
            tk.Message(form, bg=bgColor, width=width, text="Число дней, после которых участок на руках у возвещателя считается просроченным:").pack(side="top", padx=padx,pady=pady)
            entry.insert(0, self.timeoutDays)
            def _saveSetting(event=None):
                try: self.timeoutDays=int(entry.get())
                except: pass
                else: 
                    self.filemenu3.entryconfigure(6, label="Срок обработки участка: %d дн." % self.timeoutDays)
                    self.timeoutTip.rewrite("Участки, не сданные возвещателями более %d дн. (нажмите для поиска)" % self.timeoutDays)
                    self.timeoutTip2.rewrite("Участки, не сданные возвещателями более %d дн. (нажмите для поиска)" % self.timeoutDays)
                    form.destroy()
                    self.updateS()
                    self.saveSettings()
        elif setting=="logLength":
            tk.Message(form, bg=bgColor, width=width, text="Максимальный размер журнала в строках:").pack(padx=padx,pady=pady)
            entry.insert(0, self.logLength.get())
            def _saveSetting(event=None):
                try: self.logLength.set(int(entry.get()))
                except: pass
                else:
                    self.filemenu3.entryconfigure(7, label="Размер журнала: %d стр." % self.logLength.get())                    
                    form.destroy()
                    self.saveSettings()
                    self.cutLog()
                    self.updateLog()
        entry.bind("<Button-3>", self.standardMenu)
        entry.bind("<Return>", _saveSetting)
        entry.bind("<FocusOut>", _saveSetting)
        entry.bind("<Escape>", lambda x: form.destroy())
    
    # OUTSOURCED FUNCTIONS ----------------------------------------------------------------
    
    def images(self): images.images(self)
