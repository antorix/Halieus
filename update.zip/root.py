#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
import pickle
import os
import datetime
from data import Ter
import data as d
import time
import webbrowser
import tkinter.messagebox as mb
import tools
import images

class Root:    
    
    def __init__(self, parent, load):
        
        # Load database and all settings        
        self.currentVersion="1.1.0"       
        self.db=load[1]
        self.settings=load[2]
        images.images(self)        
        self.style = ttk.Style()
        self.style.configure("big.TButton", font=('', 10), color="green")
        self.prevDate=""
        self.tips="\
● Есть два способа быстро добавить много участков: массовое создание и импорт из Excel. Оба находятся в Меню → Инструменты.\n\n\
● Сохранять и загружать данные не нужно, они автоматически загружаются при запуске программы и сохраняются при каждом изменении. Однако можно экспортировать и импортировать базу данных для переноса на другие устройства или резервирования (Меню → Файл).\n\n\
● Программа автоматически создает резервную копию при каждом сохранении (файл \"backup.hal\"). Импортируйте его, если что-то пошло не так.\n\n\
● Для копирования-вставки рекомендуется использовать сочетания Ctrl+Insert и Shift+Insert.\n\n\
● Программа полностью автоматически, в фоновом режиме обновляет саму себя через Интернет. Вам ничего не нужно делать, при этом размер загружаемого файла составляет считанные килобайты. Это можно отключить в настройках, но настоятельно не рекомендуется.\n\n\
● К каждому участку можно прикрепить картинку, положив ее в папке программы в формате .png и прописав имя файла в карточке участка. Эту функцию можно отключить в настройках.\n\n\
● Иcпользуйте горячие клавиши: Insert – новый участок; Alt+Home – выдать участок; Alt+End – сдать участок; Alt+0 – ввести возвещателя.\n\n\
● Если что-то не работает или непонятно, не стесняйтесь писать автору программы через Меню → Помощь → Поддержка. Вам обязательно помогут!"

        # Variables for settings
        self.sortType=tk.StringVar()                                          
        self.sortType.set(self.settings[0])        
        self.autoUpdate=tk.IntVar()
        self.autoUpdate.set(self.settings[1])        
        self.listGrid=tk.IntVar()
        self.listGrid.set(self.settings[2])        
        self.images=tk.IntVar()
        self.images.set(self.settings[3])       
        self.searchHistory=tk.IntVar()
        self.searchHistory.set(self.settings[4])        
        self.bottomSB=tk.IntVar()
        self.bottomSB.set(self.settings[5])
        self.lines=tk.IntVar()
        self.lines.set(self.settings[6])        
        self.fields=[]
        for i in range(8):
            self.fields.append(tk.IntVar())
            self.fields[i].set(int(self.settings[7][i]))
        self.listFont=tk.StringVar()
        self.listFont.set(self.settings[8])
        self.listFontSize=tk.StringVar()
        self.listFontSize.set(self.settings[9])
        
        # Window set up         
        w = parent.winfo_screenwidth()/1.8
        h = parent.winfo_screenheight()/1.3
        ws = parent.winfo_screenwidth()
        hs = parent.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-50
        parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        parent.minsize(260,285)
        if os.name=="nt": parent.iconbitmap(self.ico[0])
        parent.title("Halieus")
        parent.grid_columnconfigure (0, weight=1)
        parent.grid_rowconfigure    (2, weight=1)
        self.padx=3
        self.pady=3
        self.stripe="#e8f0ff"        
        parent.bind("<Insert>", self.newTer)
        parent.bind("<Alt-Home>", self.giveSelected)
        parent.bind("<Alt-End>", self.submitSelected)
        parent.bind("<Control-f>", self.searchFocus)
        parent.bind("<Alt-0>", self.publisherFocus)
        
        # Main menu
        menubar = tk.Menu(parent)
        filemenu1 = tk.Menu(menubar, tearoff=0)                                 # Файл
        menubar.add_cascade(label="Файл", menu=filemenu1)
        filemenu1.add_command(label="Импорт", image=self.img[38], compound="left", command=self.importDB) 
        filemenu1.add_command(label="Экспорт", image=self.img[39], compound="left", command=self.exportDB)
        filemenu1.add_command(label="Очистка", image=self.img[40], compound="left", command=self.clearDB)
        filemenu1.add_separator()
        filemenu1.add_command(label="Выход", command=parent.quit)
        filemenu2 = tk.Menu(menubar, tearoff=0)                                 # Инструменты
        menubar.add_cascade(label="Инструменты", menu=filemenu2)
        filemenu2.add_command(label="Массовое создание участков", image=self.img[11], compound="left", command=self.massCreate)
        filemenu2.add_command(label="Импорт участков из Excel", image=self.img[14], compound="left", command=self.importXLS)
        filemenu2.add_command(label="Экспорт данных в Excel", image=self.img[13], compound="left", command=self.exportXLS)
        filemenu3 = tk.Menu(menubar, tearoff=0)                                 # Настройки
        menubar.add_cascade(label="Настройки", menu=filemenu3)
        filemenu3.add_checkbutton(label="Автообновление программы", variable=self.autoUpdate, command=self.saveSettings)
        filemenu3.add_checkbutton(label="Картинки в участках", variable=self.images, command=self.saveSettings)
        filemenu3.add_checkbutton(label="Поиск включая возвещателей в истории", variable=self.searchHistory, command=self.saveSettings)
        filemenu3.add_separator()
        tableMenu=tk.Menu(menubar, tearoff=1)                                   # Настройки списка участков
        filemenu3.add_cascade(label="Настройки списка участков", image=self.img[25], compound="left", menu=tableMenu)
        fontMenu=tk.Menu(tableMenu, tearoff=1)                                  # Шрифт
        tableMenu.add_cascade(label="Шрифт", menu=fontMenu)
        fontMenu.add_radiobutton(label="Courier New", variable=self.listFont, value="Courier New", command=self.saveSettings)
        fontMenu.add_radiobutton(label="Liberation Mono", variable=self.listFont, value="Liberation Mono", command=self.saveSettings)
        fontMenu.add_radiobutton(label="Lucida Console", variable=self.listFont, value="Lucida Console", command=self.saveSettings)
        fontSizeMenu=tk.Menu(tableMenu, tearoff=1)                              # Размер шрифта
        tableMenu.add_cascade(label="Размер шрифта", menu=fontSizeMenu)
        fontSizeMenu.add_radiobutton(label="Очень мелкий", variable=self.listFontSize, value="7", command=self.saveSettings)
        fontSizeMenu.add_radiobutton(label="Мелкий", variable=self.listFontSize, value="8", command=self.saveSettings)
        fontSizeMenu.add_radiobutton(label="Средний", variable=self.listFontSize, value="9", command=self.saveSettings)
        fontSizeMenu.add_radiobutton(label="Крупный", variable=self.listFontSize, value="10", command=self.saveSettings)
        fontSizeMenu.add_radiobutton(label="Очень крупный", variable=self.listFontSize, value="11", command=self.saveSettings)
        tableMenu.add_checkbutton(label="Сетка", variable=self.listGrid, command=self.saveSettings)
        tableMenu.add_checkbutton(label="Вертикальные линии", variable=self.lines, command=self.saveSettings)
        tableMenu.add_checkbutton(label="Горизонтальная полоса прокрутки", variable=self.bottomSB, command=self.saveSettings)
        tableMenu.add_separator()
        tableMenu.add_checkbutton(label="Поле статуса", variable=self.fields[0], command=self.saveSettings)
        tableMenu.add_checkbutton(label="Поле номера", variable=self.fields[1], command=self.saveSettings)
        tableMenu.add_checkbutton(label="Поле типа", variable=self.fields[2], command=self.saveSettings)
        tableMenu.add_checkbutton(label="Поле адреса", variable=self.fields[3], command=self.saveSettings)
        tableMenu.add_checkbutton(label="Поле возвещателя", variable=self.fields[4], command=self.saveSettings)
        tableMenu.add_checkbutton(label="Поле даты сдачи", variable=self.fields[5], command=self.saveSettings)
        tableMenu.add_checkbutton(label="Поле числа обработок", variable=self.fields[6], command=self.saveSettings)
        tableMenu.add_checkbutton(label="Поле заметки", variable=self.fields[7], command=self.saveSettings)
        filemenu4 = tk.Menu(menubar, tearoff=0)                                 # Помощь
        menubar.add_cascade(label="Помощь", menu=filemenu4)
        def __showTips(): self.showTips(self.tips, 510)
        filemenu4.add_command(label="Важно знать", image=self.img[4], compound="left", command=__showTips)
        filemenu4.add_command(label="Поддержка", image=self.img[31], compound="left", command=self.support)
        filemenu4.add_command(label="О программе", image=self.img[47], compound="left", command=self.about)
        parent.config(menu=menubar)
        
        # Search
        self.searchBar=ttk.Frame(parent)
        self.searchBar.grid(column=1, row=0, padx=self.padx)
        self.search=ttk.Entry(self.searchBar, width=30)                         
        self.search.grid(column=4, row=0, sticky="e")
        tk.Label(self.searchBar, text="Поиск", fg="gray20").grid(column=3, row=0, padx=3, sticky="e")                          
        self.search.focus_force()
        self.search.bind("<Return>", self.find)
        self.searchButton=ttk.Button(self.searchBar, image=self.img[29])
        self.searchButton.grid(column=5, row=0, sticky="w")
        self.searchButton.bind("<1>", self.find)
        
        # Main notebook
        self.notebook=ttk.Notebook(parent)
        self.notebook.grid(column=0, row=1, columnspan=2, rowspan=4, padx=self.padx*0, pady=self.pady*0, sticky="nwes")
        self.tabList=ttk.Frame(self.notebook)
        self.tabList.columnconfigure(0, weight=1)
        self.tabList.rowconfigure(2, weight=1)
        self.tabReports=ttk.Frame(self.notebook)
        self.tabReports.columnconfigure(0, weight=1)
        self.tabReports.rowconfigure(0, weight=1)
        self.notebook.add(self.tabList, text="Участки", image=self.img[25], compound="left")
        self.notebook.add(self.tabReports, text="Отчеты", image=self.img[43], compound="left")
        self.tabReports.bind("<Visibility>", self.updateR)
        
        # Mass selection bar 
        self.massFrame=ttk.Frame(self.tabList)                                        
        self.massFrame.grid(column=0, row=1, columnspan=2, sticky="we")                                            
        self.massFrame.grid_columnconfigure(4, weight=1)        
        self.selCount=tk.Label(self.massFrame, fg="MidnightBlue")               # selection count 
        self.selCount.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="ws")
        self.massEditButton=ttk.Button(self.massFrame, text="Массовая правка", image=self.img[10], compound="left",\
            command=self.massEdit)                                              # mass edit
        self.massEditButton.grid(column=1, row=0, padx=3, sticky="ws")                
        def __massCopy(): self.massCopy(parent)                                 # mass copy
        self.massCopyButton=ttk.Button(self.massFrame, text="Скопировать номера", image=self.img[49], compound="left", command=__massCopy)
        self.massCopyButton.grid(column=2, row=0, padx=3, sticky="ws")
        self.massCopyConfirm=tk.Label(self.massFrame, fg="darkgreen")
        self.massCopyConfirm.grid(column=3, row=0, padx=3, sticky="w")        
        self.filterYear = tk.IntVar()                                           # checkbuttons
        self.filterYear.set(0)
        ttk.Checkbutton(self.massFrame, text="Обработано за год   ", variable=self.filterYear, command=self.update).grid(column=5, row=0, pady=self.pady, sticky="w")                         
        self.filterWorked = tk.IntVar()
        self.filterWorked.set(0)
        ttk.Checkbutton(self.massFrame, text="Не обрабатывалось", variable=self.filterWorked, command=self.update).grid(column=6, row=0, pady=self.pady, sticky="w")        
        
        # Sorting
        self.sortFrame = ttk.Frame(self.tabList)
        self.sortFrame.grid(column=0, row=0, columnspan=2, padx=self.padx, sticky="nwe")
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Статус", image=self.img[3], compound="left", text="Статус", command=self.setSort).grid(column=0, row=0, padx=3, pady=self.pady, sticky="w")
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Номер (1)", image=self.img[22], compound="left", text="Номер (1)", command=self.setSort).grid(column=1, row=0, padx=3, pady=self.pady, sticky="w")
        self.sort1=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Номер (1а)", image=self.img[23], compound="left", text="Номер (1а)", command=self.setSort).grid(column=2, row=0, padx=3, pady=self.pady, sticky="w")
        self.sort2=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Тип", image=self.img[26], compound="left", text="Тип", command=self.setSort).grid(column=3, row=0, padx=3, pady=self.pady, sticky="w")
        self.sort3=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Адрес", image=self.img[21], compound="left", text="Адрес", command=self.setSort).grid(column=4, row=0, padx=3, pady=self.pady, sticky="w")
        self.sort4=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Возвещатель", image=self.img[17], compound="left", text="Возвещатель", command=self.setSort).grid(column=5, row=0, padx=3, pady=self.pady, sticky="w")      
        self.sort5=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Давность", image=self.img[18], compound="left", text="Давность", command=self.setSort).grid(column=6, row=0, padx=3, pady=self.pady, sticky="w")
        self.sort6=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Обработки", image=self.img[5], compound="left", text="Обработки", command=self.setSort).grid(column=7, row=0, padx=3, pady=self.pady, sticky="w")
        self.sort7=ttk.Radiobutton(self.sortFrame, variable=self.sortType, value="Заметка", image=self.img[20], compound="left", text="Заметка", command=self.setSort).grid(column=8, row=0, padx=3, pady=self.pady, sticky="w")
        
        # Main list        
        self.list = tk.Listbox(self.tabList, activestyle="dotbox", width=50, bd=1, selectmode="extended", relief="sunken")
        self.list.grid(column=0, row=2, columnspan=2, padx=self.padx, pady=self.pady, sticky="nwes")  
        self.rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=self.rightScrollbar.set)      
        self.rightScrollbar.pack(side="right", fill="y")
        self.bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
        self.list.configure(xscrollcommand=self.bottomScrollbar.set)
        #self.bottomScrollbar.pack(side="bottom", fill="x")
        self.list.bind("<Return>", self.openSelected)
        if os.name!="posix": self.list.bind("<Double-1>", self.openSelected)
        self.list.bind("<<ListboxSelect>>", self.activateButtons)
        self.list.bind("<3>", self.listPopup)
        self.list.bind("<space>", self.listPopup)
        
        # Main list context menu
        listbar = tk.Menu(self.list)
        self.listmenu = tk.Menu(listbar, tearoff=0)
        def __openSingleTer(): self.openSingleTer()        
        self.listmenu.add_command(label=" Открыть", image=self.img[27], compound="left", command=__openSingleTer)
        def __giveSelected(): self.giveSelected()        
        self.listmenu.add_command(label=" Выдать", image=self.img[9], compound="left", command=__giveSelected)
        def __submitSelected(): self.submitSelected()
        self.listmenu.add_command(label=" Сдать", image=self.img[8], compound="left", command=__submitSelected)
        self.listmenu.add_command(label=" Массовая правка", image=self.img[10], compound="left", command=self.massEdit)
        self.listmenu.add_command(label=" Скопировать номера", image=self.img[49], compound="left", command=__massCopy)
        def __deleteSelected(): self.deleteSelected()
        self.listmenu.add_command(label=" Удалить", image=self.img[28], compound="left", command=__deleteSelected)
        listbar.add_cascade(label="Действия", menu=self.listmenu)
        self.list.bind("<Delete>", self.deleteSelected)
        self.list.bind("<BackSpace>", self.deleteSelected)
        
        # Operations
        self.statsMass=ttk.LabelFrame(self.tabList, text="Действия")
        self.statsMass.grid(column=0, row=3, columnspan=4, padx=self.padx, pady=self.pady, sticky="wns")                
        self.buttonGive = ttk.Button(self.statsMass, text="Выдать", image=self.img[6], compound="left", command=__giveSelected)
        self.buttonGive.grid(column=0, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")
        self.buttonSubmit = ttk.Button(self.statsMass, text="Сдать", image=self.img[7], compound="left", command=__submitSelected)
        self.buttonSubmit.grid(column=1, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")        
        ttk.Separator(self.statsMass, orient='vertical').grid(column=3, row=0, rowspan=2, padx=self.padx*4, pady=self.pady*4, sticky='ns')       
        self.publisherLabel=tk.Label(self.statsMass, image=self.img[17], compound="left", text="Возвещатель")
        self.publisherLabel.grid(column=4, row=0, padx=self.padx*2.5, sticky="ws")
        ttk.Label(self.statsMass, image=self.img[19], compound="left", text="Дата").grid(column=5, row=0, columnspan=2, sticky="ws")        
        self.chosenPublisher=ttk.Entry(self.statsMass)
        self.chosenPublisher.grid(column=4, row=1, padx=self.padx*3, pady=5, sticky="wn")
        self.chosenPublisher.bind("<Return>", self.giveSelected)
        self.chosenPublisher.bind("<KeyRelease>", self.publisherNormal)
        self.chosenPublisher.bind("<FocusOut>", self.publisherNormal)
        self.chosenDate=ttk.Entry(self.statsMass, width=8)
        self.chosenDate.grid(column=5, row=1, pady=5, sticky="wn")
        self.chosenDate.bind("<FocusOut>", self.checkDate)                        
        style = ttk.Style()
        style.configure("small3.TButton", font=('', 7))
        ttk.Button(self.statsMass, text="Сегодня", style="small3.TButton", command=self.insertDate).grid(column=6, row=1, padx=5, pady=5, sticky="wn")
        def __newTer(): self.newTer(event=None)
        ttk.Button(self.tabList, text="Новый участок", compound="left", style='big.TButton', image=self.img[0], command=__newTer).grid(column=1, row=3, padx=self.padx*2, pady=self.pady*2, ipadx=10, ipady=10, sticky="se")        
        # Tab 2
        self.frameReports=tk.Frame(self.tabReports)
        self.frameReports.grid(column=0,row=0,padx=self.padx, pady=self.pady, sticky="nesw")
        self.frameReports.columnconfigure(0, weight=5)
        self.frameReports.columnconfigure(1, weight=5)
        self.frameReports.rowconfigure(0, weight=2)
        self.frameReports.rowconfigure(1, weight=3)        
        self.subframe1=tk.Frame(self.frameReports, bg="white")                  # statistics [0,0]
        self.subframe1.grid(column=0,row=0,columnspan=2,rowspan=2,sticky="nesw")
        self.subframe1.rowconfigure(1, weight=1)
        self.subframe1.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe1, text=" Статистика", image=self.img[24], font="Tahoma 10 bold", compound="left").pack(fill="both")
        self.statsFrame=tk.Frame(self.subframe1, bg="white")
        self.statsFrame.pack(padx=self.padx, pady=self.pady, fill="both")
        self.statsFrame.columnconfigure(1, weight=1)                
        self.stat=[]
        for i, img in zip([0,1,2,3,4,5,6,7], [45,3,44,15,5,32,46,41]):
            self.stat.append(tk.Label(self.statsFrame, bg="white", image=self.img[img], compound="left"))
            self.stat[i].grid(column=1, row=i, padx=self.padx, pady=self.pady, sticky="wn")     
        
        #ttk.Button(self.frameReports, text="Отчет", compound="left", style='big.TButton', image=self.img[42], command=self.exportXLS).grid()
        
        subframe2=tk.Frame(self.frameReports, bd=0, bg="white")                 # count types [1,0]
        subframe2.grid(column=1,row=0,sticky="nesw")
        subframe2.rowconfigure(1, weight=1)
        subframe2.columnconfigure(0, weight=1)        
        ttk.Label(subframe2, text=" Типы", image=self.img[48], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.typeList=tk.Listbox(subframe2, bd=0, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.typeList, orient="vertical", command=self.typeList.yview) 
        self.typeList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")        
        self.typeList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        listbar = tk.Menu(self.list)
        self.typeMenu=tk.Menu(listbar, tearoff=0)
        def __findType(event=None): self.findFromReport(self.typeList, "type")
        self.typeMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=__findType)
        self.typeList.bind("<3>", self.typePopup)
        self.typeList.bind("<Return>", __findType)
        self.typeList.bind("<Double-Button-1>", __findType)       
        
        
        subframe3=tk.Frame(self.frameReports, bg="white")                       # count publishers [0,1]
        subframe3.grid(column=0, row=1, sticky="nesw")
        subframe3.rowconfigure(1, weight=1)
        subframe3.columnconfigure(0, weight=1)        
        ttk.Label(subframe3, text=" Возвещатели", image=self.img[17], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.pubList=tk.Listbox(subframe3, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.pubList, orient="vertical", command=self.pubList.yview) 
        self.pubList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")
        self.pubList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        
        listbar = tk.Menu(self.list)
        self.pubMenu=tk.Menu(listbar, tearoff=0)
        def __findPublisher(event=None): self.findFromReport(self.pubList, "publisher")
        self.pubMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=__findPublisher)
        self.pubList.bind("<3>", self.pubPopup)
        self.pubList.bind("<Return>", __findPublisher)
        self.pubList.bind("<Double-Button-1>", __findPublisher)        
        subframe4=tk.Frame(self.frameReports, bg="white")                       # count notes [1,1]
        subframe4.grid(column=1, row=1, sticky="nesw")
        subframe4.rowconfigure(1, weight=1)
        subframe4.columnconfigure(0, weight=1)        
        ttk.Label(subframe4, text=" Заметки", image=self.img[20], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.noteList=tk.Listbox(subframe4, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.noteList, orient="vertical", command=self.noteList.yview) 
        self.noteList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")
        self.noteList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        listbar = tk.Menu(self.list)
        self.noteMenu=tk.Menu(listbar, tearoff=0)
        def __findNote(event=None): self.findFromReport(self.noteList, "note")
        self.noteMenu.add_command(label=" Найти", image=self.img[29], compound="left", command=__findNote)
        self.noteList.bind("<3>", self.notePopup)     
        self.noteList.bind("<Return>", __findNote)
        self.noteList.bind("<Double-Button-1>", __findNote)        
        
        # Footer
        self.statusFrame=tk.Frame(parent)
        self.statusFrame.grid(column=0, row=6, sticky="w")      
        self.terCount=tk.Label(self.statusFrame, fg="gray20", image=self.img[45], compound="left")
        self.terCount.pack(side="left", fill="y")        
        self.timedoutCount=tk.Label(self.statusFrame, fg="gray20", image=self.img[15], compound="left")
        self.timedoutCount.pack(side="left", fill="y")
        self.nonWorkedYearCount=tk.Label(self.statusFrame, fg="gray20", image=self.img[32], compound="left")
        self.nonWorkedYearCount.pack(side="left", fill="y")
        self.nonWorkedCount=tk.Label(self.statusFrame, fg="gray20", image=self.img[46], compound="left")
        self.nonWorkedCount.pack(side="left", fill="y") 
        self.statusBar=tk.Label(fg="gray20")
        self.statusBar.grid(column=1, columnspan=2, row=6, sticky="e")        
        ttk.Separator(parent, orient='horizontal').grid (column=0, row=6, columnspan=2, sticky='nwe')
        ttk.Sizegrip(parent).grid(column=1, row=0, rowspan=7, sticky="se")                
        
        # Startup operations
        self.activateButtons(None)
        self.insertDate()
        self.update()        
        self.updateR()
        if not os.path.exists("settings.ini"):
            self.showTips("Добро пожаловать в Halieus! Пожалуйста, уделите всего минуту на следующую важную информацию (вы можете вернуться к ней позже в Меню → Помощь).\n\n" + self.tips, 570)
            self.saveSettings()
        
    # FUNCTIONS ---------------------------------------------------------------------------    
    
    def support(self): webbrowser.open("http://halieus.blogspot.com/")
    def publisherNormal(self, event=None): self.publisherLabel["fg"] = "black"
    def massCreate(self): tools.massCreate(self)
    def importXLS(self): tools.importXLS(self)
    def searchFocus(self, event=None): self.search.focus_force()
    def publisherFocus(self, event=None): self.chosenPublisher.focus_force()
    def exportXLS(self): tools.exportXLS(self)
    def massEdit(self): tools.massEdit(self)    
    def typePopup(self, event=None): self.typeMenu.post(event.x_root, event.y_root)
    def pubPopup(self, event=None): self.pubMenu.post(event.x_root, event.y_root)
    def notePopup(self, event=None): self.noteMenu.post(event.x_root, event.y_root)
    
    def update(self, sort="unchanged"):
        """ Redraw ter list and update interface """
        if sort=="unchanged": sort = str(self.sortType.get())                   # sort
        if sort=="Давность": self.db.sort(key=lambda x: d.convert(x.getDateLastSubmit()), reverse=False) 
        elif sort=="Номер (1)":
            try: self.db.sort(key=lambda x: float(x.number), reverse=False) 
            except:
                mb.showwarning("Ошибка сортировки", "В номерах участков используются нецифровые символы либо пустые номера, поэтому числовая сортировка невозможна. Переключаюсь на алфавитную.")
                sort="Номер (1а)"
                self.sortType.set("Номер (1а)")
                self.settings[0]=str(self.sortType.get())
                self.saveSettings()
                self.db.sort(key=lambda x: x.number, reverse=False)                
        elif sort=="Номер (1а)": self.db.sort(key=lambda x: x.number, reverse=False) 
        elif sort=="Статус": self.db.sort(key=lambda x: x.getStatus(), reverse=True) 
        elif sort=="Тип": self.db.sort(key=lambda x: x.type, reverse=False) 
        elif sort=="Адрес": self.db.sort(key=lambda x: x.address, reverse=False) 
        elif sort=="Возвещатель": self.db.sort(key=lambda x: x.getCurrentPublisher(), reverse=False) 
        elif sort=="Обработки": self.db.sort(key=lambda x: x.getWorks(), reverse=False) 
        elif sort=="Заметка": self.db.sort(key=lambda x: x.note, reverse=False)         
        else: self.sortType.set(None)
        self.listContent = tk.StringVar(value=tuple(["%4s) %s" % (str(i+1), self.db[i].retrieve(self)) for i in range(len(self.db))])) # fill list        
        self.list.configure(listvariable=self.listContent)
        self.list["font"]="{%s} %s" % (self.listFont.get(), self.listFontSize.get())   
        self.worked=self.year=self.given=self.nonWorked=self.timedout=0         # calculate stats
        for i in range(len(self.db)):                                           # coloring
            if self.db[i].getPublisher()!="" and self.db[i].getStatus()!=0: self.given+=1
            if self.db[i].getWorks()==0: self.nonWorked+=1            
            if self.db[i].getStatus()==2: self.timedout+=1
            self.delta2=self.db[i].getDelta2()            
            if self.db[i].getWorks()<=0 and self.filterWorked.get()==1:         
                self.list.itemconfig(i,                 fg="red")               # color for non-worked ters
                self.worked+=1
            else: self.list.itemconfig(i,               fg="gray15")            # color for regular ters
            if self.delta2<365: self.year+=1
            if self.filterYear.get()==1 and self.delta2<365: self.list.itemconfig(i, bg='PaleGreen')
            elif i % 2 == 0: self.list.itemconfig(i,                bg="white") # 2 bg colors for stripes
            else:
                if self.listGrid.get()==1: self.list.itemconfig(i,  bg=self.stripe)
                else: self.list.itemconfig(i,                       bg="white")           
        if self.bottomSB.get()==1: self.bottomScrollbar.pack(side="bottom", fill="x")
        else: self.bottomScrollbar.pack_forget()        
        if self.timedout!=0:
            self.timedoutCount.pack(side="left", fill="y")
            self.timedoutCount["text"]=str(self.timedout)
        else: self.timedoutCount.pack_forget()        
        if (len(self.db)-self.year)!=0:
            self.nonWorkedYearCount.pack(side="left", fill="y")            
            self.nonWorkedYearCount["text"]=str(len(self.db)-self.year)
        else: self.nonWorkedYearCount.pack_forget()        
        if self.nonWorked!=0:
            self.nonWorkedCount.pack(side="left", fill="y")
            self.nonWorkedCount["text"]=str(self.nonWorked)
        else: self.nonWorkedCount.pack_forget()        
        try: self.statusBar["text"] = "База изменена %s        " % datetime.datetime.fromtimestamp(os.path.getmtime("core.hal")) # last core save
        except: pass
        self.terCount["text"]=str(len(self.db))
        
    def updateR(self, event=None):
        """ Redraw report tab """   
        self.fontReport="{%s} 9" % self.listFont.get()
        for i in range(8): self.stat[i]["font"]=self.fontReport
        self.stat[0]["text"] =          "%-35s %d" % (" Всего участков:", len(self.db))                                # Всего участков        
        self.stat[1]["text"] =          "%-35s %d" % (" В картотеке:", (len(self.db)-self.given))                   # В картотеке        
        try: self.stat[2]["text"] =     "%-35s %d (%.1f%%)" % (" На руках:", self.given, (self.given/len(self.db))*100) # На руках
        except: self.stat[2]["text"] =  "%-35s 0" % " На руках:"        
        self.stat[3]["text"] =          "%-35s %d" % (" Просрочено:", self.timedout)                                 # 4 Просрочено        
        try: self.stat[4]["text"] =     "%-35s %d (%.1f%%)" % (" Обработано за год:", self.year, (self.year/len(self.db))*100) # Обработано за год
        except: self.stat[4]["text"] =  "%-35s 0" % " Обработано за год:"        
        try: self.stat[5]["text"] =          "%-35s %d (%.1f%%)" % (" Не обработано за год:", len(self.db)-self.year, (100-(self.year/len(self.db))*100)) # Не обработано за год        
        except: self.stat[5]["text"] =          "%-35s 0" % " Не обработано за год:" # Не обработано за год        
        try: self.stat[6]["text"] =     "%-35s %d (%.1f%%)" % (" Не обрабатывалось:", self.nonWorked, (self.nonWorked/len(self.db))*100) # Не обрабатывалось
        except: self.stat[6]["text"] =  "%-35s 0" % " Не обрабатывалось:"
        x = d.getAverages(self) / 30.5                                                 # Среднее время обработки
        self.stat[7]["text"]=           "%-35s %.1f мес." % (" Среднее время обработки участка:", x)
        self.types=[]                                                           # calculate other reports / types
        numbers=[]
        content=[]
        for ter in self.db: self.types.append(ter.type)
        self.types = list(set(self.types))
        self.types.sort()        
        for i in range(len(self.types)):
            numbers.append([self.types[i], 0])
            for ter in self.db: 
                if ter.type==self.types[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без типа"
            content.append("%2s) %-33s %s" % (str(i+1), numbers[i][0][:33], numbers[i][1]))            
        listContent=tk.StringVar(value=tuple(content))
        self.typeList.configure(font=self.fontReport, listvariable=listContent)
        self.publishers=[]                                                      # publishers
        numbers=[]
        content=[]
        for ter in self.db: self.publishers.append(ter.getCurrentPublisher())
        self.publishers = list(set(self.publishers))
        self.publishers.sort()        
        for i in range(len(self.publishers)):
            numbers.append([self.publishers[i], 0])
            for ter in self.db: 
                if ter.getCurrentPublisher()==self.publishers[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без возвещателя"
            content.append("%2s) %-34s %s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))
        listContent=tk.StringVar(value=tuple(content))
        self.pubList.configure(listvariable=listContent, font=self.fontReport)
        self.notes=[]                                                           # notes
        numbers=[]
        content=[]
        for ter in self.db: self.notes.append(ter.note)
        self.notes = list(set(self.notes))
        self.notes.sort()        
        for i in range(len(self.notes)):
            numbers.append([self.notes[i], 0])
            for ter in self.db: 
                if ter.note==self.notes[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]="Без заметки"
            content.append("%2s) %-33s %s" % (str(i+1), numbers[i][0][:33], numbers[i][1]))
        listContent=tk.StringVar(value=tuple(content))
        self.noteList.configure(listvariable=listContent, font=self.fontReport)
    
    def about(self):
        about=tk.Toplevel(bg="white")
        about.focus_force()
        about.grab_set()
        w = 440
        h = 230
        ws = about.winfo_screenwidth()
        hs = about.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        about.geometry('%dx%d+%d+%d' % (w, h, x, y))
        about.minsize(w,h)
        about.title("О программе")
        if os.name=="nt": about.iconbitmap(self.ico[4])
        def quit(event): about.destroy()
        about.bind("<Escape>", quit)
        ttk.Label(about, image=self.img[16], background="white", borderwidth=0).grid(column=0, row=2, rowspan=6, padx=self.padx*7, pady=self.pady, sticky="")
        ttk.Label(about, text="Halieus %s" % self.currentVersion, background="white", font="Arial 11 bold").grid(column=1, row=2, padx=self.padx, pady=self.pady*5, sticky="w")
        email=tk.Label(about, background="white", font="Arial 10 underline", text="antorix@gmail.com", cursor="hand2")
        email.grid(column=1, row=3, padx=self.padx, pady=self.pady*2, sticky="w")
        def mailto(event): webbrowser.open("mailto:antorix@gmail.com")
        email.bind("<Button-1>", mailto)
        web=tk.Label(about, background="white", font="Arial 10 underline", text="halieus.blogspot.com", cursor="hand2")
        web.grid(column=1, row=4, padx=self.padx, pady=self.pady*2, sticky="w")
        def openWeb(event): webbrowser.open("http://halieus.blogspot.com/")
        web.bind("<Button-1>", openWeb)
        ttk.Label(about, background="white", font="Arial 10", text="Лицензия GNU GPL").grid(column=1, row=5, padx=self.padx, pady=self.pady*2, sticky="w")
        ttk.Label(about, background="white", font="Arial 10 italic", text=
"Иисус сказал им: «Идите за мной,\n\
и я сделаю вас ловцами (греч. halieus)\n\
людей» (Мк. 1:17)\n\n").grid(column=1, row=6, padx=self.padx, pady=self.pady*2, sticky="w")
        
    def showTips(self, text, height):
        tip=tk.Toplevel(bg="white")
        tip.focus_force()
        tip.grab_set()
        tk.Message(tip, width=390, text=text, background="white").pack(padx=self.padx*2, pady=self.pady*2, expand=True)
        w = 410
        h = height
        ws = tip.winfo_screenwidth()
        hs = tip.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        tip.geometry('%dx%d+%d+%d' % (w, h, x, y))
        tip.minsize(w,h)
        tip.title("Важно знать")
        if os.name=="nt": tip.iconbitmap(self.ico[3])
        def quit(event): tip.destroy()
        tip.bind("<Escape>", quit)
        
    def listPopup(self, event=None):
        if len(self.list.curselection())==0:
            self.listmenu.entryconfig(" Открыть", state="disabled")
            self.listmenu.entryconfig(" Выдать", state="disabled")
            self.listmenu.entryconfig(" Сдать", state="disabled")
            self.listmenu.entryconfig(" Удалить", state="disabled")
        elif len(self.list.curselection())==1:
            self.listmenu.entryconfig(" Открыть", state="normal")
            self.listmenu.entryconfig(" Выдать", state="normal")
            self.listmenu.entryconfig(" Сдать", state="normal")
            self.listmenu.entryconfig(" Удалить", state="normal")
        else:
            self.listmenu.entryconfig(" Открыть", state="disabled")
            self.listmenu.entryconfig(" Выдать", state="normal")
            self.listmenu.entryconfig(" Сдать", state="normal")
            self.listmenu.entryconfig(" Удалить", state="normal")
        self.listmenu.post(event.x_root, event.y_root)
        
    def entryPopup(self): pass
    
    def saveSettings(self):
        fields=""
        for i in range(8): fields+=str(self.fields[i].get())        
        with open("settings.ini", "w", encoding="utf-8") as file:
            file.write( "Sort type="    + str(self.sortType.get())  +"\n"+\
                        "Auto update="  + str(self.autoUpdate.get())+"\n"+\
                        "List grid="    + str(self.listGrid.get())  +"\n"+\
                        "Images in cards="+ str(self.images.get())  +"\n"+\
                        "Search in history="   + str(self.searchHistory.get()) +"\n"+\
                        "Bottom scrollbar="+ str(self.bottomSB.get())+"\n"+\
                        "Lines in grid="+ str(self.lines.get())     +"\n"+\
                        "Table fields=" + fields                    +"\n"+\
                        "List font="    + self.listFont.get()       +"\n"+\
                        "List font size="+ self.listFontSize.get()  +"\n"
            )            
        self.update()
        self.updateR()
    
    def save(self, filename=False):
        try: os.remove("backup.hal")
        except: print("can't delete backup")
        try: os.rename("core.hal", "backup.hal")
        except: print("can't rename core to backup")
        if filename==False: filename="core.hal"                                 
        with open(filename, "wb") as file: pickle.dump(self.db, file) 
        self.update()
    
    def importDB(self):
        ftypes = [('База данных Halieus (*.hal)', '.hal')]
        filename = filedialog.askopenfilename(filetypes=ftypes, defaultextension='.hal')
        if filename!="":
            load=d.load(filename)
            if load[0]==True:
                self.db=load[1]
                self.save()
                self.updateR()
            else: mb.showerror("Ошибка", "Импорт файла %s не удался! Файл испорчен или имеет неправильный формат." % filename)
                
    def exportDB(self):
            ftypes = [('База данных Halieus (*.hal)', '.hal')]
            filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile='Территория собрания.hal', defaultextension='.hal')
            if filename!="":
                try:
                    self.save(filename=filename)
                    mb.showinfo("Экспорт", "Экспорт базы данных в файл %s выполнено успешно." % filename)
                except: mb.showerror("Ошибка", "Экспорт не удался!")
        
    def clearDB(self):
        if mb.askyesno("Очистка", "Вы уверены, что хотите безвозвратно удалить все участки?")==True: self.deleteSelected(self, all=True)                              
    
    def newTer(self, event=None, number="", type="", address="", note="", map="", image="", silent=False): 
        self.db.append(Ter(number=number, type=type, address=address, note=note, map=map, image=image))      
        if silent==False: self.db[len(self.db)-1].show(self, new=True)          # if true, it is mass generation
            
    def checkDate(self, event):
        if d.verifyDate(self.chosenDate.get())==False:
            self.chosenDate.delete(0, "end")
            self.chosenDate.insert(0, self.prevDate)
        else:
            self.prevDate=self.chosenDate.get()            

    def find(self, event=None): 
        query = self.search.get().strip()
        if query=="": return
        count=0
        for i in range(len(self.db)):
            if self.searchHistory.get()==1:
                for w in self.db[i].works:
                    if query in w[0]:
                        self.db.insert(0, self.db.pop(i))
                        count+=1
            if query in self.db[i].number\
            or query in self.db[i].type\
            or query in self.db[i].address\
            or query in self.db[i].getDate1()\
            or query in self.db[i].getCurrentPublisher()\
            or query in self.db[i].getDate2()\
            or query in str(self.db[i].getWorks())\
            or query in self.db[i].note\
            or query in self.db[i].image\
            or query in self.db[i].map:
                self.db.insert(0, self.db.pop(i))
                count+=1
            
        self.update(sort=None)
        for i in range(count): self.list.itemconfig(i, bg="yellow")
        self.notebook.select(self.tabList)
        #self.tabList.focus_force()
            
    def openSingleTer(self, event=None):
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
    
    def openSelected(self, event=None):
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
        else: self.listPopup(event)
        
    def giveSelected(self, event=None):
        if len(self.list.curselection())==0: return
        elif self.chosenPublisher.get().strip()=="": self.setPublisher()                     
        if self.chosenPublisher.get().strip()!="":
            for i in range(len(self.list.curselection())):
                self.db[self.list.curselection()[i]].give(self)    
    
    def setPublisher(self):
        publisher=tk.Toplevel()
        publisher.title("Возвещатель")
        if os.name=="nt": publisher.iconbitmap("images/smile.ico")
        publisher.grab_set()
        publisher.focus_force()
        w = 250
        h = 30
        x = (publisher.winfo_screenwidth()/2) - (w/2)
        y = (publisher.winfo_screenheight()/2) - (h/2)-40
        publisher.geometry('%dx%d+%d+%d' % (w, h, x, y))
        publisher.grid_columnconfigure (0, weight=1)
        publisher.minsize(w,h)
        newPub=ttk.Entry(publisher)
        newPub.grid(padx=5, pady=5, sticky="we")
        def save(event):
            self.chosenPublisher.delete(0, "end")
            self.chosenPublisher.insert(0, newPub.get())
            publisher.destroy()
        newPub.bind("<Return>", save)
        def quit(event): publisher.destroy()
        publisher.bind("<Escape>", quit)
        newPub.focus_set()
        publisher.wait_window()
    
    def submitSelected(self, event=None):
        if len(self.list.curselection())==0: return
        elif self.chosenDate.get().strip()=="": self.chosenDate.focus_force()
        else:
            for i in range(len(self.list.curselection())): self.db[self.list.curselection()[i]].submit(self)
            
    def deleteSelected(self, event=None, all=False):
        if all==True:
            del self.db[:]
            self.save()
            self.updateR()
        elif len(self.list.curselection())==0: return                
        elif len(self.list.curselection())==1:
            if mb.askyesno("Удаление", "Удалить участок %s?" % self.db[self.list.curselection()[0]].number)==True:
                del self.db[self.list.curselection()[0]]
                self.save()
        else:
            if mb.askyesno("Удаление", "Удалить эти участки (%d)?" % len(self.list.curselection()))==True:
                count=0
                for i in self.list.curselection():
                    del self.db[i-count]
                    count+=1
                self.save()        
    
    def activateButtons(self, event=None):
        if len(self.list.curselection())!=0:
            self.selCount["text"]="Выбрано %d" % len(self.list.curselection())
            self.massEditButton.grid()
            self.massCopyButton.grid()
        else:
            self.selCount["text"]=""
            self.massEditButton.grid_remove()        
            self.massCopyButton.grid_remove()
            self.massCopyConfirm["text"]=""
        self.buttonGive.state(["!disabled"])
        self.buttonSubmit.state(["!disabled"])
        if len(self.list.curselection())==0:
            self.buttonGive.state(["disabled"])
            self.buttonSubmit.state(["disabled"])
            
    def massCopy(self, parent):
        parent.clipboard_clear()
        for i in range(len(self.list.curselection())): parent.clipboard_append("%s, " % self.db[self.list.curselection()[i]].number)               
        self.massCopyConfirm["text"]="Номера участков в буфере"        
        def __erase(): self.massCopyConfirm["text"]=""
        self.massCopyConfirm.after(1000, __erase)
    
    def setSort(self):
        self.settings[0]=str(self.sortType.get())
        self.saveSettings()
        self.update(sort=str(self.sortType.get()))
        
    def insertDate(self):
        self.chosenDate.delete(0, "end")
        self.chosenDate.insert(0, time.strftime("%d.%m", time.localtime()) + "." + str(int(time.strftime("%Y", time.localtime()))-2000))
        self.prevDate=self.chosenDate.get()
        
    def findFromReport(self, list, object, event=None):
        count=0
        if object=="type":
            query=self.types[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].type:
                    self.db.insert(0, self.db.pop(i))
                    count+=1      
        
        elif object=="publisher":
            query=self.publishers[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].getCurrentPublisher():
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        
        else:
            query=self.notes[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].note:
                    self.db.insert(0, self.db.pop(i))
                    count+=1      
              
        self.update(sort=None)
        for i in range(count): self.list.itemconfig(i, bg="yellow")
        self.notebook.select(self.tabList)
        
    
