#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
import pickle
import os
import datetime
from data import Ter
import data as d
import time
import webbrowser
import tkinter.messagebox as mb
import tools
import images
import contacts
from time import strftime, localtime
from classes import CreateToolTip, Splash
import tkinter.scrolledtext as ScrolledText
import _thread
#import junk

class Root(tk.Frame):
    """Main interface class"""  
    
    def __init__(self, firstSplashMessage):
        tk.Frame.__init__(self)
        
        # Run splash
        self.settings=d.load(self, loadDB=False)[2]        
        self.showSplash=tk.IntVar()
        self.showSplash.set(self.settings[14])        
        if self.showSplash.get()==1: self.master.withdraw()
        self.splash=Splash(self.showSplash.get())
        
        # Load db and settings
        self.splash.update(firstSplashMessage)
        self.msg=d.loadLanguage()
        self.splash.update(self.msg[3])
        self.db=d.load(self, loadSettings=False)[1]
        self.splash.update(self.msg[4])
        self.images()
        
        # Settings
        self.splash.update(self.msg[5])
        self.prevDate=""
        self.tips=self.msg[26]        
        self.sortType=tk.IntVar()                                               # define variables        
        self.autoUpdate=tk.IntVar()        
        self.listGrid=tk.IntVar()    
        self.fields=[]
        for i in range(8): self.fields.append(tk.IntVar())        
        self.listFont=tk.StringVar()        
        self.listFontSize=tk.StringVar()        
        self.doubleAddress=tk.IntVar()        
        self.workedTerYear=tk.IntVar()        
        self.noteAsText=tk.IntVar()        
        self.insertNew=tk.IntVar()
        self.timeoutDays=180
        self.exactSearch=tk.IntVar()        
        self.searchFields = tk.StringVar()        
        self.logLength=tk.IntVar()        
        self.actPrompts=tk.IntVar()        
        self.saveWindow=tk.IntVar()        
        self.images=tk.IntVar()
        self.searchHistory=tk.IntVar()
        self.bottomSB=tk.IntVar()
        self.lines=tk.IntVar()
        self.imageFolder=tk.StringVar()
        self.contactsEnabled=tk.IntVar()
        try:                                                                    # set variables
            self.sortType.set(self.settings[0])                                     
            self.autoUpdate.set(self.settings[1])
            self.listGrid.set(self.settings[2])        
            self.images.set(self.settings[3])       
            self.searchHistory.set(self.settings[4])        
            self.bottomSB.set(self.settings[5])
            self.lines.set(self.settings[6])        
            for i in range(8): self.fields[i].set(int(self.settings[7][i]))
            self.listFont.set(self.settings[8])
            self.listFontSize.set(self.settings[9])
            self.doubleAddress.set(self.settings[10])
            self.workedTerYear.set(self.settings[11])
            self.noteAsText.set(self.settings[12])
            self.insertNew.set(self.settings[13])            
            self.exactSearch.set(self.settings[16])
            if self.settings[17]=="": self.searchFields.set(self.msg[344])
            else: self.searchFields.set(self.settings[17])
            self.actPrompts.set(self.settings[19])
            self.saveWindow.set(self.settings[20])
            self.imageFolder.set(self.settings[21])
            self.contactsEnabled.set(self.settings[22])
            self.timeoutDays=int(self.settings[15])
            self.logLength.set(self.settings[18])
        except: print("some variables were not set")        
        
        # Styling
        self.splash.update(self.msg[6])
        self.fonts=d.getWinFonts()        
        if os.name=="nt" and not self.listFont.get() in self.fonts: self.listFont.set(self.fonts[0])        
        self.padx=self.pady=3
        self.headersPadx=2
        self.yellow="#ffff84"
        self.stripe="#e8f0ff"
        self.logColor="white"#"#f7fbff"
        self.style = ttk.Style()
        self.style.configure("new.TButton", font=('', 10))
        self.style.map('action.TButton', background=[('disabled', 'gray80')])
        self.style.configure("action.TButton", font=('', 9))
        self.style.configure("sort.TButton", relief="groove")        
        self.style.configure("manual.TEntry", activeforeground=self.stripe)
        self.style.configure("startup.TButton", relief="raised", font=("{Arial bold}", 12), width=25, justify="center")
        self.style.configure("small.TButton",  width=7, font=('', 7))           
        self.style.configure("gear.TLabel", background="gray94")                # list settings
        self.style.configure("small2.TButton", width=10, font=('', 7))
        self.style.configure("savecard.TButton", justify="center")
        self.style.configure("savecardPressed.TButton", background="SteelBlue", justify="center")
    
        # Window set up
        self.splash.update(self.msg[7])
        self.geo=[]
        self.winSizeX=870
        self.winSizeY=700
        try:
            with open("win.ini") as f: file=f.readlines()
            self.geo.append(int(file[0])) # w
            self.geo.append(int(file[1])) # h 
            self.geo.append(int(file[2])) # x
            self.geo.append(int(file[3])) # y
        except:
            ws = self.master.winfo_screenwidth()
            hs = self.master.winfo_screenheight()
            self.geo.append(self.winSizeX)
            self.geo.append(self.winSizeY)
            self.geo.append(int((ws/2) - (self.geo[0]/2)))
            self.geo.append(int((hs/2) - (self.geo[1]/2)))
            if self.master.winfo_screenwidth()<self.winSizeX or self.master.winfo_screenheight()<self.winSizeY: self.master.wm_state('zoomed')
        self.master.geometry('%dx%d+%d+%d' % (self.geo[0], self.geo[1], self.geo[2], self.geo[3]-40))        
        
        self.master.minsize(260,285)
        #if os.name=="nt": self.master.iconbitmap(self.ico[0])
        self.tk.call('wm', 'iconphoto', self.master._w, self.img[72])
        self.master.title("Halieus")
        self.master.grid_columnconfigure (0, weight=1)
        self.master.grid_rowconfigure    (2, weight=1)
        self.master.bind("<Alt-End>", self.submitSelected)
        self.master.bind("<Control-f>", lambda x: self.search.focus_force())
        self.master.bind("<Alt-0>", lambda x: self.chosenPublisher.focus_force())
        self.master.bind_class("TEntry", "<3>", self.standardMenu)
        self.master.bind_class("TCombobox", "<3>", self.standardMenu)
        
        # Main menu
        self.menubar = tk.Menu(self.master)
        self.filemenu1 = tk.Menu(self.menubar, tearoff=0)                       # Файл
        self.menubar.add_cascade(label=self.msg[14], menu=self.filemenu1)
        self.filemenu1.add_command(label=self.msg[18], image=self.img[27], compound="left", command=self.importDB) 
        self.filemenu1.add_command(label=self.msg[19], image=self.img[39], compound="left", command=self.exportDB)
        self.filemenu1.add_separator()
        self.filemenu1.add_command(label=self.msg[25], command=self.master.quit)
        self.filemenu2 = tk.Menu(self.menubar, tearoff=0)                       # Инструменты
        self.menubar.add_cascade(label=self.msg[15], menu=self.filemenu2)
        self.filemenu2.add_command(label=self.msg[20], image=self.img[40], compound="left", command=self.clearDB)
        self.filemenu2.add_command(label=self.msg[21], image=self.img[51], compound="left", command=self.restoreDB)
        self.filemenu2.add_command(label=self.msg[27], image=self.img[11], compound="left", command=lambda: tools.massCreate(self))
        self.filemenu2.add_command(label=self.msg[28], image=self.img[14], compound="left", command=lambda: tools.importXLS(self))
        self.filemenu2.add_command(label=self.msg[29], image=self.img[13], compound="left", command=lambda: tools.exportXLS(self))
        self.filemenu2.add_command(label=self.msg[30], image=self.img[69], compound="left", command=lambda: tools.exportPDF(self))
        self.filemenu2.add_command(label=self.msg[31], image=self.img[68], compound="left", command=lambda: tools.getFonts(self))
        self.filemenu3 = tk.Menu(self.menubar, tearoff=0)                       # Настройки
        self.menubar.add_cascade(label=self.msg[16], menu=self.filemenu3)
        self.filemenu3.add_checkbutton(label=self.msg[32], variable=self.autoUpdate, command=lambda: self.saveSettings("autoUpdate"))
        self.filemenu3.add_checkbutton(label=self.msg[33], variable=self.showSplash, command=self.saveSettings)
        self.filemenu3.add_checkbutton(label=self.msg[35], variable=self.noteAsText, command=self.saveSettings)
        self.filemenu3.add_checkbutton(label=self.msg[34], variable=self.images, command=lambda: self.saveSettings("images"))        
        self.filemenu3.add_checkbutton(label=self.msg[36], variable=self.insertNew, command=self.saveSettings)
        self.filemenu3.add_checkbutton(label=self.msg[37], variable=self.actPrompts, command=self.saveSettings)        
        self.filemenu3.add_checkbutton(label=self.msg[327], variable=self.contactsEnabled, command=lambda: self.saveSettings("contactsEnabled"))
        self.filemenu3.add_checkbutton(label=self.msg[196], variable=self.saveWindow, command=lambda: self.saveSettings("saveWindow"))        
        #filemenu3.add_checkbutton(label="Обработанный за год участок должен быть выдан не раньше года назад", variable=self.workedTerYear, command=self.saveSettings)        
        self.filemenu3.add_separator()
        self.filemenu3.add_command(label=self.msg[38] % self.timeoutDays, image=self.img[15], compound="left", command=lambda: self.setSetting("timeoutDays"))
        self.filemenu3.add_command(label=self.msg[39] % self.logLength.get(), image=self.img[65], compound="left", command=lambda: self.setSetting("logLength"))
        self.filemenu3.add_command(label=self.msg[198] % self.imageFolder.get(), image=self.img[54], compound="left", command=lambda: self.setSetting("imageFolder"))
        self.filemenu3.add_separator()
        self.tableMenu=tk.Menu(self.menubar, tearoff=1)                         # Настройки списка участков
        self.filemenu3.add_cascade(label=self.msg[40], image=self.img[50], compound="left", menu=self.tableMenu)
        self.fontMenu=tk.Menu(self.tableMenu, tearoff=1)                        # Шрифт
        self.tableMenu.add_cascade(label=self.msg[41], menu=self.fontMenu)        
        self.fontMenu.add_radiobutton(label="Courier New", variable=self.listFont, value="Courier New", command=lambda: self.saveSettings("listFont"))        
        if os.name!="nt" or "DejaVu Sans Mono" in self.fonts:
            self.fontMenu.add_radiobutton(label="DejaVu Sans Mono", variable=self.listFont, value="DejaVu Sans Mono", command=lambda: self.saveSettings("listFont"))        
        else: self.fontMenu.add_radiobutton(label="DejaVu Sans Mono", variable=self.listFont, value="DejaVu Sans Mono", state="disabled", command=lambda: self.saveSettings("listFont"))                
        if os.name!="nt" or "Lucida Console" in self.fonts:
            self.fontMenu.add_radiobutton(label="Lucida Console", variable=self.listFont, value="Lucida Console", command=lambda: self.saveSettings("listFont"))
        else: self.fontMenu.add_radiobutton(label="Lucida Console", variable=self.listFont, value="Lucida Console", state="disabled", command=lambda: self.saveSettings("listFont"))        
        if os.name!="nt" or "Ubuntu Mono" in self.fonts:
            self.fontMenu.add_radiobutton(label="Ubuntu Mono", variable=self.listFont, value="Ubuntu Mono", state="normal", command=lambda: self.saveSettings("listFont"))
        else:
            self.fontMenu.add_radiobutton(label="Ubuntu Mono", variable=self.listFont, value="Ubuntu Mono", state="disabled", command=lambda: self.saveSettings("listFont"))               
        if os.name!="nt" or "Liberation Mono" in self.fonts:
            self.fontMenu.add_radiobutton(label="Liberation Mono", variable=self.listFont, value="Liberation Mono", command=lambda: self.saveSettings("listFont"))        
        else: self.fontMenu.add_radiobutton(label="Liberation Mono", variable=self.listFont, value="Liberation Mono", state="disabled", command=lambda: self.saveSettings("listFont"))                
        if os.name!="nt" or "Cousine" in self.fonts:
            self.fontMenu.add_radiobutton(label="Cousine", variable=self.listFont, value="Cousine", command=lambda: self.saveSettings("listFont"))
        else: self.fontMenu.add_radiobutton(label="Cousine", variable=self.listFont, value="Cousine", state="disabled", command=lambda: self.saveSettings("listFont"))        
        if os.name!="nt" or "Fira Mono" in self.fonts:
            self.fontMenu.add_radiobutton(label="Fira Mono", variable=self.listFont, value="Fira Mono", command=lambda: self.saveSettings("listFont"))
        else: self.fontMenu.add_radiobutton(label="Fira Mono", variable=self.listFont, value="Fira Mono", state="disabled", command=lambda: self.saveSettings("listFont"))        
        if os.name!="nt" or "PT Mono" in self.fonts:
            self.fontMenu.add_radiobutton(label="PT Mono", variable=self.listFont, value="PT Mono", command=lambda: self.saveSettings("listFont"))
        else: self.fontMenu.add_radiobutton(label="PT Mono", variable=self.listFont, value="PT Mono", state="disabled", command=lambda: self.saveSettings("listFont"))        
        self.fontSizeMenu=tk.Menu(self.tableMenu, tearoff=1)                    # Размер шрифта
        self.tableMenu.add_cascade(label=self.msg[42], menu=self.fontSizeMenu)
        self.fontSizeMenu.add_radiobutton(label=self.msg[43], variable=self.listFontSize, value="7", command=lambda: self.saveSettings("listFontSize"))
        self.fontSizeMenu.add_radiobutton(label=self.msg[44], variable=self.listFontSize, value="8", command=lambda: self.saveSettings("listFontSize"))
        self.fontSizeMenu.add_radiobutton(label=self.msg[45], variable=self.listFontSize, value="9", command=lambda: self.saveSettings("listFontSize"))
        self.fontSizeMenu.add_radiobutton(label=self.msg[46], variable=self.listFontSize, value="10", command=lambda: self.saveSettings("listFontSize"))
        self.fontSizeMenu.add_radiobutton(label=self.msg[47], variable=self.listFontSize, value="11", command=lambda: self.saveSettings("listFontSize"))
        self.tableMenu.add_checkbutton(label=self.msg[48], variable=self.listGrid, command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[49], variable=self.lines, command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[50], variable=self.bottomSB, command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[51], variable=self.doubleAddress, command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_separator()
        self.tableMenu.add_checkbutton(label=self.msg[52], variable=self.fields[0], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[53], variable=self.fields[1], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[54], variable=self.fields[2], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[55], variable=self.fields[3], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[56], variable=self.fields[4], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[57], variable=self.fields[5], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[58], variable=self.fields[6], command=lambda: self.saveSettings("_listSet"))
        self.tableMenu.add_checkbutton(label=self.msg[59], variable=self.fields[7], command=lambda: self.saveSettings("_listSet"))        
        #self.filemenu4 = tk.Menu(self.menubar, tearoff=0)                       # Language
        #self.menubar.add_cascade(label=self.msg[22], menu=self.filemenu4)
        #self.filemenu4.add_command(label=self.msg[23], image=self.img[77], compound="left", command=lambda: self.changeLanguage("en"))
        #self.filemenu4.add_command(label=self.msg[24], image=self.img[78], compound="left", command=lambda: self.changeLanguage("ru"))       
                
        self.filemenu5 = tk.Menu(self.menubar, tearoff=0)                       # Help
        self.menubar.add_cascade(label=self.msg[17], menu=self.filemenu5)
        self.filemenu5.add_command(label=self.msg[60], image=self.img[4], compound="left", command=self.showTips)
        self.filemenu5.add_command(label=self.msg[61], image=self.img[31], compound="left", command=lambda: webbrowser.open("http://halieus.blogspot.com/"))
        self.filemenu5.add_command(label=self.msg[62], image=self.img[47], compound="left", command=self.about)
        self.master.config(menu=self.menubar)
        
        if self.images.get()==0: self.filemenu3.entryconfigure(11, label=self.msg[198] % self.imageFolder.get(), state="disabled")
        
        # Standard context menu
        self.splash.update(self.msg[8])
        self.conMenu = tk.Menu(self.master, tearoff=0)
        self.conMenu.add_command(label=self.msg[63])
        self.conMenu.add_command(label=self.msg[64])
        self.conMenu.add_command(label=self.msg[65])
        self.conMenu.add_command(label=self.msg[66])
        self.conMenu.add_separator()
        self.conMenu.add_command(label=self.msg[67])
        
        # Main notebook
        self.notebook=ttk.Notebook(self.master, style="main.TNotebook")
        self.notebook.grid(column=0, row=1, columnspan=2, rowspan=4, padx=self.padx, pady=self.pady, sticky="nwes")
        self.tabList=tk.Frame(self.notebook)                                    # tab 1
        self.notebook.add(self.tabList, text=self.msg[68], image=self.img[25], compound="left")
        self.tabList.columnconfigure(1, weight=1)
        self.tabList.rowconfigure(4, weight=1)
        self.tabReports=tk.Frame(self.notebook)                                 # tab 2
        self.notebook.add(self.tabReports, text=self.msg[69], image=self.img[43], compound="left")
        self.tabReports.columnconfigure(0, weight=1)
        self.tabReports.rowconfigure(0, weight=1)
        self.tabReports.bind("<Visibility>", self.updateR)
        self.tabLog=tk.Frame(self.notebook, bg=self.logColor)                   # tab 3
        self.notebook.add(self.tabLog, text=self.msg[70], image=self.img[65], compound="left")
        self.tabLog.columnconfigure(0, weight=1)
        self.tabLog.rowconfigure(0, weight=1)
        self.tabLog.bind("<Visibility>", self.updateLog)
        ttk.Separator(self.master, orient='horizontal').grid (column=0, row=5, columnspan=2, sticky='nwe')
        
        # TAB 1 (Ter list) ---------------------------------------------------------------
        
        # Mass selection bar 
        self.massFrame=tk.Frame(self.tabList)                                        
        self.massFrame.grid(column=0, row=2, columnspan=20, sticky="wens")                                            
        self.massFrame.grid_columnconfigure(4, weight=1)
        
        self.selCount=tk.Label(self.massFrame, fg="MidnightBlue")               # selection count 
        self.selCount.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="ws")
        self.massEditButton=ttk.Button(self.massFrame, text=self.msg[71], image=self.img[10], compound="left", command=lambda: tools.massEdit(self)) # mass edit
        self.massEditButton.grid(column=1, row=0, sticky="ws")
        CreateToolTip(self.massEditButton, self.msg[72])        
        self.massStatsButton=ttk.Button(self.massFrame, text=self.msg[73], image=self.img[24], compound="left", command=self.showMassStats) # mass (slice) statistics
        self.massStatsButton.grid(column=2, row=0, sticky="ws")                
        CreateToolTip(self.massStatsButton, self.msg[74])        
        self.massCopyButton=ttk.Button(self.massFrame, text=self.msg[75], image=self.img[49], compound="left", command=self.massCopy) # mass copy
        self.massCopyButton.grid(column=3, row=0, sticky="ws")
        CreateToolTip(self.massCopyButton, self.msg[76])
        self.cancelSel=ttk.Button(self.massFrame, text=self.msg[77], image=self.img[61], compound="left", command=self.cancelSelection) # cancel selection
        self.cancelSel.grid(column=4, row=0, sticky="ws")
        CreateToolTip(self.cancelSel, self.msg[78])
        
        self.sortMenu = tk.Menu(self.massFrame, tearoff=False)                  # sort menu
        self.sortMenu.add_command(label=self.msg[79], image=self.img[3], compound="left", command=lambda: self.setSort(0))
        self.sortMenu.add_command(label=self.msg[80], image=self.img[22], compound="left", command=lambda: self.setSort(1))
        self.sortMenu.add_command(label=self.msg[81], image=self.img[23], compound="left", command=lambda: self.setSort(2))
        self.sortMenu.add_command(label=self.msg[82], image=self.img[26], compound="left", command=lambda: self.setSort(3))
        self.sortMenu.add_command(label=self.msg[83], image=self.img[21], compound="left", command=lambda: self.setSort(4))
        self.sortMenu.add_command(label=self.msg[84], image=self.img[17], compound="left", command=lambda: self.setSort(5))
        self.sortMenu.add_command(label=self.msg[85], image=self.img[18], compound="left", command=lambda: self.setSort(6))
        self.sortMenu.add_command(label=self.msg[86], image=self.img[5], compound="left", command=lambda: self.setSort(7))
        self.sortMenu.add_command(label=self.msg[87], image=self.img[20], compound="left", command=lambda: self.setSort(8))
        
        self.filterYear = tk.IntVar()                                           # checkbutton
        self.filterYear.set(0)
        self.yearCheckbutton=ttk.Checkbutton(self.massFrame, text=self.msg[88], variable=self.filterYear, command=self.updateL)
        self.yearCheckbutton.grid(column=5, row=0, padx=self.padx, pady=self.pady, sticky="e")                         
        CreateToolTip(self.yearCheckbutton, self.msg[89])        
                
        # Manual list
        self.manualTip=tk.Label(self.massFrame, fg="MidnightBlue", text=self.msg[90])
        self.manualTip.grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="ws")
        self.manualList=ttk.Entry(self.massFrame, width=40, style="manual.TEntry")
        self.manualList.grid(column=1, row=0, padx=self.padx, pady=self.pady, sticky="wse")        
        self.manualList.bind("<KeyRelease>", self.activateButtons)
        self.manualList.bind("<FocusIn>", self.activateButtons)
        self.manualList.bind("<FocusOut>", self.activateButtons)
        self.manualList.bind("<Leave>", self.activateButtons)
        self.manualList.bind("<Return>", self.actSelected)
        CreateToolTip(self.manualList, self.msg[91])        
        self.cliptoManual=ttk.Button(self.massFrame, style="small2.TButton", text=self.msg[324])
        self.cliptoManual.grid(column=2, row=0, pady=2, sticky="ws")
        def _pasteAndActivate(event=None):
            self.manualList.event_generate("<<Paste>>")
            self.activateButtons()        
        self.cliptoManual.bind("<1>", _pasteAndActivate) 
        self.cliptoManual.bind("<Enter>", self.activateButtons)
        CreateToolTip(self.cliptoManual, self.msg[92])
        
        # Main list
        self.createList()
        
        # Operations
        self.statsMass=ttk.LabelFrame(self.tabList, text=self.msg[93])
        self.statsMass.grid(column=0, row=5, padx=self.padx, pady=self.pady, sticky="wens")           
        self.buttonAction = ttk.Button(self.statsMass, text=self.msg[94], style="action.TButton", image=self.img[63], compound="left", command=self.actSelected) # buttons
        self.buttonAction.grid(column=0, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky="we")
        CreateToolTip(self.buttonAction, self.msg[95])
        self.statsMass.columnconfigure(0, weight=1)
        ttk.Separator(self.statsMass, orient='vertical').grid(column=3, row=0, rowspan=2, padx=self.padx, pady=self.pady, sticky='ens')       
        ttk.Label(self.statsMass, image=self.img[17], compound="left", text=self.msg[96])  .grid(column=4, row=0, padx=self.padx, pady=self.pady*0, sticky="ws")
        ttk.Label(self.statsMass, image=self.img[19], compound="left", text=self.msg[97])         .grid(column=5, row=0, padx=self.padx, pady=self.pady*0, columnspan=2, sticky="ws")
        self.pubInBox = tk.StringVar()
        
        self.chosenPublisher=ttk.Combobox(self.statsMass, width=20, height=50, textvariable=self.pubInBox) # publisher combobox
        self.chosenPublisher.bind("<Return>", self.actSelected)        
        self.chosenPublisher.grid(column=4, row=1, padx=self.padx, pady=self.pady, sticky="wn")
        CreateToolTip(self.chosenPublisher, self.msg[98])        
        self.chosenDate=ttk.Entry(self.statsMass, width=8)        
        self.chosenDate.grid(column=5, row=1, padx=self.padx, pady=self.pady, sticky="wn")
        self.chosenDate.bind("<Return>", self.actSelected)        
        self.chosenDate.bind("<FocusOut>", self.checkDate)        
        CreateToolTip(self.chosenDate, self.msg[99])
        ttk.Button(self.statsMass, text=self.msg[100], style="small.TButton", command=self.insertDate).grid(column=6, row=1, padx=0, pady=self.pady, sticky="wn")
        
        # Search        
        self.searchBar=ttk.LabelFrame(self.tabList, text=self.msg[101], borderwidth=0)
        self.searchBar.grid(column=1, row=5, padx=self.padx*2, pady=self.pady, sticky="nws")
        self.searchBar.columnconfigure(1, weight=1)
        self.search=ttk.Entry(self.searchBar, width=31)
        self.search.grid(column=0, row=0, columnspan=2, padx=self.padx, pady=self.pady, sticky="swe")
        self.search.bind("<Return>", self.find)
        self.searchFilter=ttk.Combobox(self.searchBar, state="readonly", width=16, values=[self.msg[344], self.msg[103], self.msg[82], self.msg[83], self.msg[104], self.msg[105], self.msg[87]], textvariable=self.searchFields)
        self.searchFilter.grid(column=2, row=0, padx=self.padx, pady=self.pady, sticky="swe")        
        self.searchFilter.bind("<Return>", self.actSelected)        
        CreateToolTip(self.searchFilter, self.msg[107])
        self.strictSearch=ttk.Checkbutton(self.searchBar, text=self.msg[108], variable=self.exactSearch, command=lambda: self.saveSettings("strictSearch"))
        self.strictSearch.grid(column=0,row=1, padx=self.padx, pady=self.pady,sticky="nw")        
        CreateToolTip(self.strictSearch, self.msg[109])        
        self.includeHistory=ttk.Checkbutton(self.searchBar, text=self.msg[110], variable=self.searchHistory, command=lambda: self.saveSettings("includeHistory"))
        self.includeHistory.grid(column=1, columnspan=2, row=1, padx=0, pady=self.pady, sticky="nw")
        CreateToolTip(self.includeHistory, self.msg[111])                
        self.searchButton=ttk.Button(self.searchBar, text=self.msg[112], style="small.TButton", compound="left", command=self.find)
        self.searchButton.grid(column=2, row=1, padx=self.padx, pady=self.pady, sticky="ne")
        CreateToolTip(self.searchButton, self.msg[113])
        
        # New ter button
        self.newTerButton=ttk.Button(self.tabList, text=self.msg[114], compound="top", style='new.TButton', image=self.img[0], command=self.newTer)
        self.newTerButton.grid(column=7, row=5, padx=self.padx, pady=self.pady, ipadx=5, sticky="ens")
        CreateToolTip(self.newTerButton, self.msg[115])
        
        # TAB 2 (Reports) -----------------------------------------------------------------
        
        # Frame configuration
        self.frameReports=tk.Frame(self.tabReports)
        self.frameReports.grid(column=0,row=0,padx=self.padx, pady=self.pady, sticky="nesw")
        self.frameReports.columnconfigure(0, weight=5)
        self.frameReports.columnconfigure(1, weight=5)
        self.frameReports.rowconfigure(0, weight=2)
        self.frameReports.rowconfigure(1, weight=3)               
        
        self.subframe1=tk.Frame(self.frameReports, bg="white")                  # statistics [0,0]
        self.subframe1.grid(column=0,columnspan=2,row=0,rowspan=2,sticky="nesw")
        self.subframe1.rowconfigure(0, weight=1)
        self.subframe1.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe1, text=" "+self.msg[116], image=self.img[24], font="Tahoma 10 bold", compound="left").pack(fill="both")
        self.statsFrame=tk.Frame(self.subframe1, bg="white")
        self.statsFrame.pack(fill="both",padx=self.padx, pady=self.pady)        
        self.stat=[]
        for i, img in zip([0,1,2,3,4,5,6,7], [45,3,44,15,5,32,46,41]):
            self.stat.append(tk.Label(self.statsFrame, bg="white", cursor="hand2", image=self.img[img], compound="left"))
            self.stat[i].grid(column=0, row=i, sticky="wn")     
        self.stat[7]["cursor"]="arrow"
        self.stat[0]["cursor"]="arrow"
        CreateToolTip(self.stat[0], self.msg[117])     
        self.stat[1].bind("<1>", lambda x: self.findStat("checked"))
        CreateToolTip(self.stat[1], self.msg[118])
        self.stat[2].bind("<1>", lambda x: self.findStat("given"))
        CreateToolTip(self.stat[2], self.msg[119])
        self.stat[3].bind("<1>", lambda x: self.findStat("timedout"))
        self.timeoutTip=CreateToolTip(self.stat[3], self.msg[120] % self.timeoutDays)
        self.stat[4].bind("<1>", lambda x: self.findStat("workedYear"))
        CreateToolTip(self.stat[4], self.msg[121])
        self.stat[5].bind("<1>", lambda x: self.findStat("workedYearNot"))
        CreateToolTip(self.stat[5], self.msg[122])
        self.stat[6].bind("<1>", lambda x: self.findStat("notWorked"))  
        CreateToolTip(self.stat[6], self.msg[123])     
        CreateToolTip(self.stat[7], self.msg[124])
        self.statFootnote=tk.Label(self.statsFrame, bg="white", justify="left", text=self.msg[125])
        self.statFootnote.grid(column=0, row=8, padx=self.padx, pady=self.pady, sticky="wn")
        self.copyStats=ttk.Button(self.frameReports, image=self.img[49], command=lambda: self.pasteToClipboard(form=self.master, content=self.contentFullStats))
        self.copyStats.grid(column=0,row=0,padx=2, pady=2,sticky="se")
        CreateToolTip(self.copyStats, self.msg[126])
        
        self.subframe2=tk.Frame(self.frameReports, bd=0, bg="white")            # count types [1,0]
        self.subframe2.grid(column=1,row=0,sticky="nesw")
        self.subframe2.rowconfigure(1, weight=1)
        self.subframe2.columnconfigure(0, weight=1)        
        self.labelTypes=ttk.Label(self.subframe2, text=" "+self.msg[127], image=self.img[48], font="Tahoma 10 bold", compound="left")
        self.labelTypes.pack(fill="x")        
        self.typeList=tk.Listbox(self.subframe2, bd=0, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.typeList, orient="vertical", command=self.typeList.yview) 
        self.typeList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")        
        self.typeList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        listbar = tk.Menu(self.list)
        self.typeMenu=tk.Menu(listbar, tearoff=0)
        self.typeMenu.add_command(label=" "+self.msg[112], image=self.img[29], compound="left", command=lambda: self.findFromReport(self.typeList, "type"))
        self.typeList.bind("<3>", lambda event: self.typeMenu.post(event.x_root, event.y_root))
        self.typeList.bind("<Return>", lambda x: self.findFromReport(self.typeList, "type"))
        self.typeList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.typeList, "type"))        
        self.copyTypes=ttk.Button(self.subframe2, image=self.img[49], command=lambda: self.pasteToClipboard(form=self.master, content=self.contentTypes))
        self.copyTypes.pack(side="right",padx=2,pady=2)
        CreateToolTip(self.copyTypes, self.msg[126])
        
        self.subframe3=tk.Frame(self.frameReports, bg="white")                  # count publishers [0,1]
        self.subframe3.grid(column=0, row=1, sticky="nesw")
        self.subframe3.rowconfigure(1, weight=1)
        self.subframe3.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe3, text=" "+self.msg[128], image=self.img[17], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.pubList=tk.Listbox(self.subframe3, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.pubList, orient="vertical", command=self.pubList.yview) 
        self.pubList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")
        self.pubList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")    
        listbar = tk.Menu(self.list)
        self.pubMenu=tk.Menu(listbar, tearoff=0)
        self.pubMenu.add_command(label=" "+self.msg[112], image=self.img[29], compound="left", command=lambda: self.findFromReport(self.pubList, "publisher"))
        self.pubList.bind("<3>", lambda event: self.pubMenu.post(event.x_root, event.y_root))
        self.pubList.bind("<Return>", lambda x: self.findFromReport(self.pubList, "publisher"))
        self.pubList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.pubList, "publisher"))
        self.copyPubs=ttk.Button(self.subframe3, image=self.img[49], command=lambda: self.pasteToClipboard(form=self.master, content=self.contentPubs))
        self.copyPubs.pack(side="right",padx=2, pady=2,)
        CreateToolTip(self.copyPubs, self.msg[126]) 
        
        self.subframe4=tk.Frame(self.frameReports, bg="white")                  # count notes [1,1]
        self.subframe4.grid(column=1, row=1, sticky="nesw")
        self.subframe4.rowconfigure(1, weight=1)
        self.subframe4.columnconfigure(0, weight=1)        
        ttk.Label(self.subframe4, text=" "+self.msg[129], image=self.img[20], font="Tahoma 10 bold", compound="left").pack(fill="x")
        self.noteList=tk.Listbox(self.subframe4, bg="white", relief="flat", activestyle="dotbox")
        scrollbar=ttk.Scrollbar(self.noteList, orient="vertical", command=self.noteList.yview) 
        self.noteList.configure(yscrollcommand=scrollbar.set)      
        scrollbar.pack(side="right", fill="y")
        self.noteList.pack(expand=True, padx=self.padx, pady=self.pady, fill="both")        
        listbar = tk.Menu(self.list)
        self.noteMenu=tk.Menu(listbar, tearoff=0)
        self.noteMenu.add_command(label=" "+self.msg[112], image=self.img[29], compound="left", command=lambda: self.findFromReport(self.noteList, "note"))
        self.noteList.bind("<3>", lambda event: self.noteMenu.post(event.x_root, event.y_root))
        self.noteList.bind("<Return>", lambda x: self.findFromReport(self.noteList, "note"))
        self.noteList.bind("<Double-Button-1>", lambda x: self.findFromReport(self.noteList, "note"))
        self.copyNotes=ttk.Button(self.subframe4, image=self.img[49], command=lambda: self.pasteToClipboard(form=self.master, content=self.contentNotes))
        self.copyNotes.pack(side="right",padx=2, pady=2,)
        CreateToolTip(self.copyNotes, self.msg[126])
        
        # TAB 3 (Log) --------------------------------------------------------------------
        self.logWindow=ScrolledText.ScrolledText(self.tabLog, wrap="word", state="normal", bg=self.logColor, relief="flat")
        self.logWindow.grid(padx=self.padx, pady=self.pady, sticky="nesw")
        
        # TAB 4 (Contacts) ---------------------------------------------------------------
        if self.contactsEnabled.get()==1:
            self.splash.update(self.msg[133])
            self.tabContacts=contacts.MainTab(self)
    
        # --------------------------------------------------------------------------------
        
        # Footer
        self.statusFrame=tk.Frame(self.master)
        self.statusFrame.grid(column=0, row=6, padx=3, sticky="wn")      
        self.statusFrame.rowconfigure(0, weight=1)
        self.timedoutCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[15], compound="left")
        self.timedoutCount.pack(side="left", fill="y")
        self.timedoutCount.bind("<1>", lambda x: self.findStat("timedout"))
        self.timeoutTip2=CreateToolTip(self.timedoutCount, self.msg[120] % self.timeoutDays)
        self.nonWorkedYearCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[32], compound="left")
        self.nonWorkedYearCount.pack(side="left", fill="y")
        self.nonWorkedYearCount.bind("<1>", lambda x: self.findStat("workedYearNot"))
        CreateToolTip(self.nonWorkedYearCount, self.msg[122])
        self.nonWorkedCount=tk.Label(self.statusFrame, fg="gray20", cursor="hand2", image=self.img[46], compound="left")
        self.nonWorkedCount.pack(side="left", fill="y")
        self.nonWorkedCount.bind("<1>", lambda x: self.findStat("notWorked"))
        CreateToolTip(self.nonWorkedCount, self.msg[123])
        self.medal=tk.Label(self.statusFrame, fg="gray20", image=self.img[60], compound="left")
        self.medal.pack(side="left", fill="y")
        CreateToolTip(self.medal, self.msg[130])      
        self.terCount=tk.Label(self.master, fg="gray20", image=self.img[45], compound="left")
        self.terCount.grid(column=0, row=6, padx=20, sticky="e")
        CreateToolTip(self.terCount, self.msg[131])   
        self.statusBar=tk.Label(self.master, fg="gray20")
        self.statusBar.grid(column=1, columnspan=1, row=6, sticky="e")             
        CreateToolTip(self.statusBar, self.msg[132])
        ttk.Sizegrip(self.master).grid(column=1, row=0, rowspan=7, sticky="se")
        
        # Prepare to launch
        self.splash.update(self.msg[9])
        self.manualList.focus_force()
        self.activateButtons()
        self.insertDate()        
        self.updateL()
        self.updateS()
        self.updateR()
        self.updateP()
        self.splash.update(self.msg[11])
        self.cutLog()        
        if self.autoUpdate.get()==1:
            self.splash.update(self.msg[12])
            d.updateApp(self)
        self.splash.update(self.msg[13])
        self.master.deiconify()
        self.checkFirstLaunch()
        self.splash.update(self.msg[10])
        self.splash.end()
        self.saveSettings()
        self.geo[0]=self.master.winfo_width()
        self.geo[1]=self.master.winfo_height()
        self.geo[2]=self.master.winfo_x()
        self.geo[3]=self.master.winfo_y()        
        self.getWinSize()        

    # FUNCTIONS ---------------------------------------------------------------------------   
    
    def createList(self, new=False):
        if new==True:
            self.list.destroy()
            self.listbar.destroy()        
        self.font = "{%s} %d" % (self.listFont.get(), int(self.listFontSize.get())) # list
        self.list = tk.Listbox(self.tabList, activestyle="dotbox", selectmode="extended", relief="flat")
        self.list.grid(column=0, row=4, columnspan=20, sticky="nwes")  
        self.rightScrollbar = ttk.Scrollbar(self.list, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=self.rightScrollbar.set)      
        self.rightScrollbar.pack(side="right", fill="y")
        self.bottomScrollbar = ttk.Scrollbar(self.list, orient="horizontal", command=self.list.xview)
        self.list.configure(xscrollcommand=self.bottomScrollbar.set)        
        self.bottomScrollbar.pack(side="bottom", fill="x")        
        self.list.bind("<Return>", self.openSelected)        
        self.list.bind("<Double-1>", self.openSelected)
        self.list.bind("<<ListboxSelect>>", self.activateButtons)
        self.list.bind("<3>", self.listPopup)
        self.list.bind("<space>", self.actSelected)
        self.drawList()
        
        self.tableMenuButton=ttk.Button(self.massFrame, image=self.img[50], style="gear.TLabel") # table settings button
        self.tableMenuButton.grid(column=7, row=0, sticky="e")                  
        self.tableMenuButton.bind("<1>", lambda event: self.tableMenu.post(event.x_root, event.y_root))
        CreateToolTip(self.tableMenuButton, self.msg[40])  
        
        self.listbar = tk.Menu(self.list)                                       # context menu
        self.listmenu = tk.Menu(self.listbar, tearoff=0)
        self.listmenu.add_command(label=" "+self.msg[134], image=self.img[27], compound="left", command=self.openSingleTer)
        self.listmenu.add_command(label=" "+self.msg[135], image=self.img[64], compound="left", command=self.actSelected)
        self.listmenu.add_command(label=" "+self.msg[136], image=self.img[10], compound="left", command=lambda: tools.massEdit(self))
        self.listmenu.add_command(label=" "+self.msg[137], image=self.img[24], compound="left", command=self.showMassStats)
        self.listmenu.add_command(label=" "+self.msg[138], image=self.img[49], compound="left", command=self.massCopy)        
        self.listmenu.add_command(label=" "+self.msg[139], image=self.img[61], compound="left", command=self.cancelSelection)        
        self.listmenu.add_command(label=" "+self.msg[140], image=self.img[28], compound="left", command=self.deleteSelected)
        self.listbar.add_cascade(label=self.msg[141], menu=self.listmenu)
        self.list.bind("<Delete>", self.deleteSelected)
        self.list.bind("<BackSpace>", self.deleteSelected)
    
    def drawList(self):
        value = tuple(["%4s) %s" % (str(i+1), self.db[i].retrieve(self)) for i in range(len(self.db))])        
        self.list.configure(listvariable=tk.StringVar(value=value), font=self.font)
        if self.bottomSB.get()==1: self.bottomScrollbar.pack(side="bottom", fill="x")
        else: self.bottomScrollbar.pack_forget()        
        for i in range(len(self.db)):
            if i % 2 == 0: self.list.itemconfig(i,                  bg="white") # 2 bg colors for stripes
            else:
                if self.listGrid.get()==1: self.list.itemconfig(i,  bg=self.stripe)
                else: self.list.itemconfig(i,                       bg="white") 
            delta2=self.db[i].getDelta2()
            thisTerisNonWorked=0
            if delta2<365:
                if self.workedTerYear.get()==0: thisTerisNonWorked=1
                elif self.db[i].getDelta1()<365: thisTerisNonWorked=1            
            if self.filterYear.get()==1 and thisTerisNonWorked==1: self.list.itemconfig(i, bg='PaleGreen')
        
    def updateL(self):
        """Redraw ter list and footer"""
        try:                                                  
            self.drawList()
            worked,nonWorked,year,given,timedout,averagesSum=self.getStats()
            if timedout!=0:
                self.timedoutCount.pack(side="left", fill="y")
                self.timedoutCount["text"]=str(timedout)+" "
            else: self.timedoutCount.pack_forget()        
            if (len(self.db)-year)!=0:
                self.nonWorkedYearCount.pack(side="left", fill="y")            
                self.nonWorkedYearCount["text"]=str(len(self.db)-year)+" "
            else: self.nonWorkedYearCount.pack_forget()        
            if nonWorked!=0:
                self.nonWorkedCount.pack(side="left", fill="y")
                self.nonWorkedCount["text"]=str(nonWorked)+" "
            else: self.nonWorkedCount.pack_forget()        
            if timedout!=0 or (len(self.db)-year)!=0 or nonWorked!=0:
                self.medal.pack_forget()        
            else: self.medal.pack()        
            self.terCount["text"]=str(len(self.db))+" "
            try: self.statusBar["text"] = self.msg[142]+" %s      " % datetime.datetime.fromtimestamp(os.path.getmtime("core.hal")) # last core save            
            except: pass
        except:
            del self.db[:]
            self.updateL()        
            mb.showerror(self.msg[1], self.msg[143])
    
    def updateS(self, sort=-1):
        """Update sorting"""
        try: self.sortButton.destroy()
        except: pass
        self.sortButton=ttk.Button(self.massFrame, text=self.msg[144]+" ", compound="right", style="sort.TButton") # create sort button from scratch (for normal highlight)
        self.sortButton.grid(column=6, row=0, padx=self.padx, sticky="e")
        self.sortButton.bind("<1>", lambda event: self.sortMenu.post(event.x_root, event.y_root))
        CreateToolTip(self.sortButton, self.msg[145])
        if sort==-1: sort = self.sortType.get()                                 # -1 – when unchanged
        if sort==0:
            self.db.sort(key=lambda x: x.getStatus(self), reverse=True) 
            self.sortButton["image"]=self.img[3]
        elif sort==1:
            try: self.db.sort(key=lambda x: float(x.number))
            except:
                mb.showwarning(self.msg[146], self.msg[147])
                self.sortType.set(2)
                self.settings[0]=self.sortType.get()
                self.saveSettings()
                self.db.sort(key=lambda x: x.number)
                self.sortButton["image"]=self.img[23]
            else: self.sortButton["image"]=self.img[22]
        elif sort==2:
            self.db.sort(key=lambda x: x.number)
            self.sortButton["image"]=self.img[23]
        elif sort==3:
            self.db.sort(key=lambda x: x.type)
            self.sortButton["image"]=self.img[26]
        elif sort==4:
            self.db.sort(key=lambda x: x.address)
            self.sortButton["image"]=self.img[21]
        elif sort==5:
            self.db.sort(key=lambda x: x.getCurrentPublisher())
            self.sortButton["image"]=self.img[17]
        elif sort==6:
            self.db.sort(key=lambda x: d.convert(x.getDateLastSubmit()))
            self.sortButton["image"]=self.img[18]
        elif sort==7:
            self.db.sort(key=lambda x: x.getWorks())
            self.sortButton["image"]=self.img[5]
        elif sort==8:
            self.db.sort(key=lambda x: x.note)
            self.sortButton["image"]=self.img[20]
        #else: self.sortType.set(None)     
        self.drawList()
        
    def updateR(self,  event=None):
        """Redraw report tab"""
        self.tabLog["cursor"]="watch"
        self.master.update()
        self.fontReport="{%s} %s" % (self.listFont.get(), self.listFontSize.get())
        allStats=self.getStats()
        worked,nonWorked,year,given,timedout,averagesSum=allStats
        for i in range(8): self.stat[i]["font"]=self.fontReport
        self.stat[0]["text"] =          " %-36s %4d"   % (self.msg[148], len(self.db))                                       
        try: self.stat[1]["text"] =     " %-36s %4d (%.1f%%)*"   % (self.msg[149], (len(self.db)-given), (len(self.db)-given)/len(self.db)*100)       
        
        except: self.stat[1]["text"] =  " %-36s    0   (0.0%%)"  %  self.msg[149]         
        
        try: self.stat[2]["text"] =     " %-36s %4d (%.1f%%)"    % (self.msg[150], given, (given/len(self.db))*100)
        except: self.stat[2]["text"] =  " %-36s    0   (0.0%%)"  %  self.msg[150]        
        try: self.stat[3]["text"] =     " %-36s %4d (%.1f%%)"    % (self.msg[151], timedout, (timedout/len(self.db))*100)      
        except: self.stat[3]["text"] =  " %-36s    0   (0.0%%)"  %  self.msg[151]         
        try: self.stat[4]["text"] =     " %-36s %4d (%.1f%%)"    % (self.msg[152], year, (year/len(self.db))*100)
        except: self.stat[4]["text"] =  " %-36s    0   (0.0%%)"  %  self.msg[152]        
        try: self.stat[5]["text"] =     " %-36s %4d (%.1f%%)"    % (self.msg[153], len(self.db)-year, (100-(year/len(self.db))*100))      
        except: self.stat[5]["text"] =  " %-36s    0   (0.0%%)"  %  self.msg[153]         
        try: self.stat[6]["text"] =     " %-36s %4d (%.1f%%)"    % (self.msg[154], nonWorked, (nonWorked/len(self.db))*100)
        except: self.stat[6]["text"] =  " %-36s    0   (0.0%%)"  %  self.msg[154]
        self.stat[7]["text"]=           " %-37s %.1f мес."    %    (self.msg[155], allStats[5]/30.5)
        self.statFootnote["font"]="{%s} %d" % (self.listFont.get(), int(self.listFontSize.get())-1)
        self.contentFullStats=self.stat[0]["text"]+"\n"+self.stat[1]["text"]+"\n"+self.stat[2]["text"]+"\n"+self.stat[3]["text"]+"\n"+self.stat[4]["text"]+"\n"+self.stat[5]["text"]+"\n"+self.stat[6]["text"]+"\n"+self.stat[7]["text"]
        
        self.types=[]                                                           # calculate other reports / types
        self.fontReport="{%s} %s" % (self.listFont.get(), self.listFontSize.get())
        numbers=[]
        content=[]
        for ter in self.db: self.types.append(ter.type)
        self.types = list(set(self.types))
        self.types.sort()        
        for i in range(len(self.types)):
            numbers.append([self.types[i], 0])
            for ter in self.db: 
                if ter.type==self.types[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]=self.msg[156]
            content.append("%3s) %-34s %3s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))            
        listContent=tk.StringVar(value=tuple(content))
        self.typeList.configure(font=self.fontReport, listvariable=listContent)
        self.contentTypes=""
        for i in content: self.contentTypes+=i+"\n"
        
        self.publishers=[]                                                      # publishers
        numbers=[]
        content=[]
        for ter in self.db: self.publishers.append(ter.getCurrentPublisher())
        self.publishers = list(set(self.publishers))
        self.publishers.sort()        
        for i in range(len(self.publishers)):
            numbers.append([self.publishers[i], 0])
            for ter in self.db: 
                if ter.getCurrentPublisher()==self.publishers[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]=self.msg[157]
            content.append("%3s) %-35s %3s" % (str(i+1), numbers[i][0][:35], numbers[i][1]))
        listContent=tk.StringVar(value=tuple(content))
        self.pubList.configure(listvariable=listContent, font=self.fontReport)
        self.contentPubs=""
        for i in content: self.contentPubs+=i+"\n"    
        
        self.notes=[]                                                           # notes
        numbers=[]
        content=[]
        for ter in self.db: self.notes.append(ter.note)
        self.notes = list(set(self.notes))
        self.notes.sort()        
        for i in range(len(self.notes)):
            numbers.append([self.notes[i], 0])
            for ter in self.db: 
                if ter.note==self.notes[i]: numbers[i][1]+=1
            if numbers[i][0]=="": numbers[i][0]=self.msg[158]
            content.append("%3s) %-34s %3s" % (str(i+1), numbers[i][0][:34], numbers[i][1]))
        listContent=tk.StringVar(value=tuple(content))
        self.noteList.configure(listvariable=listContent, font=self.fontReport)
        self.contentNotes=""
        for i in content: self.contentNotes+=i+"\n"        
        self.tabLog["cursor"]="arrow"
    
    def updateP(self):
        """Update publishers combobox"""
        self.allPublishers=[]                                                       
        for ter in self.db:
            self.allPublishers.append(ter.getCurrentPublisher())     
            for w in ter.works:
                if d.getDelta(w[2])<365: self.allPublishers.append(w[0])                       
        self.allPublishers = list(set(self.allPublishers))
        self.allPublishers.sort()
        if len(self.allPublishers)>0 and self.allPublishers[0]=="": del self.allPublishers[0]                
        self.chosenPublisher["values"]=self.allPublishers
        
    def updateLog(self, event=None):
        self.cutLog()
        try:
            with open("log.txt", "r", encoding="utf=8") as log: content=log.read()
        except:
            print("log not found, create blank")
            with open("log.txt", "a", encoding="utf=8") as log: pass
            with open("log.txt", "r", encoding="utf=8") as log: content=log.read()        
        self.logWindow["font"]="{%s} 9" % self.listFont.get()
        self.logWindow.configure(state="normal")
        self.logWindow.delete(0.0, "end")
        if len(content)>0: self.logWindow.insert(0.0, content)
        else: self.logWindow.insert(0.0, self.msg[159])
        self.logWindow.configure(state="disabled")
        self.logWindow["font"]="{%s} 9" % self.listFont.get()
        self.logWindow.see("end")        
        
    def cutLog(self):
        try:
            with open("log.txt", "r", encoding="utf=8") as log: content=log.readlines()
        except: return
        if self.logLength.get()<len(content):
            print("cutting log")
            with open("log.txt", "w", encoding="utf=8") as log:
                for line in range(self.logLength.get(), 0, -1):
                    if line<len(content): log.write( content[ len(content)-line ] )
                    else: break                    
    
    def popupForCopy(self, content, event=None):
        if content=="email": self.menuEmail.post(event.x_root, event.y_root)
        else: self.menuWeb.post(event.x_root, event.y_root)
            
    def about(self):
        about=tk.Toplevel(bg="white")
        about.wm_overrideredirect(True)
        about.focus_force()
        about.grab_set()
        w = 700
        h = 300
        x = (about.winfo_screenwidth()/2) - (w/2)
        y = (about.winfo_screenheight()/2) - (h/2)-40
        about.geometry('%dx%d+%d+%d' % (w, h, x, y))
        about.minsize(w,h)        
        frame=tk.Frame(about, bg="white")
        frame.pack(expand=True, fill="both")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(2, weight=1)
        tk.Label(frame, bd=0,image=self.img[56]).place(x=0,y=0)
        with open("Halieus.pyw", "r", encoding="utf-8") as file: content = [line.rstrip() for line in file]
        ttk.Label(frame, text="Halieus %s" % content[0][10:], font="Arial 12 bold italic").grid(column=0,row=0,padx=5,pady=5,sticky="nw")        
        menubar=tk.Menu(about)
        self.menuEmail=tk.Menu(menubar, tearoff=0)                                 
        menubar.add_cascade(label=self.msg[14], menu=self.menuEmail)        
        self.menuEmail.add_command(label=self.msg[64], compound="left", command=lambda: self.pasteToClipboard(about, "antorix@gmail.com"))        
        self.menuWeb=tk.Menu(menubar, tearoff=0)                                 
        #self.menubar.add_cascade(label="Файл", menu=self.menuWeb)
        self.menuWeb.add_command(label=self.msg[64], compound="left", command=lambda: self.pasteToClipboard(about, "http://halieus.blogspot.com/"))            
        email=tk.Label(frame, bg="white", font="Arial 9 underline", text="antorix@gmail.com", cursor="hand2", image=self.img[57], compound="left")
        email.grid(column=1, row=0, padx=self.padx*8, pady=self.pady*8, sticky="w")
        email.bind("<Button-1>", lambda x: webbrowser.open("mailto:antorix@gmail.com"))
        email.bind("<Button-3>", lambda event: self.popupForCopy("email", event))                        
        web=tk.Label(frame, bg="white", font="Arial 9 underline", text="halieus.blogspot.com", cursor="hand2", image=self.img[58], compound="left")
        web.grid(column=1, row=1, padx=self.padx*8, sticky="w")              
        web.bind("<Button-1>", lambda x: webbrowser.open("http://halieus.blogspot.com/"))
        web.bind("<Button-3>", lambda event: self.popupForCopy("web", event))              
        tk.Label(frame, fg="gray20", bg="white", font="Arial 9 italic", justify="left", text=self.msg[160]).grid(column=1, row=2, padx=self.padx*4, pady=self.pady*2, sticky="es")
        frame2=tk.Frame(frame, bg="Teal",bd=5)
        frame2.grid(column=0,row=5,columnspan=2,sticky="wes")
        tk.Label(frame, fg="white", bg="Teal", font="Arial 7", text=self.msg[161]).grid(column=1,row=4,sticky="se")
        about.bind("<Escape>", lambda x: about.destroy())
        close=tk.Label(frame, bg="white", image=self.img[59])
        close.grid(column=1,row=0,sticky="ne")
        close.bind("<1>", lambda x: about.destroy())
        
    def showTips(self, title=None, text=None):
        if text==None: text=self.tips
        if title==None: title=self.msg[162]
        tip=tk.Toplevel(bg="white")
        tip.wm_overrideredirect(True)        
        tip.focus_force()
        tip.grab_set()
        frame=tk.Frame(tip, bg="white", relief='solid', borderwidth=1)
        frame.pack(expand=True, padx=self.padx, pady=self.pady*3, fill="both")
        frame.columnconfigure(0, weight=2)
        frame.columnconfigure(0, weight=5)
        tk.Label(frame, background="white", image=self.img[52]).grid(column=0, row=0, padx=self.padx, pady=self.pady, sticky="wens")
        tk.Label(frame, text=title, background="white", font="Arial 11 bold").grid(column=1, row=0, padx=self.padx, pady=self.pady, sticky="wns")
        tk.Message(frame, width=500, background="white", text=text).grid(column=1, row=1, padx=self.padx, pady=self.pady, sticky="e")
        x = (tip.winfo_screenwidth()/2)-300
        #y = (tip.winfo_screenheight()/7)        
        #ws=self.master.winfo_width()
        #hs=self.master.winfo_height()
        #x=self.master.winfo_x()
        y=tip.winfo_reqwidth()-40 
        if self.master.winfo_screenwidth()<self.winSizeX or self.master.winfo_screenheight()<self.winSizeY: tip.wm_state('zoomed')        
        tip.geometry('+%d+%d' % (x, y))   
        tip.bind("<Escape>", lambda x: tip.destroy())
        tip.bind("<3>", lambda x: tip.destroy())
        close=tk.Label(frame, bg="white", image=self.img[59])
        close.grid(column=1,row=0,sticky="ne")
        close.bind("<1>", lambda x: tip.destroy())   
        tip.wait_window()
        
    def listPopup(self, event=None):
        if len(self.list.curselection())==0:
            self.listmenu.entryconfig(" "+self.msg[134], state="disabled")
            self.listmenu.entryconfig(" "+self.msg[135], state="disabled")
            self.listmenu.entryconfig(" "+self.msg[136], state="disabled")
            self.listmenu.entryconfig(" "+self.msg[137], state="disabled")
            self.listmenu.entryconfig(" "+self.msg[138], state="disabled")
            self.listmenu.entryconfig(" "+self.msg[139], state="disabled")
            self.listmenu.entryconfig(" "+self.msg[140], state="disabled")
        elif len(self.list.curselection())==1:            
            self.listmenu.entryconfig(" "+self.msg[134], state="normal")
            self.listmenu.entryconfig(" "+self.msg[135], state="normal")
            self.listmenu.entryconfig(" "+self.msg[136], state="normal")
            self.listmenu.entryconfig(" "+self.msg[137], state="normal")
            self.listmenu.entryconfig(" "+self.msg[138], state="normal")
            self.listmenu.entryconfig(" "+self.msg[139], state="normal")
            self.listmenu.entryconfig(" "+self.msg[140], state="normal")            
        else:
            self.listmenu.entryconfig(" "+self.msg[134], state="disabled")
            self.listmenu.entryconfig(" "+self.msg[135], state="normal")
            self.listmenu.entryconfig(" "+self.msg[136], state="normal")
            self.listmenu.entryconfig(" "+self.msg[137], state="normal")
            self.listmenu.entryconfig(" "+self.msg[138], state="normal")
            self.listmenu.entryconfig(" "+self.msg[139], state="normal")
            self.listmenu.entryconfig(" "+self.msg[140], state="normal")
        self.listmenu.post(event.x_root, event.y_root)
    
    def saveSettings(self, variable=None):
        fields=""
        for i in range(8): fields+=str(self.fields[i].get())        
        with open("settings.ini", "w", encoding="utf-8") as file: pass
        with open("settings.ini", "a", encoding="utf-8") as file:
            file.write("<a000>%d</a000>\n"   % self.sortType.get())
            file.write("<a001>%d</a001>\n"   % self.autoUpdate.get())
            file.write("<a002>%d</a002>\n"   % self.listGrid.get())
            file.write("<a003>%d</a003>\n"   % self.images.get())
            file.write("<a004>%d</a004>\n"   % self.searchHistory.get())
            file.write("<a005>%d</a005>\n"   % self.bottomSB.get())
            file.write("<a006>%d</a006>\n"   % self.lines.get())
            file.write("<a007>%s</a007>\n"   % fields)
            file.write("<a008>%s</a008>\n"   % self.listFont.get())
            file.write("<a009>%s</a009>\n"   % self.listFontSize.get())
            file.write("<a010>%d</a010>\n"   % self.doubleAddress.get())
            file.write("<a011>%d</a011>\n"   % self.workedTerYear.get())
            file.write("<a012>%d</a012>\n"   % self.noteAsText.get())
            file.write("<a013>%d</a013>\n"   % self.insertNew.get())
            file.write("<a014>%d</a014>\n"   % self.showSplash.get())
            file.write("<a015>%d</a015>\n"   % self.timeoutDays)
            file.write("<a016>%d</a016>\n"   % self.exactSearch.get())
            file.write("<a017>%s</a017>\n"   % self.searchFields.get())
            file.write("<a018>%d</a018>\n"   % self.logLength.get())
            file.write("<a019>%d</a019>\n"   % self.actPrompts.get())
            file.write("<a020>%d</a020>\n"   % self.saveWindow.get())
            file.write("<a021>%s</a021>\n"   % self.imageFolder.get())
            file.write("<a022>%s</a022>\n"   % self.contactsEnabled.get())
        if self.insertNew.get()==1: self.master.bind("<Insert>", self.newTer)
        else: self.master.unbind("<Insert>")
        if variable=="listFontSize" or variable=="listFont" or variable=="_listSet": self.createList(new=True)
        elif variable=="autoUpdate" and self.autoUpdate.get()==1: d.updateApp(self)        
        elif variable=="saveWindow": self.getWinSize()
        elif variable=="contactsEnabled": self.switchContacts()
        elif variable=="images":
            if self.images.get()==0: self.filemenu3.entryconfigure(11, label=self.msg[198] % self.imageFolder.get(), state="disabled")
            else: self.filemenu3.entryconfigure(11, label=self.msg[198] % self.imageFolder.get(), state="normal")            

    def save(self, filename=False, export=False):
        self.filename=filename
        self.export=export
        def _runSave(threadName, delay):
            if self.export==False:
                try: os.remove("backup3.hal")
                except: print("can't delete backup3")
                try: os.rename("backup2.hal", "backup3.hal")
                except: print("can't rename backup2 to backup3")
                try: os.rename("backup1.hal", "backup2.hal")
                except: print("can't rename backup1 to backup2")
                try: os.rename("core.hal", "backup1.hal")
                except: print("can't rename core to backup1")
            if self.filename==False: self.filename="core.hal"                                 
            with open(self.filename, "wb") as file:
                try: pickle.dump(self.db, file) 
                except:
                    print("can't save core!")
                    mb.showerror(self.msg[1], self.msg[163])
                    self.log(self.msg[164])
        try: _thread.start_new_thread(_runSave,("Thread-Save", 1,))
        except: print("can't run thread")            
        else: self.updateL()
    
    def saveNotes(self, event=None):
        with open("notes.txt", "w", encoding="utf=8") as file: file.write(self.logNotes.get(1.0, "end"))

    def importDB(self, filename=None, backup=False):
        ftypes = [(self.msg[165], ".hal")]
        if filename==None: filename = filedialog.askopenfilename(filetypes=ftypes, defaultextension='.hal')
        if filename!="":
            self.tabList["cursor"]="watch"
            print("import attempt…")
            try:
                load=d.load(self, filename)
                if load[0]==True:
                    self.list.grid_remove()
                    self.tableMenuButton.grid_remove()                        
                    self.db=load[1]
                    self.save()
                    self.updateR()
                    self.updateP()
                    self.updateS()
                    print("import of %s successful, set acquired array as core" % filename)
                    self.log(self.msg[166] % filename)
                    self.createList()                    
                elif backup==False:
                    print("backup error")
                    self.log(self.msg[167] % filename)
                    mb.showerror(self.msg[1], self.msg[168] % filename)                
                else:
                    print("restore error")
                    return False                                                # backup restore attempt failed                
                self.updateLog()
            except: pass
        self.tabList["cursor"]="arrow"
        if self.contactsEnabled.get()==1: self.tabContacts.update()
        
    def exportDB(self):
        ftypes = [(self.msg[165], ".hal")]
        filename = filedialog.asksaveasfilename(filetypes=ftypes, initialfile=self.msg[169]+'.hal', defaultextension='.hal')
        if filename!="":
            try: self.save(filename=filename, export=True)                
            except: mb.showerror(self.msg[1], self.msg[170])
            else:
                mb.showinfo(self.msg[171], self.msg[172] % filename)
                self.log(self.msg[173] % filename)
                self.updateLog()
        
    def clearDB(self):
        if mb.askyesno(self.msg[20], self.msg[174])==True:
            self.deleteSelected(all=True)                              
            self.cancelSelection()
            if self.contactsEnabled.get()==1: self.tabContacts.update()
        
    def restoreDB(self):
        if mb.askyesno(self.msg[21], self.msg[175])==True:
            if self.importDB(filename="backup1.hal", backup=True)==False:
                print("backup1 not found")
                if self.importDB(filename="backup2.hal", backup=True)==False:
                    print("backup2 not found")
                    if self.importDB(filename="backup3.hal", backup=True)==False:
                        print("backup3 not found")
                        mb.showwarning(self.msg[21], self.msg[176])
                        
    def log(self, text):
        date = strftime("%d.%m", localtime()) + "." + str(int(strftime("%Y", localtime()))-2000)
        time = strftime("%H:%M:%S", localtime())
        with open("log.txt", "a", encoding="utf-8") as log: log.write("%s %s: %s\n" % (date, time, text))
    
    def newTer(self, event=None, number="", type="", address="", note="", map="", image="", work=[], silent=False): 
        self.db.append(Ter(number=number, type=type, address=address, note=note, map=map, image=image, work=work))      
        if silent==False: self.db[len(self.db)-1].show(self, new=True)          # if true, it is mass generation
            
    def checkDate(self, event):
        if d.verifyDate(self, self.chosenDate.get())==False:
            self.chosenDate.delete(0, "end")
            self.chosenDate.insert(0, self.prevDate)
        else:
            self.prevDate=self.chosenDate.get()            

    def find(self, event=None, query=None):
        if query==None: query=self.search.get().strip()
        if query=="": return
        count=0
        for i in range(len(self.db)):
            if self.searchFields.get()==self.msg[344]:
                if self.exactSearch.get()==0:
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query in w[0]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                            elif query in w[1]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                            elif query in w[2]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                    if query in self.db[i].number\
                    or query in self.db[i].type\
                    or query in self.db[i].address\
                    or query in self.db[i].getDate1()\
                    or query in self.db[i].getCurrentPublisher()\
                    or query in self.db[i].getDate2()\
                    or query in str(self.db[i].getWorks())\
                    or query in self.db[i].note\
                    or query in self.db[i].image\
                    or query in self.db[i].map:
                        self.db.insert(0, self.db.pop(i))
                        count+=1
                else:
                    if self.searchHistory.get()==1:                    
                        for w in self.db[i].works:
                            if query==w[0]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                            elif query==w[1]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                            elif query==w[2]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                    if query==self.db[i].number\
                    or query==self.db[i].type\
                    or query==self.db[i].address\
                    or query==self.db[i].getDate1()\
                    or query==self.db[i].getCurrentPublisher()\
                    or query==self.db[i].getDate2()\
                    or query==str(self.db[i].getWorks())\
                    or query==self.db[i].note\
                    or query==self.db[i].image\
                    or query==self.db[i].map:
                        self.db.insert(0, self.db.pop(i))
                        count+=1 
            elif self.searchFields.get()==self.msg[103]:
                if self.exactSearch.get()==0 and query in self.db[i].number: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].number: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
            elif self.searchFields.get()==self.msg[82]:
                if self.exactSearch.get()==0 and query in self.db[i].type: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].type: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
            elif self.searchFields.get()==self.msg[83]:
                if self.exactSearch.get()==0 and query in self.db[i].address: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].address: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1           
            elif self.searchFields.get()==self.msg[104]:
                if self.exactSearch.get()==0:
                    if query in self.db[i].getCurrentPublisher(): 
                        self.db.insert(0, self.db.pop(i))
                        count+=1
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query in w[0]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                elif self.exactSearch.get()==1:
                    if query==self.db[i].getCurrentPublisher(): 
                        self.db.insert(0, self.db.pop(i))
                        count+=1                
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query==w[0]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1             
            elif self.searchFields.get()==self.msg[105]:                
                if self.exactSearch.get()==0:
                    if query in self.db[i].getDate1() or query in self.db[i].getDate2(): 
                        self.db.insert(0, self.db.pop(i))
                        count+=1
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query in w[1] or query in w[2]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1
                elif self.exactSearch.get()==1:
                    if query==self.db[i].getDate1() or query==self.db[i].getDate2(): 
                        self.db.insert(0, self.db.pop(i))
                        count+=1                
                    if self.searchHistory.get()==1:
                        for w in self.db[i].works:
                            if query==w[1] or query==w[2]:
                                self.db.insert(0, self.db.pop(i))
                                count+=1                              
            elif self.searchFields.get()==self.msg[83]:
                if self.exactSearch.get()==0 and query in self.db[i].address: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].address: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
            elif self.searchFields.get()==self.msg[87]:
                if self.exactSearch.get()==0 and query in self.db[i].note: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
                elif self.exactSearch.get()==1 and query==self.db[i].note: 
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        #self.updateL()
        #self.updateS(sort=None)
        self.notebook.select(self.tabList)
        self.list.yview(0)        
        if count==0: self.quickTip(self.msg[177])
        else:
            self.updateS(sort=None)
            for i in range(count): self.list.itemconfig(i, bg=self.yellow)
            
    def openSingleTer(self, event=None):
        self.list.focus_force()
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
    
    def openSelected(self, event=None):
        self.list.focus_force()
        if len(self.list.curselection())==1: self.db[self.list.curselection()[0]].show(self)                    
        else: self.listPopup(event)
        
    def actSelected(self, event=None):
        """Give or submit ter(s)"""
        self.list["cursor"]="watch"
        self.manualList["cursor"]="watch"
        self.master.update()
        self.list.focus_force()
        if len(self.list.curselection())!=0:
            for i in range(len(self.list.curselection())):
                if self.db[self.list.curselection()[i]].getCurrentPublisher()=="": self.db[self.list.curselection()[i]].give(self)    
                else: self.db[self.list.curselection()[i]].submit(self)
        elif self.manualList.get().strip()!="":
            selection=self.manualList.get().strip()+","            
            start=end=0
            list=[]
            for i in range(len(selection)):
                if selection[i]==",":
                    end=i
                    list.append(selection[start:end].strip())
                    start=i+1
            else:
                count=0
                for i in range(len(list)):
                    for t in self.db:
                        if t.number==list[i]:
                            if t.getCurrentPublisher()=="": done=t.give(self)
                            else: done=t.submit(self)
                            count+=1
                if count==0: mb.showwarning(self.msg[1], self.msg[178])
                else:
                    if done==True: self.quickTip(self.msg[179], width=10, time=500)
        self.list["cursor"]="arrow"
        self.manualList["cursor"]="arrow"        
    
    def submitSelected(self, event=None):
        self.list.focus_force()
        if len(self.list.curselection())!=0:
            if self.chosenDate.get().strip()=="": self.chosenDate.focus_force()
            else:
                for i in range(len(self.list.curselection())): self.db[self.list.curselection()[i]].submit(self)
                
        elif self.manualList.get().strip()!="":
            selection=self.manualList.get().strip()+","            
            start=end=0
            list=[]
            for i in range(len(selection)):
                if selection[i]==",":
                    end=i
                    list.append(selection[start:end].strip())
                    start=i+1
            for i in range(len(list)):
                for t in self.db:
                    if t.number==list[i]: t.submit(self)
            
    def deleteSelected(self, event=None, all=False):
        if all==True:
            del self.db[:]
            self.save()
            self.log(self.msg[180])
            self.updateLog()
        elif len(self.list.curselection())==0: return                
        elif len(self.list.curselection())==1:
            if mb.askyesno(self.msg[181], self.msg[182] % self.db[self.list.curselection()[0]].number)==True:
                self.log(self.msg[183] % (self.db[self.list.curselection()[0]].number, self.db[self.list.curselection()[0]].address))
                del self.db[self.list.curselection()[0]]
                self.save()
                self.cancelSelection()
                if self.sortType.get()==1: self.updateS(sort=1)
        else:
            if mb.askyesno(self.msg[181], self.msg[184] % len(self.list.curselection()))==True:
                self.master["cursor"]="watch"
                self.master.update()
                count=0
                for i in self.list.curselection():
                    self.log(self.msg[183] % (self.db[i-count].number, self.db[i-count].address))
                    del self.db[i-count]                    
                    count+=1
                self.save()
                self.cancelSelection()
                if self.sortType.get()==1: self.updateS(sort=1)
                self.master["cursor"]="arrow"
    
    def activateButtons(self, event=None):
        if len(self.list.curselection())!=0:
            self.selCount["text"]=self.msg[185] % len(self.list.curselection())
            self.massEditButton.grid()
            self.massStatsButton.grid()
            self.massCopyButton.grid()
            self.cancelSel.grid()
            self.manualList.grid_remove()
            self.manualTip.grid_remove()
            self.cliptoManual.grid_remove()
        else:
            self.selCount["text"]=""
            self.massEditButton.grid_remove()        
            self.massCopyButton.grid_remove()
            self.massStatsButton.grid_remove()
            self.cancelSel.grid_remove()
            self.manualList.grid()
            self.manualTip.grid()
            self.cliptoManual.grid()        
        self.buttonAction.state(["!disabled"])
        if len(self.list.curselection())==0 and self.manualList.get().strip()=="":
            self.buttonAction.state(["disabled"])
            
    def cancelSelection(self, event=None):
        self.list.selection_clear(0, "end")
        self.activateButtons()
    
    def setPublisher(self):
        if len(self.allPublishers)>0: self.chosenPublisher.set(self.allPublishers[0])
        else: self.chosenPublisher.set(self.msg[186])
            
    def massCopy(self):
        self.master.clipboard_clear()
        for i in range(len(self.list.curselection())): self.master.clipboard_append("%s, " % self.db[self.list.curselection()[i]].number)               
        self.quickTip(self.msg[187])
        
    def setSort(self, sort, event=None):
        self.sortType.set(sort)
        self.saveSettings()
        self.updateS(sort)
        
    def insertDate(self):
        self.chosenDate.delete(0, "end")
        self.chosenDate.insert(0, time.strftime("%d.%m", time.localtime()) + "." + str(int(time.strftime("%Y", time.localtime()))-2000))
        self.prevDate=self.chosenDate.get()
        
    def findFromReport(self, list, object, event=None):
        count=0
        if object=="type":
            query=self.types[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].type:
                    self.db.insert(0, self.db.pop(i))
                    count+=1   
        elif object=="publisher":
            query=self.publishers[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].getCurrentPublisher():
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        else:
            query=self.notes[list.curselection()[0]]
            for i in range(len(self.db)):
                if query==self.db[i].note:
                    self.db.insert(0, self.db.pop(i))
                    count+=1      
        self.updateL()
        self.updateS(sort=None)
        for i in range(count): self.list.itemconfig(i, bg=self.yellow)
        self.notebook.select(self.tabList)
        self.list.yview(0)

    def findStat(self, type, event=None):
        """ Functions to find stats from the stat list """
        count=0
        if type=="checked":
            for i in range(len(self.db)):
                if self.db[i].getStatus(self)==0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="given":
            for i in range(len(self.db)):
                if self.db[i].getStatus(self)!=0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="timedout":
            for i in range(len(self.db)):
                if self.db[i].getStatus(self)==2:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="workedYear":
            for i in range(len(self.db)):
                if self.db[i].getDelta2()<365:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="workedYearNot":
            for i in range(len(self.db)):
                if self.db[i].getDelta2()>=365:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        elif type=="notWorked":
            for i in range(len(self.db)):
                if self.db[i].getWorks()==0:
                    self.db.insert(0, self.db.pop(i))
                    count+=1
        else: return
        self.updateL()
        self.updateS(sort=None)
        #self.updateS(sort=None)
        self.notebook.select(self.tabList)
        for i in range(count): self.list.itemconfig(i, bg=self.yellow)
        self.list.yview(0)     

    def getStats(self, selection=None):
        """ Return statistics of selection of ters or all database is none"""
        if selection==None: selection=list(range(0, len(self.db)))
        worked=year=given=timedout=nonWorked=0
        averages=[]          
        for i in range(len(selection)):                                         # coloring
            if self.db[selection[i]].getPublisher()!="" and self.db[selection[i]].getStatus(self)!=0: given+=1
            if self.db[selection[i]].getWorks()==0: nonWorked+=1
            if self.db[selection[i]].getStatus(self)==2: timedout+=1            # color for non-worked ters
            else: self.list.itemconfig(i,               fg="gray15")            # color for regular ters
            delta2=self.db[selection[i]].getDelta2()
            if delta2<365:
                if self.workedTerYear.get()==0: year+=1                    
                elif self.db[selection[i]].getDelta1()<365: year+=1                    
            averages+=self.db[selection[i]].getAverageWork()
        worked=len(selection)-nonWorked
        try: averagesSum=sum(averages)/float(len(averages))
        except: averagesSum=0.0        
        return worked,nonWorked,year,given,timedout,averagesSum

    def showMassStats(self):        
        form=tk.Toplevel(bg="white")
        form.title(self.msg[137]+" (%d)" % len(self.list.curselection()))
        form.minsize(300,0)
        form.tk.call('wm', 'iconphoto', form._w, self.img[76])
        form.focus_force()
        form.grid_columnconfigure (1, weight=1)
        form.bind("<Escape>", lambda x: form.destroy())
        padx=pady=1
        frame=tk.Frame(form, bg="white")                
        frame.pack(expand=True)
        frame.columnconfigure(0, weight=1)        
        form.columnconfigure(0, weight=1)        
        form.rowconfigure(0, weight=1)        
        stat=[]        
        for i, img in zip([0,1,2,3,4,5,6,7], [45,3,44,15,5,32,46,41]):
            stat.append(tk.Label(frame, bg="white", text="", image=self.img[img], compound="left"))
            stat[i].grid(column=0, row=i, padx=padx, pady=pady, sticky="w")        
        allStats=self.getStats(self.list.curselection())
        worked,nonWorked,year,given,timedout,averagesSum=allStats        
        for i in range(8): stat[i]["font"]=self.fontReport
        stat[0]["text"] =          "%-27s %4d, из них:"   % (" "+self.msg[188], len(self.list.curselection()))                                       
        try: stat[1]["text"] =     "%-27s %4d (%.1f%%)"   % (" "+self.msg[149], (len(self.list.curselection())-given), (len(self.list.curselection())-given)/len(self.list.curselection())*100)       
        except: stat[1]["text"] =  "%-27s    0   (0.0%%)" %  " "+self.msg[149]         
        try: stat[2]["text"] =     "%-27s %4d (%.1f%%)"   % (" "+self.msg[150], given, (given/len(self.list.curselection()))*100)
        except: stat[2]["text"] =  "%-27s    0   (0.0%%)" %  " "+self.msg[150]        
        try: stat[3]["text"] =     "%-27s %4d (%.1f%%)"   % (" "+self.msg[151], timedout, (timedout/len(self.list.curselection()))*100)      
        except: stat[3]["text"] =  "%-27s    0   (0.0%%)" %  " "+self.msg[151]         
        try: stat[4]["text"] =     "%-27s %4d (%.1f%%)"   % (" "+self.msg[152], year, (year/len(self.list.curselection()))*100)
        except: stat[4]["text"] =  "%-27s    0   (0.0%%)" %  " "+self.msg[152]        
        try: stat[5]["text"] =     "%-27s %4d (%.1f%%)"   % (" "+self.msg[153], len(self.list.curselection())-year, (100-(year/len(self.list.curselection()))*100))      
        except: stat[5]["text"] =  "%-27s    0   (0.0%%)" %  " "+self.msg[153]         
        try: stat[6]["text"] =     "%-27s %4d (%.1f%%)"   % (" "+self.msg[154], nonWorked, (nonWorked/len(self.list.curselection()))*100)
        except: stat[6]["text"] =  "%-27s    0   (0.0%%)" %  " "+self.msg[154]
        stat[7]["text"]=           "%-28s %.1f мес."      % (" "+self.msg[155], allStats[5]/30.5)        
        content=stat[0]["text"]+"\n"+stat[1]["text"]+"\n"+stat[2]["text"]+"\n"+stat[3]["text"]+"\n"+stat[4]["text"]+"\n"+stat[5]["text"]+"\n"+stat[6]["text"]+"\n"+stat[7]["text"]        
        copyButton=ttk.Button(form, image=self.img[49], command=lambda: self.pasteToClipboard(form, content))
        copyButton.pack(side="right")
        CreateToolTip(copyButton, self.msg[189])        
        
    def standardMenu(self, e):
        self.conMenu.entryconfigure(self.msg[63], command=lambda: e.widget.event_generate("<<Cut>>"))
        self.conMenu.entryconfigure(self.msg[64], command=lambda: e.widget.event_generate("<<Copy>>"))
        self.conMenu.entryconfigure(self.msg[65], command=lambda: e.widget.event_generate("<<Paste>>"))
        self.conMenu.entryconfigure(self.msg[66], command=lambda: e.widget.event_generate("<<Clear>>"))
        self.conMenu.entryconfigure(self.msg[67], command=lambda: e.widget.event_generate("<<SelectAll>>"))              
        self.conMenu.tk.call("tk_popup", self.conMenu, e.x_root, e.y_root)
        
    def quickTip(self, text, width=100, time=1000):
        """Show self-destructing notification in center of screen"""
        confirm=tk.Toplevel(bg="white")
        confirm.wm_overrideredirect(True)        
        frame=tk.Frame(confirm, bg="white", relief='solid', borderwidth=1)
        frame.pack(expand=True, fill="both")
        tk.Label(frame, text=text, background="white", highlightbackground="gray50").pack(padx=self.padx, pady=self.pady, expand=True, fill="both")
        x = (confirm.winfo_screenwidth()/2) - (width/2)
        y = (confirm.winfo_screenheight()/2.3)
        confirm.geometry('+%d+%d' % (x, y))        
        confirm.after(time, lambda: confirm.destroy())

    def pasteToClipboard(self, form, content):
        form.clipboard_clear()
        form.clipboard_append(content)
        self.quickTip(self.msg[190])
        
    def checkFirstLaunch(self):
        if not os.path.exists("settings.ini"):
            self.showTips(text=self.msg[191]+"\n\n" + self.tips)                       
            if len(self.db)==0:
                color="white"
                self.tip=tk.Toplevel(bg=color)
                w = self.master.winfo_screenwidth()/3
                h = self.master.winfo_screenheight()/6
                ws = self.master.winfo_screenwidth()
                hs = self.master.winfo_screenheight()
                x = (ws/2) - (w/2)
                y = (hs/2) - (h/2)-50
                self.tip.geometry('%dx%d+%d+%d' % (w, h, x, y))            
                self.tip.wm_overrideredirect(True)        
                self.tip.focus_force()
                #self.master.wm_state('iconic')                
                #self.tip.grab_set()
                frame=tk.Frame(self.tip, bg=color, relief='flat')
                frame.pack(expand=True, padx=self.padx, pady=self.pady, fill="y")
                frame.rowconfigure(0,weight=1)
                frame.columnconfigure(0,weight=1)
                frame.columnconfigure(1,weight=1)            
                frame.columnconfigure(2,weight=1)           
                tk.Button(frame, image=self.img[2], width=200, compound="top", relief="groove", bd=2, justify="center", font="Tahoma 10 bold", text=self.msg[192], command=lambda: tools.importXLS(self, self.tip)).grid(column=0,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw")
                tk.Button(frame, image=self.img[37], width=200, compound="top", relief="groove", bd=2, justify="center", font="Tahoma 10 bold", text=self.msg[193], command=lambda: tools.massCreate(self, self.tip)).grid(column=1,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw")
                tk.Button(frame, image=self.img[55], width=200, compound="top", relief="groove", bd=2, justify="center", font="Tahoma 10 bold", text=self.msg[194], command=self.tip.destroy).grid(column=2,row=0, padx=self.padx*3, pady=self.pady*3, sticky="nesw")
                self.tip.wait_window()
                #self.master.wm_state('normal')

    def setSetting(self, setting):
        """Interface to get various numeral settings"""
        bgColor="gray94"
        width=180
        padx=pady=5
        form=tk.Toplevel(bg=bgColor, bd=1, relief='solid', borderwidth=1)
        w=200
        h=100
        ws = form.winfo_screenwidth()
        hs = form.winfo_screenheight()
        x = (ws/2)-(w/2)
        y = (hs/2)-(h/2)-50
        form.geometry('+%d+%d' % (x, y))
        form.wm_overrideredirect(True) 
        form.grab_set()
        entry=tk.Entry(form, relief="flat")
        entry.pack(side="bottom", padx=5,pady=5, fill="x")
        entry.focus_force()        
        if setting=="timeoutDays":
            tk.Message(form, bg=bgColor, width=width, text=self.msg[195]).pack(side="top", padx=padx,pady=pady)
            entry.insert(0, self.timeoutDays)
            def _saveSetting(event=None):
                try: self.timeoutDays=int(entry.get().strip())
                except: print("setting loading error")
                else: 
                    self.filemenu3.entryconfigure(9, label=self.msg[38] % self.timeoutDays)
                    self.timeoutTip.rewrite(self.msg[120] % self.timeoutDays)
                    self.timeoutTip2.rewrite(self.msg[120] % self.timeoutDays)
                    form.destroy()
                    self.updateS()
                    self.saveSettings()
        elif setting=="logLength":
            tk.Message(form, bg=bgColor, width=width, text=self.msg[197]).pack(padx=padx,pady=pady)
            entry.insert(0, self.logLength.get())
            def _saveSetting(event=None):
                try: self.logLength.set(int(entry.get().strip()))
                except: print("setting loading error")
                else:
                    self.filemenu3.entryconfigure(10, label=self.msg[39] % self.logLength.get())                    
                    self.cutLog()
                    self.updateLog()
                    form.destroy()
                    self.saveSettings()
        elif setting=="imageFolder":
            tk.Message(form, bg=bgColor, width=width, text=self.msg[330]).pack(padx=padx,pady=pady)
            entry.insert(0, self.imageFolder.get())
            def _saveSetting(event=None):
                try: self.imageFolder.set(entry.get().strip())
                except: print("setting loading error")
                else:
                    self.filemenu3.entryconfigure(11, label=self.msg[198] % self.imageFolder.get())
                    form.destroy()
                    self.saveSettings()
        entry.bind("<Return>", _saveSetting)
        entry.bind("<FocusOut>", _saveSetting)
        entry.bind("<Escape>", lambda x: form.destroy())
        
    def changeLanguage(self, lang):
        print("language changed to %s" % lang)
        with open("lang.ini", "w", encoding="utf-8") as f: f.write(lang)
        self.master.destroy()
        d.loadLanguage()
        Root().mainloop()
        
    def getWinSize(self, event=None):
        """Manage window geometry saving"""
        if self.saveWindow.get()==1:
            self.master.bind("<Configure>", self.getWinSize)
            ws=self.master.winfo_width()
            hs=self.master.winfo_height()
            x=self.master.winfo_x()
            y=self.master.winfo_y()            
            if ws!=self.geo[0] or hs!=self.geo[1] or x!=self.geo[2] or y!=self.geo[3]:
                with open("win.ini", "w") as f: f.write("%d\n%d\n%d\n%d" % (ws, hs, x, y))        
                #print("saved")
                self.geo[0]=ws
                self.geo[1]=hs
                self.geo[2]=x
                self.geo[3]=y
        else:
            self.master.unbind("<Configure>")
            if os.path.exists("win.ini"): os.remove("win.ini")
            
    def switchContacts(self):
        """Manage contacts on/off in settings"""
        if self.contactsEnabled.get()==1:
            self.tabContacts=contacts.MainTab(self)
            self.updateL()
        elif mb.askyesno(self.msg[327], self.msg[329])==False: self.contactsEnabled.set(1)
        else:
            for ter in self.db:
                if len(ter.extra)>0: del ter.extra[0][:]
            self.tabContacts.tabCon.destroy()
            self.save()
            self.log(self.msg[331])
            self.updateL()
            
    # OUTSOURCED FUNCTIONS ----------------------------------------------------------------

    def images(self): images.images(self)
