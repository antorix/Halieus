import tkinter as tk 
def images(self):
    self.ico=[]
    self.ico.append("icon.ico")                                                 # 0
    self.ico.append("images/mass.ico")                                          # 1
    self.ico.append("images/mass_save.ico")                                     # 2
    self.ico.append("images/card.ico")                                          # 3
    self.ico.append("images/work.ico")                                          # 4        
    self.ico.append("images/chart.ico")                                         # 5        
    self.ico.append("images/statistics.ico")                                    # 6
    self.ico.append("images/excel.ico")                                         # 7
    self.img=[]
    self.img.append(tk.PhotoImage(file="images/plus32.gif"))                    # 0
    self.img.append(tk.PhotoImage(file="images/excel_sample.gif"))              # 1
    self.img.append(tk.PhotoImage(file="images/excel_file32.gif"))              # 2
    self.img.append(tk.PhotoImage(file="images/tick16.gif"))                    # 3
    self.img.append(tk.PhotoImage(file="images/bulb16.gif"))                    # 4
    self.img.append(tk.PhotoImage(file="images/work16.gif"))                    # 5
    self.img.append(tk.PhotoImage(file="images/play32.gif"))                    # 6
    self.img.append(tk.PhotoImage(file="images/stop32.gif"))                    # 7
    self.img.append(tk.PhotoImage(file="images/stop16.gif"))                    # 8
    self.img.append(tk.PhotoImage(file="images/play16.gif"))                    # 9
    self.img.append(tk.PhotoImage(file="images/mass_save16.gif"))               # 10
    self.img.append(tk.PhotoImage(file="images/mass16.gif"))                    # 11
    self.img.append(tk.PhotoImage(file="images/mass_save32.gif"))               # 12
    self.img.append(tk.PhotoImage(file="images/excel_export16.gif"))            # 13
    self.img.append(tk.PhotoImage(file="images/excel_import16.gif"))            # 14
    self.img.append(tk.PhotoImage(file="images/warning16.gif"))                 # 15
    self.img.append(tk.PhotoImage(file="images/fish128.gif"))                   # 16
    self.img.append(tk.PhotoImage(file="images/smile16.gif"))                   # 17
    self.img.append(tk.PhotoImage(file="images/calendar16.gif"))                # 18
    self.img.append(tk.PhotoImage(file="images/calendar_chain16.gif"))          # 19
    self.img.append(tk.PhotoImage(file="images/note16.gif"))                    # 20
    self.img.append(tk.PhotoImage(file="images/house16.gif"))                   # 21
    self.img.append(tk.PhotoImage(file="images/sort_numbers16.gif"))            # 22
    self.img.append(tk.PhotoImage(file="images/sort_alph16.gif"))               # 23
    self.img.append(tk.PhotoImage(file="images/statistics16.gif"))              # 24
    self.img.append(tk.PhotoImage(file="images/table16.gif"))                   # 25
    self.img.append(tk.PhotoImage(file="images/tag16.gif"))                     # 26
    self.img.append(tk.PhotoImage(file="images/open16.gif"))                    # 27
    self.img.append(tk.PhotoImage(file="images/multiply16.gif"))                # 28
    self.img.append(tk.PhotoImage(file="images/lens13.gif"))                    # 29
    self.img.append(tk.PhotoImage(file="images/info16.gif"))                    # 30
    self.img.append(tk.PhotoImage(file="images/support16.gif"))                 # 31
    self.img.append(tk.PhotoImage(file="images/bell16.gif"))                    # 32
    self.img.append(tk.PhotoImage(file="images/clock16.gif"))                   # 33
    self.img.append(tk.PhotoImage(file="images/map24.gif"))                     # 34
    self.img.append(tk.PhotoImage(file="images/png_file24.gif"))                # 35
    self.img.append(tk.PhotoImage(file="images/save16.gif"))                    # 36
    self.img.append(tk.PhotoImage(file="images/mass32.gif"))                    # 37
    self.img.append(tk.PhotoImage(file="images/db_save16.gif"))                 # 38
    self.img.append(tk.PhotoImage(file="images/db_export16.gif"))               # 39
    self.img.append(tk.PhotoImage(file="images/db_delete16.gif"))               # 40
    self.img.append(tk.PhotoImage(file="images/stopwatch16.gif"))               # 41
    self.img.append(tk.PhotoImage(file="images/export_excel32.gif"))            # 42
    self.img.append(tk.PhotoImage(file="images/calc16.gif"))                    # 43
    self.img.append(tk.PhotoImage(file="images/given16.gif"))                   # 44
    self.img.append(tk.PhotoImage(file="images/db16.gif"))                      # 45
    self.img.append(tk.PhotoImage(file="images/freeze16.gif"))                  # 46
    self.img.append(tk.PhotoImage(file="images/about16.gif"))                   # 47
    self.img.append(tk.PhotoImage(file="images/tags16.gif"))                    # 48
    self.img.append(tk.PhotoImage(file="images/clipboard16.gif"))               # 49
    self.img.append(tk.PhotoImage(file="images/table_gear16.gif"))              # 50 
    self.img.append(tk.PhotoImage(file="images/db_refresh16.gif"))              # 51
    self.img.append(tk.PhotoImage(file="images/bulb48.gif"))                    # 52
    self.img.append(tk.PhotoImage(file="images/map16.gif"))                     # 53
    self.img.append(tk.PhotoImage(file="images/image16.gif"))                   # 54
    self.img.append(tk.PhotoImage(file="images/hourglass32.gif"))               # 55
    self.img.append(tk.PhotoImage(file="images/splash.gif"))                    # 56
    self.img.append(tk.PhotoImage(file="images/email16.gif"))                   # 57
    self.img.append(tk.PhotoImage(file="images/w16.gif"))                       # 58
    self.img.append(tk.PhotoImage(file="images/close13.gif"))                   # 59
    self.img.append(tk.PhotoImage(file="images/medal16.gif"))                   # 60
    self.img.append(tk.PhotoImage(file="images/cancel16.gif"))                  # 61
    self.img.append(tk.PhotoImage(file="images/exit16.gif"))                    # 62    
    self.img.append(tk.PhotoImage(file="images/action32.gif"))                  # 63
    self.img.append(tk.PhotoImage(file="images/action16.gif"))                  # 64
    self.img.append(tk.PhotoImage(file="images/book16.gif"))                    # 65
    self.img.append(tk.PhotoImage(file="images/gear12.gif"))                    # 66
    self.img.append(tk.PhotoImage(file="images/notebook16.gif"))                    # 67

class Test():
    def __init__(self): pass
test = Test()
tk.Tk()
images(test)
