Halieus не требует установки, но необходимо установить движок Python. В Windows для этого достаточно просто запустить файл УСТАНОВКА.exe. Проверьте соединение с Интернетом – будет загружено примерно 13 МБ. Сама программа запускается файлом Halieus.pyw. Если обычный двойной щелчок мыши не работает, откройте правым щелчком контекстное меню и там Открыть с помощью – Python. Можно создать ярлык на рабочем столе с помощью прилагаемой иконки (файл "icon.ico").

LINUX

В Ubuntu Linux введите:

sudo apt-get install idle3

Затем запустите через IDLE3 файл Halieus.pyw (File – Open – F5).

MAC

В OS X установите Python по ссылке:

https://www.python.org/ftp/python/3.6.0/python-3.6.0-macosx10.6.pkg

Затем необходимо установить TCL по ссылке:

http://www.activestate.com/activetcl/downloads/thank-you?dl=http://downloads.activestate.com/ActiveTcl/releases/8.5.18.0/ActiveTcl8.5.18.0.298892-macosx10.5-i386-x86_64-threaded.dmg 

Запустите IDLE и откройте через него файл Halieus.pyw (Run – Run module).