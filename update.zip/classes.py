import tkinter as tk
from tkinter import ttk

class CreateToolTip(object):
    """Show tooptips at widgets"""
    def __init__(self, widget, text='widget info', waittime=400):
        self.waittime = waittime #miliseconds
        self.wraplength = 180    #pixels
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.leave)
        self.widget.bind("<ButtonPress>", self.leave)
        self.id = None
        self.tw = None
    def enter(self, event): self.schedule(event)
    def leave(self, event):
        self.unschedule()
        self.hidetip()
    def schedule(self, event):
        self.unschedule()
        self.id = self.widget.after(self.waittime, lambda: self.showtip(event))
    def unschedule(self):
        id = self.id
        self.id = None
        if id: self.widget.after_cancel(id)
    def showtip(self, event):
        x = y = 0
        x, y, cx, cy = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        # creates a toplevel window
        self.tw = tk.Toplevel(self.widget)
        # Leaves only the label and removes the app window
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))
        self.label = tk.Label(self.tw, text=self.text, justify='left',
                       background="#ffffff", relief='solid', borderwidth=1,
                       wraplength = self.wraplength)
        self.label.pack(ipadx=1)
    def hidetip(self):
        tw = self.tw
        self.tw= None
        if tw: tw.destroy()
    def rewrite(self, text):
        self.text=text

class Splash(tk.Toplevel):
    """Show splash screen"""
    def __init__(self, permission=False, master=None):
        self.permission=permission
        if self.permission==False: return            
        self.master=tk.Toplevel()
        self.master["cursor"]="watch"
        w=450
        h=300
        ws = self.master.winfo_screenwidth()
        hs = self.master.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-50
        self.master.geometry('%dx%d+%d+%d' % (w, h, x, y))
        self.master.wm_overrideredirect(True)       
        self.master.columnconfigure(0, weight=1)
        self.master.rowconfigure(2, weight=1)
        self.imgSplash=tk.PhotoImage(file="images/splash.gif")
        tk.Label(self.master, bd=0,image=self.imgSplash).place(x=0,y=0)
        ttk.Label(self.master, text="Halieus", font="Arial 12 bold italic").grid(column=0,row=0,padx=5,pady=5,sticky="nw")        
        with open("Halieus.pyw", "r", encoding="utf-8") as file: content = [line.rstrip() for line in file]
        ttk.Label(self.master, text="v%s" % content[0][10:], font="Arial 8 italic").grid(column=0,columnspan=2,row=0,padx=5,pady=7,sticky="ne")        
        self.splashText=tk.Label(self.master, fg="white", bg="Teal", font="Arial 8")
        self.splashText.grid(column=1,row=4,sticky="se")
        self.master.update()
    def update(self, text):
        if self.permission==False: return            
        self.splashText.configure(text=text)
        self.master.update()
    def end(self):
        if self.permission==False: return
        self.master.destroy()

class Progress():
    """Show progress bar"""
    
    def __init__(self, text):        
        bgColor="gray95"
        self.form=tk.Toplevel(bg=bgColor, bd=1, relief='solid', borderwidth=1)
        w=200
        h=50
        ws = self.form.winfo_screenwidth()
        hs = self.form.winfo_screenheight()
        x = (ws/2)-(w/2)
        y = (hs/2)-(h/2)-50
        self.form.geometry('%dx%d+%d+%d' % (w,h,x, y))
        self.form.wm_overrideredirect(True)
        tk.Label(self.form, bg=bgColor, text=text).pack()
        bar=ttk.Progressbar(self.form)
        bar.start()
        self.form["cursor"]="watch"
        self.form.update()
        bar.pack(padx=5,pady=5,fill="both")
        self.form.focus_force()
        self.form.grab_set()
