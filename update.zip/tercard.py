#!/usr/bin/python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk
import os
import webbrowser
import data as d
import tkinter.messagebox as mb

def terCard(ter, root, new):
    """ Show ter card"""
    
    # Card set up    
    card = tk.Toplevel()
    card.focus_force()
    card.grab_set()
    x = (card.winfo_screenwidth()/2)-280
    y = (card.winfo_screenheight()/4)
    card.geometry('+%d+%d' % (x, y))
    card.minsize(560,500)
    padx=5
    pady=5
    card.grid_columnconfigure (0, weight=1)
    card.grid_rowconfigure    (0, weight=0)
    card.grid_rowconfigure    (1, weight=5)
    card.title("№%s" % ter.number)
    if os.name=="nt": card.iconbitmap(root.ico[3])
    ttk.Sizegrip(card).grid(column=2, row=9, sticky="se")                
    
    # Status frame        
    def action(event):        
        if ter.getStatus()==0:
            ter.give(root, fromTerCard=True)            
            buttonAction["text"]="Выдать"
        else:
            ter.submit(root, fromTerCard=True)
            buttonAction["text"]="Сдать"
        drawStatus()
        drawHistory()
    def drawStatus():
        """ Draw and update status information for card """  
        if ter.getStatus()==0:
            statusLabel["text"]="В картотеке"
            statusLabel["image"]=root.img[3]
            buttonAction["text"]="Выдать"
            buttonAction["image"]=root.img[9]
            card.bind("<Alt-Home>", action)
            card.bind("<Alt-End", None)
        elif ter.getStatus()==1:
            statusLabel["text"]="Обрабатывается возвещателем %s\nВыдан %s (%s дн. назад)" % (ter.getPublisher(), ter.getDate1(), ter.getDelta1())
            statusLabel["image"]=root.img[33]
            buttonAction["text"]="Сдать"
            buttonAction["image"]=root.img[8]
            card.bind("<Alt-Home>", None)
            card.bind("<Alt-End>", action)
        else:
            statusLabel["text"]="Просрочен возвещателем %s\nВыдан %s (%s дн. назад)" % (ter.getPublisher(), ter.getDate1(), ter.getDelta1())
            statusLabel["image"]=root.img[15]
            buttonAction["text"]="Сдать"
            buttonAction["image"]=root.img[9]
            card.bind("<Alt-Home>", None)
            card.bind("<Alt-End>", action)    
    statusFrame=ttk.LabelFrame(card, text="Статус участка")
    statusFrame.grid_columnconfigure (1, weight=1)
    statusFrame.grid(column=0, row=0, columnspan=3, padx=padx, pady=pady, sticky="nesw")
    statusLabel=tk.Label(statusFrame, compound="left", justify="left", padx=5)
    statusLabel.pack(padx=5, pady=5, side="left") 
    buttonAction=ttk.Button(statusFrame, compound="left")
    buttonAction.bind("<1>", action)
    drawStatus()
    ttk.Label(statusFrame).pack(pady=5, side="left")    
    if os.name!="posix": buttonAction.pack(padx=5, pady=5, side="right")
    
    # Notebook set up
    nb=ttk.Notebook(card)
    nb.grid(column=0, row=1, columnspan=3, padx=padx, pady=pady, sticky="nesw")
    tab1=tk.Frame(nb)    
    nb.add(tab1, text="Данные", image=root.img[30], compound="left")
    tab2=ttk.Frame(nb)
    #averages=ter.getAverageWork()
    #averagesSum=sum(averages)/float(len(averages))
    if ter.getDelta2()==999999: delta2="∞"
    else: delta2=ter.getDelta2()
    nb.add(tab2, text="Обработка (%d/%s)" % (ter.getWorks(), delta2), image=root.img[5], compound="left")
    
    # Tab 1 (info)
    tab1.grid_columnconfigure(1, weight=1) # tags
    #tab1.grid_rowconfigure(0, weight=1)
    #tab1.grid_rowconfigure(1, weight=1)
    #tab1.grid_rowconfigure(2, weight=1)
    tab1.grid_rowconfigure(3, weight=5)
    #tab1.grid_rowconfigure(4, weight=1)
    #tab1.grid_rowconfigure(5, weight=1)
    tk.Label(tab1, image=root.img[22], compound="left", text=" Номер").grid(column=0, row=0, padx=padx, pady=pady*2, sticky="w")
    tk.Label(tab1, image=root.img[26], compound="left", text=" Тип").grid(column=0, row=1, padx=padx, pady=pady*2, sticky="w")
    tk.Label(tab1, image=root.img[21], compound="left", text=" Адрес").grid(column=0, row=2, padx=padx, pady=pady*2, sticky="w")
    tk.Label(tab1, image=root.img[20], compound="left", text=" Заметка").grid(column=0, row=3, padx=padx, pady=pady*2, sticky="w")
    def openMap(): webbrowser.open(entry[4].get())
    buttonMap=ttk.Button(tab1, image=root.img[53], compound="left", text=" Карта", command=openMap)
    buttonMap.grid(column=0, row=4, padx=padx, pady=pady*2, sticky="w")
    root.CreateToolTip(buttonMap, "Чтобы открыть участок на карте, введите URL-адрес")
    entry=[]                                                                    # fields            
    for i in range(6): entry.append(tk.Entry(tab1, relief="flat"))
    entry[0].grid(column=1, row=0, padx=padx, pady=pady, sticky="we")
    entry[0].focus_force()
    entry[0].insert(0, ter.number)
    def updateTitle(event): card.title("№%s" % entry[0].get().strip())        
    entry[0].bind("<KeyRelease>", updateTitle)    
    entry[1].grid(column=1, row=1, padx=padx, pady=pady, sticky="we")
    entry[1].insert(0, ter.type)
    entry[2].grid(column=1, row=2, padx=padx, pady=pady, sticky="we")
    entry[2].insert(0, ter.address)
    #entry[3].grid(column=1, row=3, padx=padx, pady=pady, sticky="we")
    #entry[3].insert(0, ter.note)    
    note=tk.Text(tab1, font="{%s} %s" % (root.listFont.get(), root.listFontSize.get()), relief="flat")
    note.insert(0.0, ter.note)
    note.grid(column=1, row=3, padx=padx, pady=pady, sticky="wesn")
    note.bind("<Button-3>", root.standardMenu)
    rightScrollbar = ttk.Scrollbar(note, orient="vertical", command=note.yview)
    note.configure(yscrollcommand=rightScrollbar.set)      
    rightScrollbar.pack(side="right", fill="y")
    entry[4].grid(column=1, row=4, padx=padx, pady=pady, sticky="we")
    entry[4].insert(0, ter.map)
    if root.images.get()==1:
        def openImage():
            if os.path.exists("%s.png" % entry[5].get().strip()): webbrowser.open("%s.png" % entry[5].get().strip())
            else: mb.showerror("Ошибка", "Файл не найден! Проверьте наличие файла %s.png в папке программы." % entry[5].get())
        buttonImage=ttk.Button(tab1, image=root.img[54], compound="left", text="Картинка", command=openImage)
        buttonImage.grid(column=0, row=5, padx=padx, pady=pady, sticky="w")
        root.CreateToolTip(buttonImage, "Чтобы открыть картинку в формате PNG, введите название файла (без расширения .png), который находится в папке программы")
        entry[5].grid(column=1, row=5, padx=padx, pady=pady, sticky="we")
        entry[5].insert(0, ter.image)
        def insertImage():
            entry[5].delete(0, "end")
            entry[5].insert(0, entry[0].get().strip())
            if entry[5].get().strip()!="": buttonImage.state(["!disabled"])
            else: buttonImage.state(["disabled"])
        ttk.Button(tab1, text="Как номер", style="small2.TButton", command=insertImage).grid(padx=5, pady=5, column=2, row=5, sticky="w")
    style = ttk.Style()                                                         # buttons
    style.configure("small2.TButton", font=('', 8))
    def insertMap():
        entry[4].delete(0, "end")
        entry[4].insert(0, "https://yandex.ru/maps/?text=%s" % entry[2].get().strip())
        if entry[4].get().strip()!="": buttonMap.state(["!disabled"])
        else: buttonMap.state(["disabled"])
    ttk.Button(tab1, text="Как адрес", style="small2.TButton", command=insertMap).grid(padx=5, pady=5, column=2, row=4, sticky="w") 
    def checkButtonMapState(event):
        if entry[4].get().strip()!="": buttonMap.state(["!disabled"])
        else: buttonMap.state(["disabled"])
    entry[4].bind("<KeyRelease>", checkButtonMapState)
    checkButtonMapState(None)
    def checkButtonImageState(event):
        if entry[5].get().strip()!="": buttonImage.state(["!disabled"])
        else: buttonImage.state(["disabled"])
    if root.images.get()==1:
        entry[5].bind("<KeyRelease>", checkButtonImageState)
        checkButtonImageState(None)
    
    # Tab 2 (history)
    def drawHistory():
        """ Draw and update history information on tab 2 """
        if ter.getDelta2()==999999: delta2="∞"
        else: delta2=ter.getDelta2()
        text2=". Последняя – %s дн. назад " % delta2
        if ter.getWorks()==0: info.configure(image=root.img[32])
        elif ter.getWorks()>0:
            text2=". Последняя – %s дн. назад (%s) " % (delta2, ter.getDateLastSubmit())
            if ter.getDelta2()>365: info.configure(image=root.img[32])
        info["text"]="Обработок – %d%s" % (ter.getWorks(), text2)
        #info["text"]+="\nСреднее время обработки: %d дн." % averagesSum        
        #nb.configure(tab2, text="Обработка (%d/%s)" % (ter.getWorks(), delta2))
        #root.CreateToolTip(info, "Последний раз участок обрабатывался свыше 365 дней назад либо никогда")
        
        workContent=tk.StringVar(value=tuple(["%3d) %-25s %8s – %8s" % (i+1, (ter.works[i][0][:25]+""), ter.works[i][1], ter.works[i][2]) for i in range(len(ter.works))])) # fill list        
        workList.configure(listvariable=workContent)
    tab2.grid_columnconfigure (1, weight=1)
    tab2.grid_rowconfigure (1, weight=1)
    info=tk.Label(tab2, image=None, compound="right")
    info.grid(column=0, row=0, padx=3, pady=pady, sticky="w")       
    workList=tk.Listbox(tab2, relief="flat", activestyle="dotbox", font="{%s} %s" % (root.listFont.get(), root.listFontSize.get()))    
    workList.grid(column=0, row=1, columnspan=2, padx=padx*2, pady=pady, sticky="nesw")    
    drawHistory()
    rightScrollbar = ttk.Scrollbar(workList, orient="vertical", command=workList.yview)
    workList.configure(yscrollcommand=rightScrollbar.set)      
    rightScrollbar.pack(side="right", fill="y")

    # History edit
    def openVisit(event=None):
        sel=workList.curselection()[0]
        if ter.works[sel][0]=="" or ter.works[sel][1]=="" or ter.works[sel][2]=="":
            root.quickTip("Нельзя отредактировать незаконченную обработку", 200, 2000)
            return
        visit=tk.Toplevel()
        visit.focus_force()
        visit.grab_set()
        w = 340
        h = 160
        ws = visit.winfo_screenwidth()
        hs = visit.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)-40
        visit.geometry('%dx%d+%d+%d' % (w, h, x, y))
        visit.minsize(w,h)
        visit.maxsize(w,h)
        visit.grid_columnconfigure (0, weight=1)
        visit.grid_rowconfigure    (0, weight=0)
        sel2=sel+1
        visit.title("%d)" % sel2)
        if os.name=="nt": visit.iconbitmap(root.ico[4])
        def quitVisit(event):
            visit.destroy()
            card.grab_set()
            workList.focus_force()
        visit.bind("<Escape>", quitVisit)
        visit.columnconfigure(1, weight=1)
        visit.rowconfigure(3, weight=1)
        ttk.Label(visit, text="Возвещатель:").grid(column=0, row=0, padx=padx, pady=pady, sticky="e")
        ttk.Label(visit, text="Дата выдачи участка:").grid(column=0, row=1, padx=padx, pady=pady, sticky="e")
        ttk.Label(visit, text="Дата сдачи участка:").grid(column=0, row=2, padx=padx, pady=pady, sticky="e")
        name=ttk.Entry(visit)
        name.grid(column=1, columnspan=2, row=0, padx=padx, pady=pady, sticky="we")
        name.insert(0, ter.works[sel][0])
        date1=ttk.Entry(visit)
        date1.grid(column=1, columnspan=2, row=1, padx=padx, pady=pady, sticky="we")
        date1.insert(0, ter.works[sel][1])
        date2=ttk.Entry(visit)
        date2.grid(column=1, columnspan=2, row=2, padx=padx, pady=pady, sticky="we")
        date2.insert(0, ter.works[sel][2])
        wrongDate=tk.Label(visit, fg="red")
        wrongDate.grid(column=0, columnspan=3, padx=padx, row=3)
        def delete():
            del ter.works[sel]
            drawHistory()
            quitVisit(None)
        ttk.Button(visit, text="Удалить", image=root.img[28], compound="left", command=delete).grid(column=0, row=4, padx=padx, pady=pady, sticky="w")
        def saveVisit():
            if d.verifyDate(date1.get().strip(), silent=True)==False or d.verifyDate(date2.get().strip(), silent=True)==False: wrongDate["text"]="Проверьте правильность ввода дат (ДД.ММ.ГГ)"
            elif name.get().strip()=="": wrongDate["text"]="Имя не может быть пустым"
            else:
                ter.works[sel][0]=name.get().strip()
                ter.works[sel][1]=date1.get().strip()
                ter.works[sel][2]=date2.get().strip()
                drawHistory()
                quitVisit(None)
        ttk.Button(visit, text="Сохранить", image=root.img[36], compound="left", command=saveVisit).grid(column=1, row=4, padx=padx, pady=pady, sticky="e")
        def __quit(): quitVisit(None)
        ttk.Button(visit, text="Отмена", command=__quit).grid(column=2, row=4, padx=padx, pady=pady, sticky="w")
    if os.name!="posix": workList.bind("<Double-Button-1>", openVisit)
    workList.bind("<Return>", openVisit)    
    def popupWorkList(event): workListMenu.post(event.x_root, event.y_root)    
    workList.bind("<3>", popupWorkList)
    listbar = tk.Menu(workList)
    workListMenu = tk.Menu(listbar, tearoff=0)
    workListMenu.add_command(label="Открыть", image=root.img[27], compound="left", command=openVisit)
    
    # Save and cancel    
    buttonSave=ttk.Button(card, text="Сохранить", image=root.img[36], compound="left")
    def saveCard(event): 
        ter.number=entry[0].get().strip()
        ter.type=entry[1].get().strip()
        ter.address=entry[2].get().strip()
        #ter.note=entry[3].get().strip()
        ter.note=note.get(0.0, "end").strip()
        ter.map=entry[4].get().strip()
        if root.images.get()==1: ter.image=entry[5].get().strip()        
        root.save()
        card.destroy()
    buttonSave.bind("<Button-1>", saveCard)
    buttonSave.grid(padx=padx, ipadx=padx*5, ipady=3, column=1, row=2, sticky="se")
    def cancelChanges(event): card.destroy()
    buttonCancel=ttk.Button(card, text="Отмена")   
    buttonCancel.bind("<Button-1>", cancelChanges)
    card.bind("<Escape>", cancelChanges)
    buttonCancel.grid(padx=padx, ipadx=padx*5, ipady=3, column=2, row=2, sticky="se")    
    for e in entry:
        e.bind("<Return>", saveCard)    
        e.bind("<Button-3>", root.standardMenu)
    
    # After close
    card.wait_window()
    result, root.db, root.settings=d.load()
    root.update()
    root.list.focus_force()
